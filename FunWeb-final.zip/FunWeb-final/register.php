<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Bootstrap Example</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
         <!-- import CSS -->
       <link rel="stylesheet" href="css\navbar.css">
        <link href="bootstrap-3.3.6\dist\css\bootstrap.min.css" rel="stylesheet">
        <link href="bootstrap-3.3.6\dist\css\bootstrap.css" rel="stylesheet">
        <link href="css\register.css" rel="stylesheet">
        <link href="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-2.2.3.js">
        
  
        <!-- import JS -->
        <script type="text/javascript" src="js\register.js"></script> 
        <!-- import PHP -->
        <?php include'Model/Informatii.php'; ?>
        <?php include'Model/Index.php'; ?>
        
    </head>
    <body>
<br><br>
        <div id="Titlu_inregistrare"> Start learning! </div>
        <hr>
        <!--<form id = "Login_formular" >
        Username:<input type='text' name='user' placeholder="Type your username here..." /><br>
        Password :<input type='password' name='password' placeholder="Type your password here..."/><br>
        <input type='submit' class="btn btn-default"  value='Login aplication' name='Submit'/>
        </form>-->
        <form id = "Inregistrare_formular" class="form-horizontal" role="form" method="POST">
            <div class="form-group">
                <div class="col-sm-10">
                    <fieldset>
                        <label class="control-label col-sm-2" for="user"><i class="glyphicon glyphicon-user"></i> </label>


                        <input type="text" class="form-control" name='user' id="user" placeholder="Username" onkeyup="checkUsernameForLength(this);" required="true"/>
                        <span class="hint"> minimum 4 characters length </span>

                    </fieldset>
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-10">
                    <fieldset>
                        <label class="control-label col-sm-2" for="email"> <i class="glyphicon glyphicon-envelope"></i></label>

                        <input type="email" class="form-control" name='email' id="email"  placeholder="Email" onkeyup="checkEmail(this);" required="true"/>
                        <span class="hint">You can enter your real address without worry - we don't spam!</span>
                    </fieldset>
                </div>
            </div>


            <div class="form-group">
                <div class="col-sm-10"> 
                    <fieldset>
                        <label class="control-label col-sm-2" for="parola"> <i class="glyphicon glyphicon-lock"></i> </label>

                        <input type="password" name="parola" class="form-control" id="parola" placeholder="Password" onkeyup="checkPassword(this);" required="true"/>
                        <span class="hint"> at least 4 characters in length, 8 characters recommended! </span>
                    </fieldset>
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-10">
                    <fieldset>
                        <label class="control-label col-sm-2" for="rescrie_parola"> <i class="glyphicon glyphicon-lock"></i> </label>

                        <input type="password" class="form-control" name="rescrie_parola" id="rescrie_parola" placeholder="Confirm password" onkeyup="checkPass(); return false;" required="true"/>
                        <span id='message' class='message'></span>
                    </fieldset>

                </div>
            </div>




            <div id= "inregistrare" class="form-group">        
                <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" id="inregistrare_buton" class="btn btn-primary" name="Register"> Register </button>
                </div>
            </div>
        </form>
        <?php
        register();
        ?>

<br><br>
    </body>
</html>
