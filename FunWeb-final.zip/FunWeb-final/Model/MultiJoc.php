<?php

function getQuestion($nr_intrebari) {

    $conn = connect();
    $id_joc = $_SESSION['id_joc'];

    $stmt = mysqli_prepare($conn, "SELECT DOMENII_ALESE FROM PARTIDE_DE_JOC WHERE ID_JOC=?");
    mysqli_stmt_bind_param($stmt, 'd', $id_joc);
    $stmt->execute();
    $stmt->bind_result($domenii_alese);
    $stmt->fetch();


    $domenii_alese_array = array();
    $domenii_alese_array = explode(",", $domenii_alese);
    $multime_domenii = "";


    if (sizeof($domenii_alese_array) == 1) {
        $multime_domenii = $domenii_alese_array[0];
    } else {
        if (sizeof($domenii_alese_array) == 2) {
            $multime_domenii = $domenii_alese_array[0] . "','" . $domenii_alese_array[1];
        } else {
            $multime_domenii = $domenii_alese_array[0] . "',";
            for ($i = 1; $i < sizeof($domenii_alese_array) - 1; $i++) {
                $multime_domenii = $multime_domenii . "'" . $domenii_alese_array[$i] . "',";
            }
            $multime_domenii = $multime_domenii . "'" . $domenii_alese_array[$i];
        }
    }


    mysqli_stmt_free_result($stmt);
    $interogare = "SELECT ID_INTREBARE FROM INTREBARI WHERE DOMENIU IN ( '" . $multime_domenii . "' ) ORDER BY RAND() LIMIT " . $nr_intrebari;

    $stmt = mysqli_prepare($conn, $interogare);
    //mysqli_stmt_bind_param($stmt,'s',$multime_domenii);
    $stmt->execute();
    $stmt->bind_result($id_intrebare);
    //punem intrebarile selectate intr-un array
    $id_intrebari = array();
    while ($stmt->fetch()) {

        array_push($id_intrebari, $id_intrebare);
    }

    $id_intrebari_string = "";

    if (sizeof($id_intrebari) == 1) {
        $id_intrebari_string = $id_intrebari[0];
    } else {
        if (sizeof($id_intrebari) == 2) {
            $id_intrebari_string = $id_intrebari[0] . "," . $id_intrebari[1];
        } else {

            $id_intrebari_string = $id_intrebari[0] . ",";

            for ($i = 1; $i < sizeof($id_intrebari) - 1; $i++) {
                $id_intrebari_string = $id_intrebari_string . $id_intrebari[$i] . ",";
            }

            $id_intrebari_string = $id_intrebari_string . $id_intrebari[$i];
        }
    }

    return $id_intrebari_string;
}

function createGame() {

    if (isset($_POST['Create'])) {
// Create connection
        $ok = 0;
        $domenii = array();
        if (!empty($_POST['chk1'])) {
            array_push($domenii, "html");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }
        if (!empty($_POST['chk2'])) {
            array_push($domenii, "angular");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }
        if (!empty($_POST['chk3'])) {
            array_push($domenii, "php");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }
        if (!empty($_POST['chk4'])) {
            array_push($domenii, "css");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }
        if (!empty($_POST['chk5'])) {
            array_push($domenii, "ajax");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }
        if (!empty($_POST['chk6'])) {
            array_push($domenii, "js");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }
        if (!empty($_POST['chk7'])) {
            array_push($domenii, "http");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }
        if (!empty($_POST['chk8'])) {
            array_push($domenii, "xml");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }


        if ($ok == 0) {
            $domenii = array();
            array_push($domenii, "html");
            array_push($domenii, "angular");

            array_push($domenii, "php");
            array_push($domenii, "css");
            array_push($domenii, "js");
            array_push($domenii, "http");
            array_push($domenii, "ajax");
            array_push($domenii, "xml");
        }

        $conn = connect();

        $all_dom = "";
        $prim = 0;
        for ($i = 0; $i < sizeof($domenii); $i++) {
            if ($domenii[$i] != "") {
                if ($prim == 0) {
                    $all_dom = $all_dom . $domenii[$i];
                    $prim = 1;
                } else
                    $all_dom = $all_dom . "," . $domenii[$i];
            }
        }

        $ok = 1;
        $user2 = $_POST['user1'];
        $user3 = $_POST['user2'];
        $question_number = $_POST['questions'];
        $autor = $_SESSION["my_user"];
        $stmt = mysqli_prepare($conn, "SELECT COUNT(*) FROM PARTIDE_DE_JOC WHERE STATUS_JOC=\"WAITING\" AND USER1=?");
        mysqli_stmt_bind_param($stmt, 's', $autor);
        mysqli_stmt_execute($stmt);
        $stmt->bind_result($areJoc);
        $stmt->fetch();
        if ($areJoc != 0) {
            print '   <!-- Modal -->
<div id="modal">
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Warning!</h4>
        </div>
        <div class="modal-body">
          <p><b>You already have a game in the waiting list! Please have patience!<b></p>
       
          <button type="button" class="btn btn-default" data-dismiss="modal" style="float:right;">OK</button><br><br>
        </div> 
      </div>
      
    </div>
  </div>
</div>
 <script> $("#myModal").modal("show"); </script>';
        } else {

            mysqli_stmt_free_result($stmt);
            if ($user2 == "") {
                $user2 = "?";
            }
            if ($user3 == "") {
                $user3 = "?";
            }
            if (($user2 != $user3) || ($user2 == "?" && $user3 == "?")) {

                $stmt = mysqli_prepare($conn, "INSERT INTO PARTIDE_DE_JOC 
        (USER1,USER2,USER3,CASTIGATORI,DOMENII_ALESE,NR_INTREBARI,PUNCTAJ_USER1,PUNCTAJ_USER2,PUNCTAJ_USER3,DATA_JOC,DURATA,STATUS_JOC,CORECTE_1,CORECTE_2,CORECTE_3)
        VALUES (?,?,?,null,?,?,0,0,0,null,null,\"WAITING\",0,0,0)");
                mysqli_stmt_bind_param($stmt, 'ssssd', $autor, $user2, $user3, $all_dom, $question_number);
                mysqli_stmt_execute($stmt);

                //sa punem id-ul jocului in sesiune
                mysqli_stmt_free_result($stmt);

                //jucatorul curent este jucator_1 din tabel [autorul]
                $_SESSION['nr_jucator'] = 1;
                //preluam username jucatorului curent, cel care a reat jocul
                $jucatorCreator = $_SESSION["my_user"];
                //aflam id-ul jocului proaspat creat
                $stmt = mysqli_prepare($conn, "SELECT ID_JOC FROM PARTIDE_DE_JOC WHERE USER1=? AND STATUS_JOC=\"WAITING\"");
                mysqli_stmt_bind_param($stmt, 's', $jucatorCreator);
                $stmt->execute();
                $stmt->bind_result($id_joc);
                $stmt->fetch();
                //si-l pastram in sesiune
                $_SESSION['id_joc'] = $id_joc;
                //initializam un vector care v-a memora raspunsurile date pt raport 
                initializareRaport();

                mysqli_stmt_free_result($stmt);

                $intrebarile_jocului = getQuestion($question_number);

                mysqli_stmt_free_result($stmt);

                $updateLaIntrebari = "UPDATE PARTIDE_DE_JOC SET INTREBARI = '" . $intrebarile_jocului . "' WHERE ID_JOC= " . $id_joc;

                $stmt = mysqli_prepare($conn, $updateLaIntrebari);
                mysqli_stmt_execute($stmt);

                //sa punem id-ul jocului in sesiune
                mysqli_stmt_free_result($stmt);
                mysqli_close($conn);

                $_SESSION['index_intrebare'] = $question_number;
                // startGame();
            } else {
                print '   <!-- Modal -->
<div id="modal">
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Warning!</h4>
        </div>
        <div class="modal-body">
          <p><b>Please choose different oponents!<b></p>
          <button type="button" class="btn btn-default" data-dismiss="modal" style="float:right;">OK</button><br><br>
        </div> 
      </div>
      
    </div>
  </div>
</div>
 <script> $("#myModal").modal("show"); </script>';
            }
        }
    }
}

function joinGame() {

    if (isset($_POST['joinGame'])) {

        $conn = connect();

        $autor = $_POST['autor_joc'];

        $stmt = mysqli_prepare($conn, "SELECT ID_JOC,USER2,USER3,JOIN_USER2,JOIN_USER3,NR_INTREBARI FROM PARTIDE_DE_JOC WHERE USER1=? AND STATUS_JOC=\"WAITING\"");
        mysqli_stmt_bind_param($stmt, 's', $autor);
        $stmt->execute();

        $stmt->bind_result($id_joc, $user2, $user3, $join_user2, $join_user3, $nr_intrebari);
        $stmt->fetch();

        $jucatorCurent = $_SESSION["my_user"];

        //pastram nr de intrebari ale jocului in sesiune
        $_SESSION['index_intrebare'] = $nr_intrebari;
        //pastram idul jocului in sesiune
        $_SESSION['id_joc'] = $id_joc;
        //pastram punctajul jucatorului curent in sesiune
        initializareRaport();
        if ($autor != $jucatorCurent) {
            if (($user2 == "?" || $user2 == $jucatorCurent) && $join_user2 == 0) {
                $user2 = $jucatorCurent;
                $join_user2 = 1;
                $_SESSION['nr_jucator'] = 2;
            } else {
                if (($user3 == "?" || $user3 == $jucatorCurent) && ($user2 != $jucatorCurent) && $join_user3 == 0) {
                    $user3 = $jucatorCurent;
                    $join_user3 = 1;
                    $_SESSION['nr_jucator'] = 3;
                    //lansam jocul
                }
            }

            mysqli_stmt_free_result($stmt);
            $stmt = mysqli_prepare($conn, "UPDATE PARTIDE_DE_JOC SET USER2=?, USER3=?, JOIN_USER2=?,JOIN_USER3=? WHERE USER1=? AND STATUS_JOC=\"WAITING\" ");

            mysqli_stmt_bind_param($stmt, 'ssdds', $user2, $user3, $join_user2, $join_user3, $autor);
            $stmt->execute();

            mysqli_stmt_free_result($stmt);
            ///User-ul devine indisponibil
            mysqli_stmt_free_result($stmt);
            $stmt = mysqli_prepare($conn, "UPDATE UTILIZATORI SET STATUS = 'INDISPONIBIL' WHERE USERNAME=?");


            mysqli_stmt_bind_param($stmt, 's', $jucatorCurent);
            $stmt->execute();

            mysqli_stmt_free_result($stmt);
            //
            mysqli_close($conn);

            //startGame();
        } else {
            print '   <!-- Modal -->
<div id="modal">
  <div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog">
      
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Warning!</h4>
        </div>
        <div class="modal-body">
          <p><b>You are trying to join your own game! LoL ..<b></p>
       
          <button type="button" class="btn btn-default" data-dismiss="modal" style="float:right;">OK</button><br><br>
        </div> 
      </div>
      
    </div>
  </div>
</div>
 <script> $("#myModal2").modal("show"); </script>';
        }
    }
}

function verifyAnswer() {
    $raspuns_dat = '';
    $rapsuns_raport = '';
    if (isset($_POST['A'])) {
        $raspuns_dat = 'A';
        $raspuns_raport = 'A. ' . htmlentities($_SESSION['enunturi'][sizeof($_SESSION['enunturi']) - 1][1]);
    }
    if (isset($_POST['B'])) {
        $raspuns_dat = 'B';
        $raspuns_raport = 'B. ' . htmlentities($_SESSION['enunturi'][sizeof($_SESSION['enunturi']) - 1][2]);
    }
    if (isset($_POST['C'])) {
        $raspuns_dat = 'C';
        $raspuns_raport = 'C. ' . htmlentities($_SESSION['enunturi'][sizeof($_SESSION['enunturi']) - 1][3]);
    }
    if (isset($_POST['D'])) {
        $raspuns_dat = 'D';
        $raspuns_raport = 'D. ' . htmlentities($_SESSION['enunturi'][sizeof($_SESSION['enunturi']) - 1][4]);
    }
    if (isset($_POST['E'])) {
        $raspuns_dat = 'E';
        $raspuns_raport = 'E. No response';
    }
    if ($raspuns_dat != '') {
        array_push($_SESSION['raspunsuri_date'], $raspuns_raport);

        $_SESSION['index_intrebare'] = $_SESSION['index_intrebare'] - 1;
        $raspuns_corect = $_SESSION['raspuns_corect'];

        if ($raspuns_dat == $raspuns_corect) {//pastram datele pt raport: daca raspunsul curent este corect/gresit
            array_push($_SESSION['raport_raspunsuri'], " corect ");
            return true;
        } else {
            array_push($_SESSION['raport_raspunsuri'], " gresit ");
            return false;
        }
    }
}

function verifyAnswer_Multi() {
    if (verifyAnswer()) {
        updateMulti();
    }

    if ($_SESSION['index_intrebare'] <= 0) {


$conn = connect();
    $id_joc = $_SESSION['id_joc'];

    $stmt = mysqli_prepare($conn, "UPDATE PARTIDE_DE_JOC SET FINAL_USER1=FINAL_USER1+1 WHERE ID_JOC=?");
    mysqli_stmt_bind_param($stmt, 'd', $id_joc);
    $stmt->execute();
   




        print "<script>";
        print "self.location = 'prefinal.php';";
        print "</script>";
    }
}

function statistici_Multi() {
    $conn = connect();
    $select = "SELECT USER1,USER2,USER3,PUNCTAJ_USER1,PUNCTAJ_USER2,PUNCTAJ_USER3,CORECTE_" . $_SESSION['nr_jucator'] . ", NR_INTREBARI FROM PARTIDE_DE_JOC WHERE ID_JOC= " . $_SESSION['id_joc'];
    $stmt = mysqli_prepare($conn, $select);
    $stmt->bind_result($user1, $user2, $user3, $punctaj_1, $punctaj_2, $punctaj_3, $corecte, $nr_total_intrebari);
    $stmt->execute();
    $stmt->fetch();

    $nr_intrebari_gresite = $nr_total_intrebari - $corecte - $_SESSION['index_intrebare'];

    mysqli_stmt_free_result($stmt);
    mysqli_close($conn);
    $index_userCurent = $_SESSION['nr_jucator'];
    switch ($index_userCurent) {
        case '1':
            $punctajCurent = $punctaj_1;
            $user_1 = $user2;
            $user_2 = $user3;
            $punctaj_partener1 = $punctaj_2;
            $punctaj_partener2 = $punctaj_3;
            break;
        case '2':
            $punctajCurent = $punctaj_2;
            $user_1 = $user1;
            $user_2 = $user3;
            $punctaj_partener1 = $punctaj_1;
            $punctaj_partener2 = $punctaj_3;
            break;
        default:
            $punctajCurent = $punctaj_3;
            $user_1 = $user1;
            $user_2 = $user2;
            $punctaj_partener1 = $punctaj_1;
            $punctaj_partener2 = $punctaj_2;
            break;
    }
    $intrebari_ramase = $_SESSION['index_intrebare'];

    print '<div class="statistics form-group">

      <label class="control-label col-sm-2" > Remaining questions: ' . $intrebari_ramase . ' </label>

      <label class="control-label col-sm-2" > Right answers: ' . $corecte . '</label>
      
      <label class="control-label col-sm-2" > Wrong answers: ' . $nr_intrebari_gresite . ' </label>
      
      <label class="control-label col-sm-2" > Score: ' . $punctajCurent . '</label>

      <label class="control-label col-sm-2" > Score ' . $user_1 . ': ' . $punctaj_partener1 . ' </label>
      <label class="control-label col-sm-2" > Score ' . $user_2 . ': ' . $punctaj_partener2 . ' </label>

    </div>';
}

function getIntrebariJoc($id_joc) {

    //stabilim conexiunea la BD
    $conn = connect();
    //facem selectul din BD
    $stmt = mysqli_prepare($conn, "SELECT INTREBARI FROM PARTIDE_DE_JOC WHERE ID_JOC= ? ");
    mysqli_stmt_bind_param($stmt, 'd', $id_joc);
    $stmt->execute();
    $stmt->bind_result($id_intrebari);
    $stmt->fetch();
    //punem idurile intrebarilor intr-un array
    $id_intrebari_array = array();
    $id_intrebari_array = explode(",", $id_intrebari);
    //eliberam statement
    mysqli_stmt_free_result($stmt);
    //inchidem conexiunea
    mysqli_close($conn);
    //returnam arrayul cu id-uri de interbari 
    return $id_intrebari_array;
}

function completeazaCampuri_Multi() {
    //stabilim conexiunea la BD
    $conn = connect();
    //preluam id-ul jocului din sesiune
    $id_joc = $_SESSION['id_joc'];

    //preluam indexul intrebarii curente din sesiune
    $index_intrebare = $_SESSION['index_intrebare'];
    //preluam array-ul cu id-urile intrebarilor
    $id_intrebari_array = getIntrebariJoc($id_joc);

    if ($index_intrebare >= 0) {
        setTimer();
        //preluam id-ul intrebarii de la indexul de intrebare curent
        $intrebare_curenta = $id_intrebari_array[$index_intrebare - 1];
        //facem selectul pentru id-ul intrebarii curente
        $stmt = mysqli_prepare($conn, "SELECT ENUNT,VARIANTA_A,VARIANTA_B,VARIANTA_C,VARIANTA_D,RASPUNS_CORECT,DIFICULTATE,TIMP FROM INTREBARI WHERE ID_INTREBARE= ? ");
        mysqli_stmt_bind_param($stmt, 's', $intrebare_curenta);
        $stmt->execute();
        $stmt->bind_result($enunt, $a, $b, $c, $d, $raspuns_corect, $dificultate, $timp);
        $stmt->fetch();
        //pastram raspunsul corect in sesiune

        $_SESSION['raspuns_corect'] = $raspuns_corect;
        $_SESSION['timp'] = $timp;
        //pastram enunturile si raspunsurile corecte pt raport

        array_push($_SESSION['enunturi'], array($enunt, $a, $b, $c, $d));

        enuntRaspuns($a, $b, $c, $d, $raspuns_corect);
        //pastram raspunsul corect in sesiune
        $_SESSION['dificultate'] = $dificultate;
        //eliberam statement
        mysqli_stmt_free_result($stmt);
        //inchidem conexiunea
        mysqli_close($conn);
        //printam enuntul si variantele de raspuns
        print "<div class=\"form-group\" id=\"enunt\">
      <label class=\"control-label\" > " . $enunt . "</label
    </div><hr>
    
    <div class=\"form-group\">
      <label class=\"control-label \" > A)  " . htmlentities($a) . " </label> 
    </div>

    <div class=\"form-group\">
      <label class=\"control-label \" > B)  " . htmlentities($b) . " </label> 
    </div>

    <div class=\"form-group\">
      <label class=\"control-label \" > C)  " . htmlentities($c) . "</label>
      
    </div>
    
    <div class=\"form-group\">
      <label class=\"control-label \" > D)  " . htmlentities($d) . "</label>
      
    </div>
    
   <div class=\"form-group\">
      <label class=\"control-label \" > E)  I dont't know  </label>
      
    </div>";
    }
}

function updateCastigator() {
    //creem o conexiune
    $conn = connect();
    //PREIA username-ul utilizatorului curent din sesiune
    $id_joc = $_SESSION["id_joc"];
    //pregatim soperatia de select
    $stmt = mysqli_prepare($conn, "SELECT PUNCTAJ_USER1,PUNCTAJ_USER2,PUNCTAJ_USER3 FROM PARTIDE_DE_JOC WHERE ID_JOC = ? ");
    mysqli_stmt_bind_param($stmt, 's', $id_joc);
    //executam operatia
    $stmt->execute();
    //extragem rezultatele
    $stmt->bind_result($punctaj1, $punctaj2, $punctaj3);
    $stmt->fetch();
    //stabilim castigatorul
    $punctaje = array($punctaj1, $punctaj2, $punctaj3);
    $max = max($punctaje);
    $castigatori = "";
    for ($i = 0; $i < sizeof($punctaje); $i++) {
        if ($max == $castigator) {
            $castigatori = $castigatori . "1";
        } else {
            $castigatori = $castigatori . "0";
        }

        //eliberam conexiunea
        mysqli_stmt_free_result($stmt);

        $stmt = mysqli_prepare($conn, "UPDATE PARTIDE_DE_JOC SET CASTIGATORI = ? WHERE ID_JOC = ? ");
        mysqli_stmt_bind_param($stmt, 'ss', $castigatori, $id_joc);
        //executam operatia
        $stmt->execute();
        mysqli_stmt_free_result($stmt);
        mysqli_close($conn);
    }
}

function updatePunctaj() {//SE FACE UPDATE IN CLASAMENT PENTRU UTILIZATRUL CURENT
    $conn = connect();
    //PREIA username-ul utilizatorului curent din sesiune
    $id_joc = $_SESSION["id_joc"];
    //selectam punctajul jocului curent din partide de joc
    $conn = connect();
    $jucatorCurent=$_SESSION['my_user'];
    //pregatim soperatia de select
    $stmt = mysqli_prepare($conn, "SELECT PUNCTAJ_USER" . $_SESSION['nr_jucator'] . " FROM PARTIDE_DE_JOC WHERE ID_JOC = ?");
    mysqli_stmt_bind_param($stmt, 's', $id_joc);
    //executam operatia
    $stmt->execute();
    //extragem rezultatele
    $stmt->bind_result($punctaj);
    $stmt->fetch();
    //eliberam conexiunea
    mysqli_stmt_free_result($stmt);
    //update in clasament
   
    //pregatim operatia de update
    $stmt = mysqli_prepare($conn, "UPDATE CLASAMENT SET PUNCTAJ = PUNCTAJ + ? WHERE USERNAME = ?");
    mysqli_stmt_bind_param($stmt, 'ss', $punctaj, $jucatorCurent);
    //executam operatia
    $stmt->execute();
    //eliberam conexiunea
    mysqli_stmt_free_result($stmt);
    mysqli_close($conn);
}

function setTimer() {
    $timp = $_SESSION['timp'];
    print "<script>
  
    setTimeout(function(){ $( \"#E\" ).click(); }, " . $timp . "000+7000);"
            . "</script>";
}

function updateMulti() {
    $conn = connect();
    $dificultate = $_SESSION['dificultate'];

    switch ($dificultate) {
        case 'e':
            $punctajCurent = 10;
            break;
        case 'm':
            $punctajCurent = 15;
            break;
        default:
            $punctajCurent = 20;
            break;
    }

    $nr = $_SESSION['nr_jucator'];
    $update = "UPDATE PARTIDE_DE_JOC SET CORECTE_" . $nr . " = CORECTE_" . $nr . "+1, PUNCTAJ_USER" . $nr . " = PUNCTAJ_USER" . $nr . " + " . $punctajCurent . " WHERE ID_JOC=" . $_SESSION['id_joc'];

    $stmt = mysqli_prepare($conn, $update);

    $stmt->execute();


    mysqli_stmt_free_result($stmt);
    mysqli_close($conn);
}

function getOnlineUsers() {//inca o coloana pentru cei online!!
    $servername = "mysql.unlimitedfunweb.tk";
    $username = "gfkiller407";
    $password = "Informatica1";
    $dbname = "unlimitedfun_fun";
// Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    $stmt = mysqli_prepare($conn, "SELECT USERNAME from UTILIZATORI WHERE STATUS = 'DISPONIBIL'");
    $stmt->execute();
    $stmt->bind_result($nume);
    $stmt->fetch();
    $jucatorCurent = $_SESSION["my_user"];
    if ($nume != $jucatorCurent) {
        printf("{'word':'%s'}", $nume);
    }

    while ($stmt->fetch()) {
        if ($nume != $jucatorCurent) {
            printf(",\n");
            printf("{'word':'%s'}", $nume);
        }
    }
    mysqli_close($conn);
}

function getPartideDeJoc() {//COMPLETEAZA IN PG DE CONFIGURARE JOCURILE EXISTENTE
// Create connection
    $conn = connect();
    $stmt = mysqli_prepare($conn, "SELECT USER1,USER2,USER3,STATUS_JOC FROM PARTIDE_DE_JOC WHERE STATUS_JOC=\"WAITING\"");
    $stmt->execute();
    $stmt->bind_result($user1, $user2, $user3, $status);

    while ($stmt->fetch()) {
        print '<form  method="POST">
        <div class="panel-body" >
                    <div class="panel panel-primary">
                      <div class="panel-heading">' . $user1 . '</div>
                      <div class="panel-body">
                        <div>
                        <span class="label label-info" id="user">' . $user2 . '</span>
                        <span class="label label-info" id="user">' . $user3 . '</span>
                    </div>
                        <div class="input-group-btn">
                        
                       <button type="submit" class="join" id="JoinGame" name="joinGame"><span>Join Game</span></button>
                      </div>
                      </div>
                  </div>
              </div>
              <input type="hidden" name="autor_joc" value="' . $user1 . '">
        </form>';
    }
    mysqli_close($conn);
}

function getCastigatori() {
    $conn = connect();
    //PREIA username-ul utilizatorului curent din sesiune
    $id_joc = $_SESSION["id_joc"];
    //selectam punctajul jocului curent din partide de joc
    $conn = connect();
    //PREIA username-ul utilizatorului curent din sesiune
    //pregatim soperatia de select
    $stmt = mysqli_prepare($conn, "SELECT USER1,USER2,USER3,CASTIGATORI FROM PARTIDE_DE_JOC WHERE ID_JOC = ?");
    mysqli_stmt_bind_param($stmt, 's', $id_joc);
    //executam operatia
    $stmt->execute();
    //extragem rezultatele
    $stmt->bind_result($user1, $user2, $user3, $castigatori);
    $stmt->fetch();
    $display_winners = "<div ><b>";
    if (substr($castigatori, 0, 1) == "1") {
        $display_winners = $display_winners . $user1 . "<br>";
    }
    if (substr($castigatori, 1, 1) == "1") {
        $display_winners = $display_winners . $user1 . "<br>";
    }
    if (substr($castigatori, 2, 1) == "1") {
        $display_winners = $display_winners . $user1 . "<br>";
    }
    $display_winners = $display_winners . $user1 . "</b></div>";

    //eliberam conexiunea
    mysqli_stmt_free_result($stmt);
    mysqli_close($conn);
    print $display_winners;
}

function finalMultiPage() {
    //creem o conexiune
    $conn = connect();
    //PREIA username-ul utilizatorului curent din sesiune
    $id_joc = $_SESSION['id_joc'];
    //pregatim soperatia de select
    $select = "SELECT USER1,USER2,USER3,CORECTE_1,CORECTE_2,CORECTE_3,NR_INTREBARI FROM PARTIDE_DE_JOC WHERE ID_JOC= ?";
    $stmt = mysqli_prepare($conn, $select);
    mysqli_stmt_bind_param($stmt, 'd', $id_joc);

    //executam operatia
    $stmt->execute();
    //extragem rezultatele
    $stmt->bind_result($user1, $user2, $user3, $corecte1, $corecte2, $corecte3, $nr_total_intrebari);
    $stmt->fetch();


    $gresite1 = $nr_total_intrebari - $corecte1;
    $gresite2 = $nr_total_intrebari - $corecte2;
    $gresite3 = $nr_total_intrebari - $corecte3;

    //desenam graficul
    print "<script type=\"text/javascript\" src=\"https://www.gstatic.com/charts/loader.js\"></script>

  <!-- load Google AJAX API -->
  <script type=\"text/javascript\" src=\"http://www.google.com/jsapi\"></script>


  <script type=\"text/javascript\">

   google.charts.load('current', {'packages':['bar']});
   google.charts.setOnLoadCallback(drawStuff);

   function drawStuff() {

    var data = new google.visualization.arrayToDataTable([
    ['      ', 'Right answers', 'Wrong answers'],
    [ '" . $user1 . "' , " . $corecte1 . " , " . $gresite1 . " ],
    [ '" . $user2 . "' , " . $corecte2 . " , " . $gresite2 . "],
    ['" . $user3 . "' , " . $corecte3 . " , " . $gresite3 . "],
    ]);

    var options = {
    
      width: 900,
      height: 500,
            chart: {
      title:'    ',
      },
      colors: ['#1AAF5D', '#8E0000'],
        
    };
   
    var chart = new google.charts.Bar(document.getElementById('dual_y_div'));
    chart.draw(data, options);
  };
</script>

<div id=\"dual_y_div\" ></div>
";
}

function finalizareMulti() {//UPDATE statusul jocului din baza de date
    $conn = connect();
    //PREIA username-ul utilizatorului curent din sesiune
    $id_joc = $_SESSION['id_joc'];
    //pregatim soperatia de select
    $select = "UPDATE PARTIDE_DE_JOC SET STATUS_JOC = \"FINISHED\" WHERE ID_JOC= ?";
    $stmt = mysqli_prepare($conn, $select);
    mysqli_stmt_bind_param($stmt, 'd', $id_joc);

    //executam operatia
    $stmt->execute();
    //extragem rezultatele
   
    $stmt->fetch();
    mysqli_stmt_free_result($stmt);
    mysqli_close($conn);
    
    }

?>
