<?php
function enuntRaspuns($a,$b,$c,$d,$raspuns_corect){
    $raspuns_raport = $raspuns_corect;
    
    if($raspuns_corect == 'A'){
        $raspuns_raport = $raspuns_raport.". ".htmlentities($a);
        
    }
     if($raspuns_corect == 'B'){
       $raspuns_raport = $raspuns_raport.". ".htmlentities($b);
    }
     if($raspuns_corect == 'C'){
        $raspuns_raport = $raspuns_raport.". ".htmlentities($c);
    }
     if($raspuns_corect == 'D'){
        $raspuns_raport = $raspuns_raport.". ".htmlentities($d);
    }
   
    array_push($_SESSION['raspunsuri_corecte'], $raspuns_raport);
   
}
//de schimbat numlele deoarece aceasta functie e folosita si in multi si in single
function raport(){
    $enunturi = $_SESSION['enunturi'];
    $raspunsuri_date = $_SESSION['raspunsuri_date'];
    $raspunsuri_corecte = $_SESSION['raspunsuri_corecte'];
    $raport_raspunsuri = $_SESSION['raport_raspunsuri'];

    $raport = "<div class=\"w3-card-2\"><table>";
    for ($i = 0; $i < sizeof($raport_raspunsuri); $i++) {
        if ($raport_raspunsuri[$i] === " gresit ") {
            $raport = $raport . "<tr><td><img class=\"icon \" src=\"multimedia/wrong.svg\" ></td><td><b><div><p> ".($i+1).". ". $enunturi[$i][0] ."</p></div>
		<div class=\"wrong\">
    	Your answer: ". $raspunsuri_date[$i] . "</div>
		<div>Right answer: " . $raspunsuri_corecte[$i] ."</div></td></b></tr>";
        }
        else if($raport_raspunsuri[$i] === " corect "){
            $raport = $raport ."<tr> <td><img class=\"icon \"src=\"multimedia/green.svg\" ></td><td><b>
	<div><p>".($i+1).". ".$enunturi[$i][0] ."</p></div>
    <div class=\"right\">  Your right answer: ". $raspunsuri_date[$i] ."</div></td></b></tr>" ;
        }
    }
    
    $raport=$raport."</b></table></div>";
    
    
    return $raport;
}


function initializareRaport(){
               
                $_SESSION['raspunsuri_date']=array();
                $_SESSION['raport_raspunsuri'] = array();
                $_SESSION['raspunsuri_corecte']=array();
                $_SESSION['enunturi'] = array();
}
?>