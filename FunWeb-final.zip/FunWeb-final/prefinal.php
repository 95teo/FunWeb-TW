<?php session_start(); ?>
<!DOCTYPE HTML>
<html lang="en">
    <HEAD>
        <TITLE>
        </TITLE>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- import CSS -->
        <link rel="stylesheet" href="bootstrap-3.3.6/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/menu.css">
	<link rel="stylesheet" href="css\navbar.css">
        <!-- import JS -->
        <script src="bootstrap-3.3.6/js/tests/vendor/jquery.min.js"></script>
        <script src="bootstrap-3.3.6/dist/js/bootstrap.min.js"></script>
        <!-- Add jQuery library -->
        <script type="text/javascript" src="fancybox/lib/jquery-1.10.1.min.js"></script>

        <!-- Add mousewheel plugin (this is optional) -->
        <script type="text/javascript" src="fancybox/lib/jquery.mousewheel-3.0.6.pack.js"></script>

        <!-- Add fancyBox main JS and CSS files -->
        <script type="text/javascript" src="fancybox/source/jquery.fancybox.js?v=2.1.5"></script>
        <link rel="stylesheet" type="text/css" href="fancybox/source/jquery.fancybox.css?v=2.1.5" media="screen" />

        <!-- Add Button helper (this is optional) -->
        <link rel="stylesheet" type="text/css" href="fancybox/source/helpers/jquery.fancybox-buttons.css?v=1.0.5" />
        <script type="text/javascript" src="fancybox/source/helpers/jquery.fancybox-buttons.js?v=1.0.5"></script>

        <!-- Add Thumbnail helper (this is optional) -->
        <link rel="stylesheet" type="text/css" href="fancybox/source/helpers/jquery.fancybox-thumbs.css?v=1.0.7" />
        <script type="text/javascript" src="fancybox/source/helpers/jquery.fancybox-thumbs.js?v=1.0.7"></script>

        <!-- Add Media helper (this is optional) -->
        <script type="text/javascript" src="fancybox/source/helpers/jquery.fancybox-media.js?v=1.0.6"></script>

        
        <script type="text/javascript">
            $(document).ready(function () {
                $('.fancybox').fancybox();

                $(".fancybox-effects-b").fancybox({
                    openEffect: 'none',
                    closeEffect: 'none',
                    helpers: {
                        title: {
                            type: 'over'
                        }
                    }
                });
                $(".fancybox-effects-c").fancybox({
                    openEffect: 'none',
                    closeEffect: 'none',
                    helpers: {
                        title: {
                            type: 'over'
                        }
                    }
                });
                $(".fancybox-effects-d").fancybox({
                    openEffect: 'none',
                    closeEffect: 'none',
                    helpers: {
                        title: {
                            type: 'over'
                        }
                    }
                });

                $("#fancybox-manual-b").click(function () {
                    $.fancybox.open({
                        href: 'info.php',
                        type: 'iframe',
                        padding: 5
                    });
                });
                $("#fancybox-manual-c").click(function () {
                    $.fancybox.open({
                        href: 'statistici.php',
                        type: 'iframe',
                        padding: 5
                    });
                });
                $("#fancybox-manual-d").click(function () {
                    $.fancybox.open({
                        href: 'clasament.php',
                        type: 'iframe',
                        padding: 5
                    });
                });


            });
        </script>
	

        <!-- import PHP -->
        <?php include'Model/Informatii.php'; ?>
        
</HEAD>
<BODY>

   <!-- Bara de navigare -->
        <div>
            <nav class="navbar">
                <div class="container-fluid">
                    <div class="navbar-header ">
                        <a class="navbar-brand" href="menu.php">Fun Web</a>
                    </div>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#" class= "dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user" ></span> <?php echo $_SESSION['my_user'] . "  " ?> </a>
                            <ul class="dropdown-menu">
                                <li><a id="fancybox-manual-b" href="javascript:;">Profile Info </a></li>
                                <li><a id="fancybox-manual-d" href="javascript:;">Clasament</a></li>
                                <li><a id="fancybox-manual-c" href="javascript:;">Statistics</a></li>
                            </ul>
                        </li>

                    </ul>
                </div>
            </nav>
        </div>
<p>Please wait for other players to finish...</p>
   <p id="result"></p><input type="hidden" id="hdnSession" data-value="<?php echo $_SESSION['id_joc']; ?>" />

<script src="./frontend2.js"></script>
<?php fb(); ?>

</BODY>
</HTML>