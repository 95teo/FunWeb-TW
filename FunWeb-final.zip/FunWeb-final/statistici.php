<?php
session_start();
?>
<DOCTYPE HTML>
    <HEAD>
        <TITLE>
        </TITLE>
         <!--import CSS -->
        <link rel="stylesheet" href="bootstrap-3.3.6\dist\css\bootstrap.min.css">
        <link rel="stylesheet" href="css\statistici.css"> 
        <!-- import JS -->
        <script src="bootstrap-3.3.6/js/tests\vendor/jquery.min.js"></script>
        <script src="bootstrap-3.3.6/dist/js/bootstrap.min.js"></script>
        <!-- import PHP -->
        <?php include'Model/Informatii.php'; ?>
        <?php include'Model/Shared.php'; ?>


    </HEAD>
    <BODY>
        <!-- tabelul cu informatii satistice -->
        <div class="table-responsive">
            <table class="table">
                <tbody>
                   
                    <tr>
                        <td> <b>Number of Single Games  </b></td>
                        <td> <b> <?php echo $single = getNrSingle(); ?></b> </td>
                    </tr>
                    <tr>
                        <td><b>Number of Multi Games</b></td>
                        <td><b><?php echo $multi = getNrMulti(); ?></b></td>
                    </tr>
                    <tr>
                        <td><b>Total number of games</b></td>
                        <td><b><?php echo ( $single + $multi ) ?></b></td>
                    </tr>
                    <tr>
                        <td><b>Last Single Game</b></td>
                        <td><b><?php echo getLastGameDateSingle(); ?></b></td>
                    </tr>
                    <tr>
                        <td><b>Last Multi Game</b></td>
                        <td><b><?php echo getLastGameDateMulti(); ?></b></td>
                    </tr>
                    <b><?php getFromClasamet() ?></b>
		   
                </tbody>
            </table>
        </div
        
    </BODY>
</HTML>