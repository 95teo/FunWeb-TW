<?php
    session_start();
?>
<!DOCTYPE HTML> 
<html lang="en"> 
    <HEAD> 
        <TITLE> 
        </TITLE> 
        <meta charset="utf-8"> 
        <!--import CSS -->
        <link rel="stylesheet" href="bootstrap-3.3.6\dist\css\bootstrap.min.css"> 
        <link href="css/Butoane_domenii.css" rel="stylesheet"> 
        <link rel="stylesheet" href="css\config.css">
        <link rel="stylesheet" href="css\navbar.css">
	<link rel="stylesheet" href="css\w3shools.css">

        <!-- Add jQuery library -->
        <script type="text/javascript" src="fancybox/lib/jquery-1.10.1.min.js"></script>

         
        <script src="js/jQuery/jquery-1.12.3.min.js"></script> 

        <script type="text/javascript" src="js/butoane_domenii.js"></script> 
        <script src="js/jQuery/jquery-1.11.3.min.js"></script>
        
        <script src="js/configurare.js"></script>
	<!-- These are for modals -->
	<script src="bootstrap-3.3.6/js/tests/vendor/jquery.min.js"></script> 
        <script src="bootstrap-3.3.6/dist/js\bootstrap.min.js"></script>
	<!-- These is for auto-suggest -->
	<script src="js/bootstrap-suggest.js"></script>
        <!-- Add fancyBox main JS and CSS files -->
        <script type="text/javascript" src="fancybox/source/jquery.fancybox.js?v=2.1.5"></script>
        <link rel="stylesheet" type="text/css" href="fancybox/source/jquery.fancybox.css?v=2.1.5" media="screen" />

        <!-- Add mousewheel plugin (this is optional) -->
        <script type="text/javascript" src="fancybox/lib/jquery.mousewheel-3.0.6.pack.js"></script>

        <!-- Add Button helper (this is optional) -->
        <link rel="stylesheet" type="text/css" href="fancybox/source/helpers/jquery.fancybox-buttons.css?v=1.0.5" />
        <script type="text/javascript" src="fancybox/source/helpers/jquery.fancybox-buttons.js?v=1.0.5"></script>

        <!-- Add Thumbnail helper (this is optional) -->
        <link rel="stylesheet" type="text/css" href="fancybox/source/helpers/jquery.fancybox-thumbs.css?v=1.0.7" />
        <script type="text/javascript" src="fancybox/source/helpers/jquery.fancybox-thumbs.js?v=1.0.7"></script>

        <!-- Add Media helper (this is optional) -->
        <script type="text/javascript" src="fancybox/source/helpers/jquery.fancybox-media.js?v=1.0.6"></script>
        
        <script type="text/javascript">
            $(document).ready(function () {
                $('.fancybox').fancybox();

                $(".fancybox-effects-b").fancybox({
                    openEffect: 'none',
                    closeEffect: 'none',
                    helpers: {
                        title: {
                            type: 'over'
                        }
                    }
                });
                $(".fancybox-effects-c").fancybox({
                    openEffect: 'none',
                    closeEffect: 'none',
                    helpers: {
                        title: {
                            type: 'over'
                        }
                    }
                });
                $(".fancybox-effects-d").fancybox({
                    openEffect: 'none',
                    closeEffect: 'none',
                    helpers: {
                        title: {
                            type: 'over'
                        }
                    }
                });

                $("#fancybox-manual-b").click(function () {
                    $.fancybox.open({
                        href: 'info.php',
                        type: 'iframe',
                        padding: 5
                    });
                });
                $("#fancybox-manual-c").click(function () {
                    $.fancybox.open({
                        href: 'statistici.php',
                        type: 'iframe',
                        padding: 5
                    });
                });
                $("#fancybox-manual-d").click(function () {
                    $.fancybox.open({
                        href: 'clasament.php',
                        type: 'iframe',
                        padding: 5
                    });
                });


            });
        </script>

        <script src="./frontend.js"></script>

	<!--import PHP -->
        <?php include'Model/Informatii.php'; ?>
        <?php include'Model/Shared.php'; ?> 
        <?php include'Model/MultiJoc.php'; ?> 
        
        

    </HEAD> 
    <BODY> 
         <!-- Bara de navigare -->
        <div>
            <nav class="navbar">
                <div class="container-fluid">
                    <div class="navbar-header ">
                        <a class="navbar-brand" href="menu.php">Fun Web</a>
                    </div>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#" class= "dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user" ></span> <?php echo $_SESSION['my_user'] . "  " ?> </a>
                            <ul class="dropdown-menu">
                                <li><a id="fancybox-manual-b" href="javascript:;">Profile Info </a></li>
                                <li><a id="fancybox-manual-d" href="javascript:;">Clasament</a></li>
                                <li><a id="fancybox-manual-c" href="javascript:;">Statistics</a></li>
                            </ul>
                        </li>

                    </ul>
                </div>
            </nav>
        </div>

        <div id="result" ><p disabled></p></div>
        
        <?php
        createGame();
        ?>
        <!-- jocurile disponibile -->
       <div class="panou">
            <div class="left-panel">
                <div class="container">
                    <div class="panel panel-default"> 
                        <?php
                        	getPartideDeJoc();
                        ?>

                    </div>
                </div>
            </div> 
            
            <!-- formularul de creare a unui joc -->
            <div class="right-panel"> 
                <form id="productForm" method="POST" class="form-horizontal"> 
                    <div class="container" > 

                        <div class="row">
                            <label class="col-xs-3 control-label">Player1</label>
                            <div class="col-sm-6">
                                <div class="input-group">
                                    <input type="text" class="form-control" name="user1" id="player1" placeholder="Choose your oponent">

                                    <div class="input-group-btn">
                                        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                                            <span class="caret"></span>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-right" role="menu">
                                        </ul>
                                    </div>
                                    <!-- /btn-group -->
                                </div>
                            </div>
                        </div> 
                        <br>
                        <div class="row">
                            <label class="col-xs-3 control-label">Player2</label>
                            <div class="col-sm-6">
                                <div class="input-group">
                                    <input type="text" class="form-control" name="user2" id="player2" placeholder="Choose your oponent">

                                    <div class="input-group-btn">
                                        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                                            <span class="caret"></span>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-right" role="menu">
                                        </ul>
                                    </div>
                                    <!-- /btn-group -->
                                </div>
                            </div>
                        </div> 
                        <br> 
                        <div class="form-group"> 
                            <label class="col-xs-3 control-label">Number of questions</label> 
                            <div class="col-xs-6 selectContainer"> 
                                <select class="form-control" name="questions"> 
                                    <option value=10>10</option> 
                                    <option value=15>15</option> 
                                    <option value=20>20</option> 
                                    <option value=25>25</option> 
                                    <option value=30>30</option> 
                                </select> 
                            </div> 
                        </div> 
                    </div> 
                    <div class="container"> 
                        <div class="form-group"> 
                            <div class="row"> 
                                <div class="col-sm-3">
                                    <label class="btn btn-primary"><img src="multimedia\SVG\html.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk1" id="item4" value="val1" class="hidden" autocomplete="off"></label> 
                                </div> 
                                <div class="col-sm-3">
                                    <label class="btn btn-primary"><img src="multimedia\SVG\angular.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk2" id="item4" value="val2" class="hidden" autocomplete="off"></label> 
                                </div> 
                                <div class="col-sm-3">
                                    <label class="btn btn-primary"><img src="multimedia\SVG\php.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk3" id="item4" value="val1" class="hidden" autocomplete="off"></label> 
                                </div> 
                                <div class="col-sm-3">
                                    <label class="btn btn-primary"><img src="multimedia\SVG\css.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk4" id="item4" value="val1" class="hidden" autocomplete="off"></label> 
                                </div> 
                            </div> 
                            <div class="row"> 
                                <div class="col-sm-3">
                                    <label class="btn btn-primary"><img src="multimedia\SVG\ajax.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk5" id="item4" value="val1" class="hidden" autocomplete="off"></label> 
                                </div> 
                                <div class="col-sm-3">
                                    <label class="btn btn-primary"><img src="multimedia\SVG\js.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk6" id="item4" value="val1" class="hidden" autocomplete="off"></label> 
                                </div> 
                                <div class="col-sm-3">
                                    <label class="btn btn-primary"><img src="multimedia\SVG\http.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk7" id="item4" value="val1" class="hidden" autocomplete="off"></label> 
                                </div> 
                                <div class="col-sm-3">
                                    <label class="btn btn-primary"><img src="multimedia\SVG\xml.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk8" id="item4" value="val1" class="hidden" autocomplete="off"></label> 
                                </div> 
                            </div> 
                        </div> 
                        <div class="form-group"> 
                            <div class="col-xs-5 col-xs-offset-3"> 
                                <button type="submit" class="btn btn-primary" name="Create" id="Create">Create Game</button>
                                 
                            </div> 
                        </div> 
                    </div>
            </div>
            



            </div>
       
        <?php
            joinGame();
        ?>

        <script type="text/javascript">
                var testdataBsSuggest = $("#player1,#player2").bsSuggest({
                    indexId: 2,
                    indexKey: 0,
                    data: {
                        'value': [
<?php getOnlineUsers(); ?>
                        ],
                        'defaults': 'http://www.1.com'
                    }
                }).on('onDataRequestSuccess', function (e, result) {
                    console.log('onDataRequestSuccess: ', result);
                }).on('onSetSelectValue', function (e, keyword, data) {
                    console.log('onSetSelectValue: ', keyword, data);
                }).on('onUnsetSelectValue', function (e) {
                    console.log("onUnsetSelectValue");
                });
        </script>
<input type="hidden" id="hdnSession" data-value="<?php echo $_SESSION['id_joc']; ?>" />
    </BODY> 
</HTML>
