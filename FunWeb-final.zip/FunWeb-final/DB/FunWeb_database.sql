-- phpMyAdmin SQL Dump
-- version 4.6.0
-- http://www.phpmyadmin.net
--
-- Host: mysql.unlimitedfunweb.tk
-- Generation Time: Jun 21, 2016 at 11:24 AM
-- Server version: 5.6.25-log
-- PHP Version: 7.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `unlimitedfun_fun`
--

-- --------------------------------------------------------

--
-- Table structure for table `CLASAMENT`
--

CREATE TABLE `CLASAMENT` (
  `USERNAME` varchar(30) NOT NULL DEFAULT '',
  `PUNCTAJ` int(11) DEFAULT NULL,
  `NIVEL` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `CLASAMENT`
--

INSERT INTO `CLASAMENT` (`USERNAME`, `PUNCTAJ`, `NIVEL`) VALUES
('anamaria', 440, 'incepator'),
('andrea', 30, 'incepator'),
('andreea', 60, 'Beginner'),
('cococo', NULL, 'incepator'),
('gabriel', 0, 'incepator'),
('gabriel1', NULL, 'incepator'),
('gfkiller', 50, 'Beginner'),
('Lavi', 245, 'Beginner'),
('Lavinia Maria Tiba', 0, 'beginner'),
('Lucian Dediu', 0, 'beginner'),
('lucifer', 80, 'Beginner'),
('NaN', 0, 'incepator'),
('olalala', 10, 'Beginner'),
('teo595', 250, 'incepator'),
('teo955', 310, 'incepator'),
('Teofil Ursan', 290, 'beginner'),
('undefined', 0, 'incepator'),
('vasi', NULL, 'BEGINNER');

-- --------------------------------------------------------

--
-- Table structure for table `INTREBARI`
--

CREATE TABLE `INTREBARI` (
  `ID_INTREBARE` char(4) NOT NULL DEFAULT '',
  `ENUNT` varchar(500) DEFAULT NULL,
  `VARIANTA_A` varchar(200) DEFAULT NULL,
  `VARIANTA_B` varchar(200) DEFAULT NULL,
  `VARIANTA_C` varchar(200) DEFAULT NULL,
  `VARIANTA_D` varchar(200) DEFAULT NULL,
  `RASPUNS_CORECT` char(1) DEFAULT NULL,
  `DOMENIU` varchar(10) DEFAULT NULL,
  `DIFICULTATE` char(1) DEFAULT NULL,
  `TIMP` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `INTREBARI`
--

INSERT INTO `INTREBARI` (`ID_INTREBARE`, `ENUNT`, `VARIANTA_A`, `VARIANTA_B`, `VARIANTA_C`, `VARIANTA_D`, `RASPUNS_CORECT`, `DOMENIU`, `DIFICULTATE`, `TIMP`) VALUES
('1000', 'Inside which HTML element do we put the JavaScript?', '<js>', '<scripting>', '<script>', '<javascript>', 'C', 'JS', 'e', 5),
('1001', 'Which operator is used to assign a value to a variable?', '*', '-', 'x', '=', 'D', 'JS', 'e', 5),
('1002', 'What is the correct JavaScript syntax to change the content of the HTML element below?   <p id="demo">This is a demonstration.</p>', 'document.getElementById("demo").innerHTML = "Hello', '#demo.innerHTML = "Hello World!";', 'document.getElementByName("p").innerHTML = "Hello ', 'document.getElement("p").innerHTML = "Hello World!', 'A', 'JS', 'm', 8),
('1003', 'What does XML stand for?', 'X-Markup Language', 'eXtra Modern Link', 'Example Markup Language', 'eXtensible Markup Language', 'D', 'XML', 'e', 5),
('1004', 'Where is the correct place to insert a JavaScript?', 'The <body> section', 'The <head> section', 'Both the <head> section and the <body> section are correct', 'None of the options above.', 'C', 'JS', 'e', 5),
('1005', 'What does DTD stand for?', 'Document Type Definition', 'Direct Type Definition', 'Dynamic Type Definition', 'Do The Dance', 'A', 'XML', 'e', 5),
('1006', 'Who is making the Web standards?', 'Mozilla', 'The World Wide Web Consortium', 'Google', 'Microsoft', 'B', 'HTML', 'e', 5),
('1007', 'Choose the correct HTML element for the largest heading:', '<h6>', '<h1>', '<head>', '<heading>', 'B', 'HTML', 'e', 5),
('1008', 'What is the correct HTML for creating a hyperlink?', '<a name="http://www.w3schools.com">W3Schools.com</a>', '<a href="http://www.w3schools.com">W3Schools</a>', '<a url="http://www.w3schools.com">W3Schools.com</a>', '<a>http://www.w3schools.com</a>', 'B', 'HTML', 'm', 8),
('1009', 'What does CSS stand for?', 'Computer Style Sheets', 'Cascading Style Sheets', 'Creative Style Sheets', 'Colorful Style Sheets', 'B', 'CSS', 'e', 5),
('1010', 'Which is the correct CSS syntax?', 'body {color: black;}', 'body:color=black;', '{body:color=black;}', '{body;color:black;}', 'A', 'CSS', 'e', 5),
('1011', 'PHP server scripts are surrounded by delimiters, which one of those under are correct delimiters?', '<?php...?>', '<?php>...</?>', '<&>...</&>', '<script>...</script>', 'A', 'PHP', 'm', 8),
('1012', 'What is the correct way to end a PHP statement?', 'New line ( \\n )', ';', '</php>', '.', 'B', 'PHP', 'e', 5),
('1013', 'What is a correct way to add a comment in PHP?', '/*...*/', '<!--...-->', '*\\...\\*', '<comment>...</comment>', 'A', 'PHP', 'e', 5),
('1014', 'Which operator is used to check if two values are equal and of same data type?', '===', '=', '==', '!=', 'A', 'PHP', 'e', 5),
('1015', 'What is the correct way to include the file "time.inc" ?', '<?php include "time.inc"; ?>', '<?php include:"time.inc"; ?>', '<!-- include file="time.inc" -->', '<?php include file="time.inc"; ?>', 'A', 'PHP', 'm', 8),
('1016', 'What is the correct way to create a function in PHP?', 'new_function myFunction()', 'create myFunction()', 'function myFunction()', 'myfunction myFunction()', 'C', 'PHP', 'm', 8),
('1017', 'What is the correct way to open the file "time.txt" as readable?', 'open("time.txt");', 'fopen("time.txt","r+");', 'fopen("time.txt","r");', 'open("time.txt","read");', 'C', 'PHP', 'h', 12),
('1018', 'Include files must have the file extension ".inc" ?', 'True', 'False', 'Don\'t know', 'That\'s a trap question, dude', 'B', 'PHP', 'm', 8),
('1019', 'Which superglobal variable holds information about headers, paths, and script locations?', '$_GET', '$_GLOBALS', '$_SERVER', '$_SESSION', 'C', 'PHP', 'e', 5),
('1020', 'What does HTML stand for?', 'Home Tool Markup Language', 'Hyper Text Markup Language', 'Hyperlinks and Text Markup Language', 'Hilarious Text Markup Language', 'B', 'HTML', 'e', 5),
('1021', 'Which character is used to indicate an end tag?', '^', '<', '*', '/', 'D', 'HTML', 'e', 5),
('1023', 'How can you make a numbered list?', '<ol>', '<ul>', '<nl>', '<dl>', 'A', 'HTML', 'e', 5),
('1024', 'How can you make a bulleted list?', '<ul>', '<dl>', '<bl>', '<ol>', 'A', 'HTML', 'e', 5),
('1025', 'What is the correct HTML for making a checkbox?', '<input type="check">', '<checkbox>', '<check>', '<input type="checkbox">', 'D', 'HTML', 'm', 8),
('1026', 'Where in an HTML document is the correct place to refer to an external style sheet?', 'At the end of the document', 'In the <body> section', 'In the <head> section', 'After </html> tag', 'C', 'CSS', 'm', 8),
('1027', 'Which HTML attribute is used to define inline styles?', 'font', 'styles', 'style', 'class', 'C', 'CSS', 'm', 8),
('1028', 'How do you insert a comment in a CSS file?', '\' this is a comment \'', '/* this is a comment */', '// this is a comment', '// this is a comment //', 'B', 'CSS', 'm', 8),
('1029', 'Which HTML tag is used to define an internal style sheet?', '<script>', '<css>', '<style>', '<internal style>', 'C', 'CSS', 'm', 8),
('1030', 'What is the correct and complete HTML for referring to an external style sheet?', '<link rel="stylesheet" href="mystyle.css">', '<link rel="stylesheet" type="text/css" src="mystyle.css">', '<css rel="stylesheet" type="text/css" href="mystyle.css">', '<link rel="stylesheet" type="text/css" href="mystyle.css">', 'D', 'CSS', 'h', 12),
('1031', 'Which property is used to change the background color?', 'bgcolor', 'auto-color', 'background-color', 'color-background', 'C', 'CSS', 'e', 5),
('1033', 'Which CSS property is used to change the text color of an element?', 'fgcolor', 'color-text', 'color-of-text', 'text-color', 'D', 'CSS', 'e', 5),
('1034', 'Which CSS property controls the text size?', 'font-style', 'text-style', 'text-size', 'font-size', 'D', 'CSS', 'e', 5),
('1035', 'What is the correct CSS syntax for making all the <p> elements bold?', '<p style="font-size:bold;">', 'p {text-size:bold;}', 'p {font-weight:bold;}', '<p style="text-size:bold;">', 'C', 'CSS', 'h', 12),
('1036', 'How do you display hyperlinks without an underline?', 'a {text-decoration:no-underline;}', 'a {text-decoration:none;}', 'a {underline:none;}', 'a {decoration:no-underline;}', 'B', 'CSS', 'm', 8),
('1037', 'How do you make each word in a text start with a capital letter?', 'text-transform:uppercase', 'text-transform:capitalize', 'You can\'t do that with CSS', 'text-transformation:capitalize', 'B', 'CSS', 'm', 8),
('1038', 'Which property is used to change the left margin of an element?', 'indent-left', 'margin-left', 'padding-left', 'set-margin-left', 'B', 'CSS', 'm', 8),
('1039', 'How do you select an element with id "demo"?', '.demo', 'demo', '*demo', '#demo', 'D', 'CSS', 'm', 8),
('1040', 'How do you select elements with class name "test"?', '#test', '*test', '.test', 'test', 'C', 'CSS', 'm', 8),
('1041', 'What is the correct syntax for referring to an external script called "xxx.js"?', '<script src="xxx.js">', '<script name="xxx.js">', '<script href="xxx.js">', '<script url="xxx.js">', 'A', 'JS', 'E', 5),
('1042', 'How do you write "Hello World" in an alert box?', '  msg("Hello World");', '  msgBox("Hello World");', '  alertBox("Hello World");', '  alert("Hello World");', 'C', 'JS', 'E', 5),
('1043', 'How do you create a function in JavaScript?', 'function = myFunction()', 'function:myFunction()', 'function myFunction()', 'myFunction()', 'C', 'JS', 'E', 5),
('1044', 'How do you call a function named "myFunction"?', 'call function myFunction()', 'call myFunction()', 'myFunction()', 'function myFunction()', 'C', 'JS', 'M', 8),
('1045', 'How to write an IF statement in JavaScript?', 'if i = 5 then', 'if (i == 5)', 'if i == 5 then', 'if i = 5', 'C', 'JS', 'M', 8),
('1046', 'How to write an IF statement for executing some code if "i" is NOT equal to 5?', 'if (i != 5)', 'if i =! 5 then', 'if (i <> 5)', 'if i <> 5', 'A', 'JS', 'M', 8),
('1047', 'How does a WHILE loop start?', 'while (i <= 10)', 'while (i <= 10; i++)', 'while i = 1 to 10', 'while i=10', 'A', 'JS', 'M', 8),
('1048', 'How does a FOR loop start?', 'for i = 1 to 5', 'for (i = 0; i <= 5; i++)', 'for (i <= 5; i++)', 'for (i = 0; i <= 5)', 'B', 'JS', 'M', 8),
('1049', 'How can you add a comment in a JavaScript?', '<!--This is a comment-->', '//This is a comment', '\'This is a comment', '/*This is a comment', 'B', 'JS', 'E', 5),
('1050', 'What is the correct way to write a JavaScript array?', 'var colors = 1 = ("red"), 2 = ("green"), 3 = ("blue")', 'var colors = "red", "green", "blue"', 'var colors = (1:"red", 2:"green", 3:"blue")', 'var colors = ["red", "green", "blue"]', 'D', 'JS', 'M', 8),
('1051', 'How do you round the number 7.25, to the nearest integer?', 'rnd(7.25)', 'Math.rnd(7.25)', 'Math.round(7.25)', 'round(7.25)', 'D', 'JS', 'H', 12),
('1052', 'What is the correct JavaScript syntax for opening a new window called "w2"?', 'w2 = window.new("http://www.w3schools.com");', 'w2 = window.open("http://www.w3schools.com");', 'w2=window.fopen("http://www.w3schools.com");', 'w2=window("http://www.w3schools.com");', 'B', 'JS', 'M', 8),
('1053', 'Which event occurs when the user clicks on an HTML element?', 'onclick', 'onchange', 'onmouseover', 'onmouseclick', 'A', 'JS', 'H', 12),
('1054', 'How do you declare a JavaScript variable?', 'v carName;', 'var carName;', 'variable carName;', '$carName;', 'B', 'JS', 'M', 8),
('1055', 'What is the correct CSS syntax for making all the <p> elements bold?', 'p {text-size:bold;}', '<p style="text-size:bold;">', '<p style="font-size:bold;">', 'p {font-weight:bold;}', 'D', 'CSS', 'M', 8),
('1056', 'How do you display hyperlinks without an underline?', 'a {decoration:no-underline;}', 'a {text-decoration:none;}', 'a {underline:none;}', 'a {text-decoration:no-underline;}', 'C', 'CSS', 'H', 12),
('1057', 'Which CSS property controls the text size?', 'text-style', 'font-style', 'text-size', 'font-size', 'D', 'CSS', 'M', 8),
('1058', 'How do you display a border like this:\r\nThe top border = 10 pixels\r\nThe bottom border = 5 pixels\r\nThe left border = 20 pixels\r\nThe right border = 1pixel?\r\n', 'border-width:10px 20px 5px 1px;', 'border-width:5px 20px 10px 1px;', 'border-width:10px 5px 20px 1px;', 'border-width:10px 1px 5px 20px;', 'C', 'CSS', 'H', 12),
('1059', 'How do you select an element with id "demo"?', 'demo', '*demo', '#demo', '.demo', 'C', 'CSS', 'E', 5),
('1060', 'There is a way of describing XML data, how?', 'XML uses a description node to describe data', 'XML uses a DTD to describe the data', 'XML uses XSL to describe data', 'XML uses a node to describe data ', 'B', 'XML', 'M', 8),
('1061', 'Which statement is true?', 'All the statements are true', 'All XML elements must be properly closed', 'All XML elements must be lower case', 'All XML documents must have a DTD', 'D', 'XML', 'M', 8),
('1062', 'Which statement is true?', 'XML tags are case sensitive', 'XML documents must have a root tag', 'All the statements are true', 'XML elements must be properly nested', 'B', 'XML', 'M', 8),
('1063', 'Which is not a correct name for an XML element?', '<h1>', '<Note>', '<1dollar>', '  All 3 names are incorrect', 'D', 'XML', 'H', 12),
('1064', 'What does XSL stand for?', 'eXtensible Stylesheet Language', 'eXtra Style Language', 'eXpandable Style Language', 'eXtensible Style Listing', 'A', 'XML', 'E', 5),
('1065', 'For the XML parser to ignore a certain section of your XML document, which syntax is correct?', '<PCDATA> Text to be ignored </PCDATA>', '<CDATA> Text to be ignored </CDATA>', '<xml:CDATA[ Text to be ignored ]>', '<![CDATA[ Text to be ignored ]]>', 'D', 'XML', 'M', 8),
('1066', 'What are XML entities used for?', 'Entities define shortcuts to standard text or special characters.', 'Entities define shortcuts to standard attributes.', 'Entities define shortcuts to standard elements', 'Entities define shortcut', 'C', 'XML', 'M', 8),
('1067', 'What is a correct way of referring to a stylesheet called "mystyle.xsl" ?', '<link type="text/xsl" href="mystyle.xsl" />', '<stylesheet type="text/xsl" href="mystyle.xsl" />', '<?xml-stylesheet type="text/xsl" href="mystyle.xsl" ?>', '<?xml-stylesheet href="mystyle.xsl" ?>', 'C', 'XML', 'H', 12),
('1068', 'Which XML DOM object represents a node in the node tree?', 'The document object', 'The node object', 'The nodeList object', 'The entities object', 'A', 'XML', 'H', 12),
('1069', 'What is an XML instance?', 'An XML element', 'An XML attribute', 'An XML document', 'An XML entities', 'A', 'XML', 'E', 5),
('1070', 'Which statement is true?', 'Both statements are true', 'Attributes must always be present', 'None of the statements are true', 'Attributes must occur in defined order', 'A', 'XML', 'M', 5),
('1071', 'Choose the correct HTML element to define important text:', '<strong>', '<b>', '<important>', '<i>', 'A', 'html', 'E', 5),
('1072', 'How can you open a link in a new tab/browser window?', '<a href="url" new>', '<a href="url" target="_blank">', '<a href="url" target="new">', '<a href="url">', 'C', 'HTML', 'M', 8),
('1073', 'What is the correct HTML for making a text input field?', '<input type="textfield">', '<textinput type="text">', '<textfield>', '<input type="text">', 'D', 'HTML', 'M', 8),
('1074', 'What is the correct HTML for making a drop-down list?', '<select>', '<input type="dropdown">', '<list>', '<input type="list">', 'B', 'HTML', 'H', 12),
('1075', 'What is the correct HTML for making a text area?', '<input type="textbox">', '<input type="textarea">', '<textarea>', '<input type="text">', 'C', 'HTML', 'M', 8),
('1076', 'What is the correct HTML for inserting an image?', '<image src="image.gif" alt="MyImage">', '<img href="image.gif" alt="MyImage">', '<img src="image.gif" alt="MyImage">', '<img alt="MyImage">image.gif</img>', 'C', 'HTML', 'M', 8),
('1077', 'What is the correct HTML for inserting a background image?', '<background img="background.gif">', '<body bg="background.gif">', '<body style="background-image:url(background.gif)">', '<body ="background.gif">', 'C', 'HTML', 'H', 12),
('1078', 'What is the correct HTML for adding a background color?', '<background>yellow</background>', '<body bg="yellow">', '<body style="background-color:yellow;">', '<body-style="yellow">', 'C', 'HTML', 'M', 8),
('1079', 'How do you get information from a form that is submitted using the "get" method?', '$_GET[];', 'Request.Form;', 'Request.QueryString;', 'Request;', 'A', 'PHP', 'M', 8);

-- --------------------------------------------------------

--
-- Table structure for table `JOC_SINGLE`
--

CREATE TABLE `JOC_SINGLE` (
  `ID_JOC` int(11) NOT NULL,
  `USER` varchar(30) DEFAULT NULL,
  `DOMENII_ALESE` varchar(500) DEFAULT NULL,
  `NR_INTREBARI` int(11) DEFAULT NULL,
  `PUNCTAJ` int(11) DEFAULT NULL,
  `DATA_JOC` timestamp NULL DEFAULT NULL,
  `DURATA` int(11) DEFAULT NULL,
  `INTREBARI` varchar(600) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `JOC_SINGLE`
--

INSERT INTO `JOC_SINGLE` (`ID_JOC`, `USER`, `DOMENII_ALESE`, `NR_INTREBARI`, `PUNCTAJ`, `DATA_JOC`, `DURATA`, `INTREBARI`) VALUES
(1, 'vasi', 'html,angular,php,css', 10, NULL, NULL, NULL, ','),
(2, 'vasi', 'ajax,js,http,xml', 10, NULL, NULL, NULL, NULL),
(3, 'vasi', 'ajax,js,http,xml', 30, NULL, NULL, NULL, ','),
(4, 'vasi', 'html,angular,php,ajax,js,xml', 10, NULL, NULL, NULL, ','),
(5, 'vasi', 'html,ajax', 10, NULL, NULL, NULL, '1078,1025,1073,1074,1072,1071,1007,1075,1006,1077'),
(6, 'vasi', 'html,angular', 10, 0, NULL, NULL, '1075,1076,1021,1007,1073,1078,1077,1024,1074,1022'),
(7, 'vasi', 'html,angular,php,css', 10, 0, NULL, NULL, '1009,1035,1074,1019,1008,1007,1029,1021,1016,1057'),
(8, 'vasi', 'html,ajax', 10, NULL, NULL, NULL, '1023,1008,1025,1007,1077,1006,1076,1021,1072,1074'),
(9, 'vasi', 'ajax,js,http,xml', 10, NULL, NULL, NULL, '1060,1044,1048,1047,1066,1049,1053,1051,1042,1001'),
(10, 'vasi', 'html,angular,php', 15, NULL, NULL, NULL, '1076,1023,1075,1017,1024,1071,1014,1013,1079,1012,1020,1018,1015,1011,1022'),
(11, 'vasi', 'html,angular,php,css', 10, NULL, NULL, NULL, '1026,1077,1059,1021,1035,1015,1006,1028,1007,1016'),
(13, 'Teofil Ursan', 'html,angular,php', 25, NULL, NULL, NULL, '1079,1025,1074,1071,1018,1008,1016,1014,1017,1077,1076,1073,1011,1022,1021,1015,1024,1006,1013,1072'),
(14, 'vasi', 'html,angular,php,css', 10, NULL, NULL, NULL, '1035,1038,1057,1021,1078,1039,1011,1025,1010,1036'),
(15, 'vasi', 'html,angular,php,css', 10, NULL, NULL, NULL, '1031,1040,1079,1011,1016,1035,1027,1059,1017,1020'),
(16, 'vasi', 'html,angular,css', 10, NULL, NULL, NULL, '1074,1073,1078,1022,1077,1029,1058,1009,1030,1035'),
(17, 'vasi', 'html,js,http,xml', 10, NULL, NULL, NULL, '1023,1001,1070,1043,1044,1047,1063,1078,1006,1045'),
(18, 'vasi', 'html,angular,php,css', 10, NULL, NULL, NULL, '1012,1056,1057,1011,1010,1058,1006,1073,1035,1036'),
(19, 'vasi', 'html,angular,php,css', 10, NULL, NULL, NULL, '1078,1056,1024,1027,1007,1077,1072,1032,1013,1058'),
(20, 'vasi', 'html,php,js', 10, NULL, NULL, NULL, '1013,1046,1075,1049,1071,1017,1079,1025,1002,1072'),
(21, 'vasi', 'html,angular,css', 10, NULL, NULL, NULL, '1056,1027,1009,1024,1076,1077,1058,1059,1078,1021'),
(22, 'vasi', 'html,angular,php', 10, NULL, NULL, NULL, '1075,1007,1079,1072,1016,1077,1006,1025,1018,1024'),
(23, 'vasi', 'html,angular,php,css', 10, NULL, NULL, NULL, '1020,1022,1018,1015,1072,1076,1038,1024,1007,1078'),
(24, 'vasi', 'html,angular,php', 10, NULL, NULL, NULL, '1014,1013,1007,1011,1078,1075,1019,1017,1021,1073'),
(25, 'vasi', 'html,angular', 10, NULL, NULL, NULL, '1021,1074,1078,1077,1071,1073,1023,1022,1024,1025'),
(26, 'vasi', 'html,angular,php', 10, NULL, NULL, NULL, '1073,1024,1014,1017,1012,1006,1023,1020,1021,1016'),
(27, 'vasi', 'html,angular,php', 10, NULL, NULL, NULL, '1021,1076,1078,1006,1074,1022,1014,1016,1073,1020'),
(28, 'vasi', 'html,angular', 10, NULL, NULL, NULL, '1078,1006,1007,1072,1074,1008,1025,1022,1076,1024'),
(29, 'vasi', 'html,angular,css', 10, NULL, NULL, NULL, '1020,1035,1033,1008,1077,1029,1030,1023,1040,1032'),
(30, 'vasi', 'html,angular,css', 10, NULL, NULL, NULL, '1077,1007,1078,1024,1072,1055,1058,1056,1073,1031'),
(31, 'vasi', 'html,angular,php', 10, NULL, NULL, NULL, '1073,1008,1013,1074,1018,1015,1024,1072,1025,1006'),
(32, 'vasi', 'html,angular,js', 10, NULL, NULL, NULL, '1000,1021,1052,1020,1074,1008,1042,1049,1044,1025'),
(33, 'vasi', 'html,angular', 10, NULL, NULL, NULL, '1020,1024,1022,1007,1021,1076,1025,1074,1023,1078'),
(34, 'vasi', 'html,angular,php', 10, NULL, NULL, NULL, '1007,1071,1019,1075,1022,1079,1014,1020,1012,1016'),
(35, 'vasi', 'html,angular,php,css', 10, NULL, NULL, NULL, '1077,1010,1021,1020,1076,1037,1029,1019,1034,1023'),
(36, 'Lavi', 'html,angular,php,css', 15, NULL, NULL, NULL, '1074,1025,1006,1035,1021,1033,1007,1055,1057,1078'),
(37, 'lucifer', 'html,angular,php,css,js,http,ajax,xml', 10, NULL, NULL, NULL, '1076,1064,1039,1069,1002,1029,1047,1055,1017,1011'),
(38, 'lucifer', 'js', 10, NULL, NULL, NULL, NULL),
(39, 'vasi', 'html,angular,php', 10, NULL, NULL, NULL, '1014,1075,1018,1071,1006,1024,1074,1079,1008,1019'),
(40, 'vasi', 'html,angular,php', 10, NULL, NULL, NULL, '1073,1022,1079,1006,1078,1075,1076,1017,1074,1018'),
(41, 'Teofil Ursan', 'html,angular,ajax,js,http', 20, NULL, NULL, NULL, NULL),
(42, 'Teofil Ursan', 'html,angular,ajax,js,http', 10, NULL, NULL, NULL, '1023,1048,1004,1020,1041,1024,1047,1076,1000,1046'),
(43, 'vasi', 'html,angular', 10, NULL, NULL, NULL, '1023,1006,1073,1020,1024,1071,1025,1075,1077,1022'),
(44, 'vasi', 'html,angular,css', 10, NULL, NULL, NULL, '1037,1076,1056,1058,1038,1034,1031,1040,1029,1078'),
(45, 'vasi', 'html,angular,php', 10, NULL, NULL, NULL, '1021,1073,1074,1072,1071,1022,1079,1076,1019,1012'),
(46, NULL, 'html,angular,php,css,ajax', 15, NULL, NULL, NULL, NULL),
(47, NULL, 'html,angular,php,css,js,http,xml', 10, NULL, NULL, NULL, NULL),
(48, 'Teofil Ursan', 'html,php', 10, NULL, NULL, NULL, '1007,1078,1006,1014,1017,1079,1020,1012,1076,1013'),
(49, NULL, 'html,angular,php,css', 10, NULL, NULL, NULL, NULL),
(50, 'Teofil Ursan', 'html,angular,php,css', 10, NULL, NULL, NULL, '1073,1020,1007,1022,1032,1055,1018,1074,1017,1009'),
(51, 'Teofil Ursan', 'html,angular,ajax', 10, NULL, NULL, NULL, '1076,1078,1006,1025,1075,1077,1072,1020,1071,1022'),
(52, 'Teofil Ursan', 'html,ajax,js', 10, NULL, NULL, NULL, '1075,1008,1046,1007,1002,1074,1004,1022,1049,1045'),
(53, 'Teofil Ursan', 'html,angular,ajax,js', 10, NULL, NULL, NULL, '1078,1072,1006,1008,1053,1000,1023,1001,1041,1044'),
(54, 'Teofil Ursan', 'html,angular,ajax', 10, NULL, NULL, NULL, '1024,1022,1072,1008,1078,1023,1073,1071,1007,1025'),
(55, 'Teofil Ursan', 'html,angular,ajax,js', 10, NULL, NULL, NULL, '1075,1002,1048,1047,1044,1023,1000,1049,1008,1054'),
(56, 'Teofil Ursan', 'html,angular,js', 10, NULL, NULL, NULL, '1071,1024,1051,1078,1000,1004,1002,1044,1001,1045'),
(57, 'Teofil Ursan', 'html,angular,ajax,js', 10, NULL, NULL, NULL, '1073,1022,1078,1025,1020,1042,1049,1007,1044,1071'),
(58, 'vasi', 'html,angular,php', 10, NULL, NULL, NULL, '1006,1025,1015,1020,1076,1021,1012,1007,1079,1011'),
(59, 'Teofil Ursan', 'html,angular,php', 10, NULL, NULL, NULL, '1007,1077,1074,1013,1006,1076,1016,1075,1019,1025'),
(60, 'Teofil Ursan', 'angular,php,css', 10, NULL, NULL, NULL, '1016,1033,1030,1056,1009,1017,1011,1032,1035,1039'),
(61, 'Teofil Ursan', 'html,angular,php', 10, NULL, NULL, NULL, '1074,1012,1024,1007,1014,1008,1006,1021,1078,1015'),
(62, 'Teofil Ursan', 'angular,php', 10, NULL, NULL, NULL, '1014,1015,1079,1018,1016,1012,1011,1017,1013,1019'),
(63, 'vasi', 'html,angular,php,css', 10, NULL, NULL, NULL, '1078,1037,1027,1076,1006,1015,1011,1008,1017,1018'),
(64, 'vasi', 'html,angular,php,css', 10, NULL, NULL, NULL, '1034,1031,1071,1013,1036,1010,1072,1019,1058,1056'),
(65, 'vasi', 'html,angular', 10, NULL, NULL, NULL, '1078,1024,1077,1021,1074,1076,1075,1072,1023,1007'),
(66, 'vasi', 'html,angular,php', 10, NULL, NULL, NULL, '1025,1008,1011,1018,1071,1021,1014,1075,1073,1023'),
(67, 'vasi', 'html,angular,php', 10, NULL, NULL, NULL, '1015,1024,1014,1079,1073,1020,1074,1078,1021,1012'),
(68, 'vasi', 'html,angular', 10, NULL, NULL, NULL, '1078,1075,1023,1072,1074,1024,1007,1008,1006,1076'),
(69, 'vasi', 'html,angular,php', 10, NULL, NULL, NULL, '1075,1024,1079,1014,1076,1023,1020,1012,1011,1016'),
(70, 'vasi', 'html', 10, NULL, NULL, NULL, '1007,1073,1078,1077,1021,1023,1008,1075,1071,1024'),
(71, 'vasi', 'html,angular', 10, NULL, NULL, NULL, '1021,1025,1073,1076,1023,1020,1075,1071,1077,1074'),
(72, 'vasi', 'html,angular', 10, 40, NULL, NULL, '1020,1077,1072,1074,1025,1075,1024,1007,1071,1023'),
(73, 'vasi', 'html,angular', 10, 20, NULL, NULL, '1073,1077,1008,1025,1075,1076,1074,1072,1071,1006'),
(74, 'vasi', 'php,css,xml', 10, 75, NULL, NULL, '1014,1018,1069,1060,1057,1015,1027,1010,1070,1065'),
(75, 'anamaria', 'html,php,css', 10, 50, NULL, NULL, '1012,1055,1017,1031,1006,1038,1009,1010,1013,1008'),
(76, 'anamaria', 'html,angular,php,js,http', 10, 0, NULL, NULL, NULL),
(77, 'vasi', 'html,angular,php,css', 10, 40, NULL, NULL, '1009,1031,1071,1033,1055,1008,1075,1014,1059,1023'),
(78, 'Teofil Ursan', 'html,css', 10, 10, NULL, NULL, '1055,1072,1030,1025,1075,1028,1035,1009,1071,1078'),
(79, 'Teofil Ursan', 'html', 10, 65, NULL, NULL, '1006,1072,1025,1008,1020,1007,1075,1076,1071,1074'),
(80, 'Teofil Ursan', 'html', 10, 45, NULL, NULL, '1078,1024,1073,1006,1025,1074,1076,1020,1008,1077'),
(81, 'Teofil Ursan', 'html', 10, 45, NULL, NULL, '1071,1077,1076,1020,1078,1075,1073,1023,1025,1024'),
(82, 'Teofil Ursan', 'html', 10, 50, NULL, NULL, '1075,1021,1078,1074,1071,1072,1006,1025,1007,1077'),
(83, 'Teofil Ursan', 'html', 10, 75, NULL, NULL, '1023,1077,1008,1074,1078,1075,1006,1073,1024,1020'),
(84, 'Teofil Ursan', 'html', 10, 70, NULL, NULL, '1023,1078,1024,1071,1074,1020,1077,1075,1073,1025'),
(85, 'vasi', 'html,angular,php,css,xml', 10, 10, NULL, NULL, '1076,1026,1067,1035,1009,1020,1034,1066,1007,1010'),
(86, 'Teofil Ursan', 'html', 10, 110, NULL, NULL, '1071,1073,1025,1008,1076,1006,1072,1023,1074,1075'),
(87, 'cococo', 'html', 10, 60, NULL, NULL, '1024,1077,1073,1078,1076,1074,1008,1071,1072,1006'),
(88, 'cococo', 'html,angular', 10, 0, NULL, NULL, NULL),
(89, 'Teofil Ursan', 'html', 10, 50, NULL, NULL, '1073,1006,1020,1021,1023,1075,1074,1076,1078,1007'),
(90, 'vasi', 'html,php,css', 10, 15, NULL, NULL, '1027,1078,1016,1031,1035,1040,1055,1028,1025,1072'),
(91, 'Teofil Ursan', 'html', 10, 100, NULL, NULL, '1077,1023,1024,1021,1007,1008,1025,1071,1073,1020'),
(92, 'Teofil Ursan', 'html', 10, 0, NULL, NULL, '1008,1071,1023,1025,1075,1020,1078,1024,1006,1021'),
(93, 'Teofil Ursan', 'html', 10, 0, NULL, NULL, '1006,1020,1078,1025,1072,1023,1007,1074,1021,1075'),
(94, 'Teofil Ursan', 'html', 10, 60, NULL, NULL, '1007,1021,1025,1006,1077,1076,1078,1075,1023,1071'),
(95, 'Teofil Ursan', 'html', 10, 20, NULL, NULL, '1020,1078,1072,1076,1071,1073,1006,1077,1024,1007'),
(96, 'Teofil Ursan', 'html,angular,php,css,js,http,ajax,xml', 10, 50, NULL, NULL, '1007,1072,1064,1079,1056,1073,1065,1050,1058,1059'),
(97, 'vasi', 'html,angular,php,css', 10, 20, NULL, NULL, '1072,1031,1010,1027,1006,1013,1055,1071,1033,1035'),
(98, 'vasi', 'html,angular,php,css', 10, 70, NULL, NULL, '1013,1025,1056,1021,1010,1059,1012,1077,1006,1078'),
(99, 'cococo', 'html,angular,php', 10, 45, NULL, NULL, '1071,1023,1078,1074,1025,1015,1011,1021,1077,1006'),
(100, 'Teofil Ursan', 'html', 10, 0, NULL, NULL, '1072,1008,1071,1075,1074,1073,1007,1076,1021,1025'),
(101, 'Teofil Ursan', 'html', 10, 30, NULL, NULL, '1077,1074,1076,1071,1021,1075,1024,1078,1007,1006'),
(102, 'Lavi', 'html,php,css', 10, 0, NULL, NULL, NULL),
(103, 'gabriel1', 'html,php', 10, 20, NULL, NULL, '1017,1006,1016,1024,1078,1008,1019,1013,1011,1077'),
(104, 'teo955', 'html,angular,php,css,js,http,ajax,xml', 10, 110, NULL, NULL, '1048,1072,1043,1016,1066,1079,1052,1027,1050,1071'),
(105, 'teo595', 'html,php', 10, 55, NULL, NULL, '1006,1075,1077,1019,1007,1016,1013,1024,1073,1074'),
(106, NULL, 'html,php', 10, 0, NULL, NULL, NULL),
(107, NULL, 'html,php', 10, 0, NULL, NULL, NULL),
(108, NULL, 'html,php,css', 10, 0, NULL, NULL, NULL),
(109, 'Lavi', 'html,php,css', 10, 0, NULL, NULL, '1014,1055,1023,1006,1031,1075,1030,1037,1057,1078'),
(110, 'Teofil Ursan', 'html,php', 10, 120, NULL, NULL, '1076,1007,1016,1015,1008,1014,1072,1013,1017,1079'),
(111, 'Teofil Ursan', 'html,php,css', 10, 65, NULL, NULL, '1059,1077,1028,1038,1031,1074,1010,1011,1013,1026'),
(112, 'lucifer', 'html,angular,php,css,js,http,ajax,xml', 10, 0, NULL, NULL, '1030,1000,1051,1059,1031,1014,1069,1077,1003,1033');

-- --------------------------------------------------------

--
-- Table structure for table `PARTIDE_DE_JOC`
--

CREATE TABLE `PARTIDE_DE_JOC` (
  `ID_JOC` int(11) NOT NULL,
  `USER1` varchar(30) DEFAULT NULL,
  `USER2` varchar(30) DEFAULT NULL,
  `JOIN_USER2` int(11) DEFAULT NULL,
  `USER3` varchar(30) DEFAULT NULL,
  `JOIN_USER3` int(11) DEFAULT NULL,
  `CASTIGATORI` char(3) DEFAULT NULL,
  `DOMENII_ALESE` varchar(500) DEFAULT NULL,
  `NR_INTREBARI` int(11) DEFAULT NULL,
  `PUNCTAJ_USER1` int(11) DEFAULT NULL,
  `PUNCTAJ_USER2` int(11) DEFAULT NULL,
  `PUNCTAJ_USER3` int(11) DEFAULT NULL,
  `DATA_JOC` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DURATA` int(11) DEFAULT NULL,
  `STATUS_JOC` varchar(20) DEFAULT NULL,
  `intrebari` varchar(500) DEFAULT NULL,
  `CORECTE_1` int(11) DEFAULT NULL,
  `CORECTE_2` int(11) DEFAULT NULL,
  `CORECTE_3` int(11) DEFAULT NULL,
  `final_user1` int(11) DEFAULT '0',
  `final_user2` int(11) DEFAULT NULL,
  `final_user3` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `PARTIDE_DE_JOC`
--

INSERT INTO `PARTIDE_DE_JOC` (`ID_JOC`, `USER1`, `USER2`, `JOIN_USER2`, `USER3`, `JOIN_USER3`, `CASTIGATORI`, `DOMENII_ALESE`, `NR_INTREBARI`, `PUNCTAJ_USER1`, `PUNCTAJ_USER2`, `PUNCTAJ_USER3`, `DATA_JOC`, `DURATA`, `STATUS_JOC`, `intrebari`, `CORECTE_1`, `CORECTE_2`, `CORECTE_3`, `final_user1`, `final_user2`, `final_user3`) VALUES
(48, 'vasi', '?', NULL, '?', NULL, NULL, 'html,angular,ajax,js', 10, 0, 0, 0, '2016-06-20 20:22:44', NULL, 'FINISHED', '1046,1048,1021,1042,1024,1072,1071,1076,1073,1043', 0, 0, 0, NULL, NULL, NULL),
(49, 'vasi', '?', NULL, '?', NULL, NULL, 'html,angular,php', 10, 20, 0, 0, '2016-06-20 20:23:26', NULL, 'FINISHED', '1078,1024,1016,1018,1014,1007,1006,1019,1076,1079', 2, 0, 0, NULL, NULL, NULL),
(50, 'vasi', '?', NULL, '?', NULL, NULL, 'html,angular,php', 10, 45, 0, 0, '2016-06-20 21:05:28', NULL, 'FINISHED', '1019,1012,1015,1018,1078,1006,1007,1017,1079,1014', 3, 0, 0, NULL, NULL, NULL),
(51, 'anamaria', '?', NULL, '?', NULL, NULL, 'html,angular,php,css', 10, 20, 0, 0, '2016-06-21 01:42:14', NULL, 'FINISHED', '1030,1013,1026,1078,1012,1055,1035,1072,1023,1040', 2, 0, 0, 0, 1, 1),
(58, 'vasi', 'anamaria', 1, 'Teofil Ursan', 1, NULL, 'html,angular,php,css', 10, 45, 45, 10, '2016-06-21 02:03:04', NULL, 'FINISHED', '1057,1010,1075,1033,1014,1011,1023,1037,1078,1030', 4, 4, 1, 3, 1, 1),
(59, 'teo955', NULL, 1, 'gabriel1', 1, NULL, 'html,php,css', 10, 55, 0, 40, '2016-06-21 03:46:22', NULL, 'FINISHED', '1028,1014,1072,1030,1079,1013,1075,1009,1031,1006', 4, 0, 3, 3, NULL, NULL),
(60, 'teo595', 'anamaria', 1, 'vasi', 1, NULL, 'html,php,css', 10, 0, 40, 10, '2016-06-21 03:58:17', NULL, 'FINISHED', '1009,1058,1023,1073,1076,1012,1055,1079,1057,1034', 0, 3, 1, 3, NULL, NULL),
(64, 'teo595', 'vasi', 1, 'anamaria', 1, NULL, 'html,php,css', 10, 35, 10, 0, '2016-06-21 05:22:16', NULL, 'FINISHED', '1033,1059,1040,1020,1030,1035,1014,1008,1056,1055', 3, 1, 0, 3, NULL, NULL),
(65, 'teo595', 'vasi', 1, 'anamaria', 1, NULL, 'html,php,css', 10, 30, 50, 35, '2016-06-21 05:26:49', NULL, 'FINISHED', '1015,1077,1079,1055,1033,1009,1020,1036,1021,1012', 2, 4, 2, 3, NULL, NULL),
(67, 'anamaria', 'teo595', 1, 'teo955', 1, NULL, 'html,angular,php,css,js,http,ajax,xml', 10, 40, 0, 30, '2016-06-21 05:38:21', NULL, 'FINISHED', '1077,1039,1037,1044,1016,1078,1019,1071,1068,1020', 2, 0, 2, 9, NULL, NULL),
(68, 'anamaria', 'teo955', 1, 'teo595', 1, NULL, 'html,angular,php,css,js,http,ajax,xml', 10, 60, 25, 45, '2016-06-21 05:41:27', NULL, 'FINISHED', '1075,1059,1055,1023,1051,1027,1030,1028,1004,1007', 3, 2, 3, 26, NULL, NULL),
(69, 'anamaria', 'teo595', 1, 'teo955', 1, NULL, 'html,angular,php,css,js,http,ajax,xml', 10, 40, 40, 60, '2016-06-21 05:44:12', NULL, 'FINISHED', '1075,1050,1077,1042,1005,1009,1046,1010,1049,1074', 3, 2, 4, 10, NULL, NULL),
(70, 'Lavi', '?', NULL, '?', NULL, NULL, 'html,angular,php,css,js,http,ajax,xml', 10, 80, 0, 0, '2016-06-21 06:09:55', NULL, 'FINISHED', '1069,1064,1001,1011,1000,1002,1006,1031,1071,1036', 5, 0, 0, 1, NULL, NULL),
(71, 'Teofil Ursan', 'anamaria', 1, 'Lavi', 1, NULL, 'html,php,css', 10, 75, 0, 0, '2016-06-21 07:31:54', NULL, 'FINISHED', '1026,1017,1021,1006,1055,1071,1019,1038,1037,1023', 5, 0, 0, 3, NULL, NULL),
(72, 'anamaria', 'Teofil Ursan', 1, 'Lavi', 1, NULL, 'html,angular,php,css,js,http,ajax,xml', 10, 20, 30, 25, '2016-06-21 07:34:37', NULL, 'FINISHED', '1058,1030,1079,1007,1038,1039,1037,1054,1018,1021', 1, 2, 2, 17, NULL, NULL),
(73, 'anamaria', '?', NULL, '?', NULL, NULL, 'html,angular', 10, 0, 0, 0, '2016-06-21 08:06:06', NULL, 'WAITING', '1025,1024,1023,1071,1021,1073,1074,1072,1076,1020', 0, 0, 0, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `UTILIZATORI`
--

CREATE TABLE `UTILIZATORI` (
  `NUME` varchar(30) DEFAULT NULL,
  `PRENUME` varchar(30) DEFAULT NULL,
  `DATA_NASTERE` date DEFAULT NULL,
  `USERNAME` varchar(30) NOT NULL DEFAULT '',
  `PAROLA` varchar(20) DEFAULT NULL,
  `EMAIL` varchar(30) DEFAULT NULL,
  `STATUS` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `UTILIZATORI`
--

INSERT INTO `UTILIZATORI` (`NUME`, `PRENUME`, `DATA_NASTERE`, `USERNAME`, `PAROLA`, `EMAIL`, `STATUS`) VALUES
('', 'ddd', '0000-00-00', 'anamaria', '12345', 'ana@yahoo.com', 'INDISPONIBIL'),
(NULL, NULL, NULL, 'andrea', 'pisi', 'andreeaandro19@gmail.com', NULL),
(NULL, NULL, NULL, 'andreea', 'pisica', 'andreeaandro19@gmail.com', NULL),
(NULL, NULL, NULL, 'bla', 'bla', 'bla', NULL),
(NULL, NULL, NULL, 'claudiu', '123', 'clau@gmail.com', 'INDISPONIBIL'),
('', '', '0000-00-00', 'cococo', '12345678', 'coco@yahoo.com', 'INDISPONIBIL'),
(NULL, NULL, NULL, 'elena', '123', 'ele@gmail.com', 'DISPONIBIL'),
(NULL, NULL, NULL, 'gabriel', '12345677', 'gabriel95@yahoo.com', NULL),
(NULL, NULL, NULL, 'gabriel1', '12345678', 'pantirugabriel90@yahoo.com', 'INDISPONIBIL'),
('', '', '0000-00-00', 'gfkiller', '123456', 'dddddd@yahoo.com', 'INDISPONIBIL'),
(NULL, NULL, NULL, 'ion', '123', 'io@fun.eu', 'DISPONIBIL'),
('Aruxandei', 'Larisa', '0000-00-00', 'lari', '12345', 'lari@pis.com', 'INDISPONIBIL'),
(NULL, NULL, NULL, 'Lavi', '12345', 'maria_rebel_95@yahoo.com', 'INDISPONIBIL'),
(NULL, NULL, NULL, 'Lavinia Maria Tiba', '123456', 'maria_rebel_95@yahoo.com', NULL),
(NULL, NULL, NULL, 'Lucian Dediu', '123456', 'lucian_dediu@yahoo.com', NULL),
(NULL, NULL, NULL, 'lucifer', '123456789', 'lucifer@yahoo.com', 'INDISPONIBIL'),
('', '', '0000-00-00', 'mihai', '123', 'mih@gmail.com', 'INDISPONIBIL'),
(NULL, NULL, NULL, 'olalala', '12345', '123@uuuu.com', 'DISPONIBIL'),
(NULL, NULL, NULL, 'radu', '123', 'rad@yahoo.com', 'INDISPONIBIL'),
('doru', 'mifai', '0000-00-00', 'teo595', '12345678', 'ursan.teofil@yahoo.com', 'INDISPONIBIL'),
(NULL, NULL, NULL, 'teo955', '12345678', 'teo@yahoo.com', 'INDISPONIBIL'),
(NULL, NULL, NULL, 'Teofil Ursan', '123456', 'ursan.teofil@yahoo.com', 'INDISPONIBIL'),
(NULL, NULL, NULL, 'toto', 'totemail@email', 'tot', NULL),
(NULL, NULL, NULL, 'undefined', '123456', 'undefined', NULL),
('Dan', 'FaraFrica', '1990-06-12', 'vasi', '12345', 'vasi@yahoo.com', 'INDISPONIBIL'),
(NULL, NULL, NULL, 'vasilica', '123', 'abc@gmail.com', 'DISPONIBIL');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `CLASAMENT`
--
ALTER TABLE `CLASAMENT`
  ADD PRIMARY KEY (`USERNAME`);

--
-- Indexes for table `INTREBARI`
--
ALTER TABLE `INTREBARI`
  ADD PRIMARY KEY (`ID_INTREBARE`);

--
-- Indexes for table `JOC_SINGLE`
--
ALTER TABLE `JOC_SINGLE`
  ADD PRIMARY KEY (`ID_JOC`);

--
-- Indexes for table `PARTIDE_DE_JOC`
--
ALTER TABLE `PARTIDE_DE_JOC`
  ADD PRIMARY KEY (`ID_JOC`);

--
-- Indexes for table `UTILIZATORI`
--
ALTER TABLE `UTILIZATORI`
  ADD PRIMARY KEY (`USERNAME`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `JOC_SINGLE`
--
ALTER TABLE `JOC_SINGLE`
  MODIFY `ID_JOC` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;
--
-- AUTO_INCREMENT for table `PARTIDE_DE_JOC`
--
ALTER TABLE `PARTIDE_DE_JOC`
  MODIFY `ID_JOC` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
