<?php
function login(){
$servername = "fenrir.info.uaic.ro";
$username = "teo95ursan";
$password = "aC7tAu6EWi";
if(isset($_POST['Login'])){
// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$url='menu.php';
   ob_start();
    header('Location: '.$url);
    ob_end_flush();
    die();
}
}
?>

<?php
function register(){
$servername = "fenrir.info.uaic.ro";
$username = "teo95ursan";
$password = "aC7tAu6EWi";
if(isset($_POST['Register'])){
// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$url='menu.php';
   ob_start();
    header('Location: '.$url);
    ob_end_flush();
    die();
}
}
?>