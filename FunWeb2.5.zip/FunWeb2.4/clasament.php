<?php
    session_start();
?>
<DOCTYPE HTML>
<HEAD>
<TITLE>
</TITLE>
<link rel="stylesheet" href="bootstrap-3.3.6\dist\css\bootstrap.min.css">
<script src="bootstrap-3.3.6\js\tests\vendor\jquery.min.js"></script>
  <script src="bootstrap-3.3.6\dist\js\bootstrap.min.js"></script>
 <?php include'Model\functions.php';?> 



<nav class="navbar navbar-inverse">
  <div class="container-fluid">
  <div class="navbar-header navbar-right">
      <a class="navbar-brand" href="#">General</a>
    </div>
    <div class=" navbar-right">
      <a class="navbar-brand" href="#">Friends</a>
     </div>
    
  </div>
</nav>

</HEAD>
<BODY>
 <div class="table-responsive">          
  <table class="table">
    <thead>
      <tr>
        <th>Username</th>
        <th>Score</th>
        <th>Level</th>
      </tr>
    </thead>
    <tbody>
      <?php
      clasament();
      ?>
    </tbody>
  </table>
  </div>
</div>

</BODY>
</HTML>