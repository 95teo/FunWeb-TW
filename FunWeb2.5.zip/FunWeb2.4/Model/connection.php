<?php
function login(){
    $servername = "fenrir.info.uaic.ro";
    $username = "teo95ursan";
    $password = "aC7tAu6EWi";
    $dbname = "teo95ursan";

    if(isset($_POST['Login'])){

// Create connection
        $conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        $user=$_POST['user'];
        $pass=$_POST['pwd'];
        $stmt =  mysqli_prepare($conn, "SELECT COUNT(*) from UTILIZATORI WHERE USERNAME=? and PAROLA=?");
        mysqli_stmt_bind_param($stmt, 'ss', $user,$pass);
        $stmt->execute();
        $stmt->bind_result($numar);
        while ($stmt->fetch()) {
            /*printf ("%d \n", $numar);*/
        }
        if($numar==0){
            echo 'Combinaţie user/parolă eronată! Reîncercaţi. ';
        }
        else {
            //$jucatorCurent=$_SESSION["my_user"];
            //mysqli_stmt_free_result($stmt);
            //$stmt =  mysqli_prepare($conn, "UPDATE UTILIZATORI SET STATUS = 'DISPONIBIL' WHERE USERNAME=?");
           // mysqli_stmt_bind_param($stmt,'s',$user);
           // $stmt->execute();
            mysqli_stmt_free_result($stmt);
            mysqli_close();
            echo "<script>";
            echo "top.window.location = 'menu.php';";
            echo "</script>";
            
/*$url='menu.php';
   ob_start();
    header('Location: '.$url);
    ob_end_flush();
    die();*/
}

}
}

function register(){
    $servername = "fenrir.info.uaic.ro";
    $username = "teo95ursan";
    $password = "aC7tAu6EWi";
    $dbname = "teo95ursan";
    if(isset($_POST['Register'])){
// Create connection
        $conn = new mysqli($servername, $username, $password,$dbname);

// Check connection

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        $ok=1;
        $user=$_POST['user'];
        $pass=$_POST['parola'];
        $mail=$_POST['email'];
        $pass_confirm=$_POST['rescrie_parola'];

        if($user<4)$ok=0;
        if($pass<4)$ok=0;
        if($pass_confirm<4)$ok=0;
        if($pass==$pass_confirm)$ok=1; else $ok=0;
        if($ok==1){
           $stmt =  mysqli_prepare($conn, "SELECT COUNT(*) from UTILIZATORI WHERE USERNAME=?");
           mysqli_stmt_bind_param($stmt, 's', $user);
           $stmt->execute();
           $stmt->bind_result($numar);
           while ($stmt->fetch()) {
            /*printf ("%d \n", $numar);*/
        }
        if($numar==1){
            echo 'Sorry for that! The username is already taken. Please choose another one. ';
        }
        else {
            mysqli_stmt_free_result($stmt);
            $stmt = mysqli_prepare($conn, "INSERT INTO UTILIZATORI VALUES (null,null,null,?,?,?,null)");
            mysqli_stmt_bind_param($stmt, 'sss', $user,$pass,$mail);
            if(mysqli_stmt_execute($stmt)){
                echo "<script>";
                echo "top.window.location = 'menu.php';";
                echo "</script>";
            }
            else{
                echo 'Oups! Something unexpected happened.';
            }
/*
$url='menu.php';
   ob_start();
    header('Location: '.$url);
    ob_end_flush();
    die();*/
}
}
else { echo "You haven't completed all the fields for register.";}

}}

function getOnlineUsers(){////////////////inca o coloana pentru cei online!!
    $servername = "fenrir.info.uaic.ro";
    $username = "teo95ursan";
    $password = "aC7tAu6EWi";
    $dbname = "teo95ursan";
// Create connection
    $conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    $stmt =  mysqli_prepare($conn, "SELECT USERNAME from UTILIZATORI WHERE STATUS = 'DISPONIBIL'");
    $stmt->execute();
    $stmt->bind_result($nume);
    $stmt->fetch();
    $jucatorCurent=$_SESSION["my_user"];
    if($nume != $jucatorCurent){
            printf ("{'word':'%s'}", $nume);
        }
    
    while ($stmt->fetch()) {
        if($nume != $jucatorCurent){
            printf (",\n");
            printf ("{'word':'%s'}", $nume);
        }
        
    }

}

function createGame(){
    $servername = "fenrir.info.uaic.ro";
    $username = "teo95ursan";
    $password = "aC7tAu6EWi";
    $dbname = "teo95ursan";
    if(isset($_POST['Create'])){
// Create connection
        $domenii=array();
        if(!empty($_POST['chk1'])){
            array_push($domenii, "html");
        }
        else{
            array_push($domenii, "");
        }
        if(!empty($_POST['chk2'])){
            array_push($domenii, "angular");
        }
        else{
            array_push($domenii, "");
        }
        if(!empty($_POST['chk3'])){
            array_push($domenii, "php");
        }
        else{
            array_push($domenii, "");
        }
        if(!empty($_POST['chk4'])){
            array_push($domenii, "css");
        }
        else{
            array_push($domenii, "");
        } 
        if(!empty($_POST['chk5'])){
            array_push($domenii, "ajax");
        }
        else{
            array_push($domenii, "");
        }
        if(!empty($_POST['chk6'])){
            array_push($domenii, "js");
        }
        else{
            array_push($domenii,"");
        }
        if(!empty($_POST['chk7'])){
            array_push($domenii, "http");
        }
        else{
            array_push($domenii, "");
        }
        if(!empty($_POST['chk8'])){
            array_push($domenii, "xml");
        }
        else{
            array_push($domenii, "");
        }
        $all_dom="";
        $prim=0;
        for ($i=0;$i<sizeof($domenii);$i++){
           if($domenii[$i]!=""){
               if($prim==0){$all_dom=$all_dom.$domenii[$i];$prim=1;}
               else
                   $all_dom=$all_dom.",".$domenii[$i];
           }  
       }  

       $conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
       if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    $ok=1;
    $user2=$_POST['user1'];
    $user3=$_POST['user2'];
    $question_number=$_POST['questions'];
    $autor=$_SESSION["my_user"];
    $stmt = mysqli_prepare($conn, "SELECT COUNT(*) FROM PARTIDE_DE_JOC WHERE STATUS_JOC=\"WAITING\" AND USER1=?");
    mysqli_stmt_bind_param($stmt,'s',$autor);
    mysqli_stmt_execute($stmt);
    $stmt->bind_result($areJoc);
    $stmt->fetch();
    if($areJoc!=0){
       print '   <!-- Modal -->
<div id="modal">
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Warning!</h4>
        </div>
        <div class="modal-body">
          <p><b>You already have a game in the waiting list! Please have patience!<b></p>
       
          <button type="button" class="btn btn-default" data-dismiss="modal" style="float:right;">OK</button><br><br>
        </div> 
      </div>
      
    </div>
  </div>
</div>
 <script> $("#myModal").modal("show"); </script>';
    } else{
    
    mysqli_stmt_free_result($stmt);
    if($user2 == "" ){
        $user2="?";
    }
    if($user3 == ""){
        $user3 = "?";
    }
    if(($user2 != $user3) || ($user2=="?" && $user3 =="?")){

    $stmt = mysqli_prepare($conn, "INSERT INTO PARTIDE_DE_JOC 
        (USER1,USER2,USER3,CASTIGATORI,DOMENII_ALESE,NR_INTREBARI,PUNCTAJ_USER1,PUNCTAJ_USER2,PUNCTAJ_USER3,DATA_JOC,DURATA,STATUS_JOC)
        VALUES (?,?,?,null,?,?,null,null,null,null,null,\"WAITING\")");
    mysqli_stmt_bind_param($stmt, 'ssssd',$autor,$user2,$user3, $all_dom,$question_number);
    mysqli_stmt_execute($stmt);
    
     //sa punem id-ul jocului in sesiune
    mysqli_stmt_free_result($stmt);
    $jucatorCreator = $_SESSION["my_user"];

    $stmt =  mysqli_prepare($conn, "SELECT ID_JOC FROM PARTIDE_DE_JOC WHERE USER1=? AND STATUS_JOC=\"waiting\"");
    mysqli_stmt_bind_param($stmt,'s',$jucatorCreator);
    $stmt->execute();
     
    $stmt->bind_result($id_joc);
    $stmt->fetch();
   
    $_SESSION['id_joc']=$id_joc;
    mysqli_stmt_free_result($stmt);
    mysqli_close($conn);

    
 // startGame();

    }
    else{
        print '   <!-- Modal -->
<div id="modal">
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Warning!</h4>
        </div>
        <div class="modal-body">
          <p><b>Please choose different oponents!<b></p>
          <button type="button" class="btn btn-default" data-dismiss="modal" style="float:right;">OK</button><br><br>
        </div> 
      </div>
      
    </div>
  </div>
</div>
 <script> $("#myModal").modal("show"); </script>';
    }
    }   
}

}


function logout(){
    session_unset();
    session_destroy();
    $url='index.php';
   ob_start();
    header('Location: '.$url);
    ob_end_flush();
    die();
}

function getQuestion(){
$servername = "fenrir.info.uaic.ro";
    $username = "teo95ursan";
    $password = "aC7tAu6EWi";
    $dbname = "teo95ursan";
// Create connection
        $conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        $id_joc = $_SESSION['id_joc'];
       // echo "id joc ".$id_joc;
        $stmt = mysqli_prepare($conn, "SELECT DOMENII_ALESE FROM PARTIDE_DE_JOC WHERE ID_JOC=?");
        mysqli_stmt_bind_param($stmt,'s',$id_joc);
        $stmt->execute();
        $stmt->bind_result($domenii_alese);
        $stmt->fetch();
       // echo "\n Domenii alese *".$domenii_alese."*\n";
        
        $domenii_alese_array =  array();
        $domenii_alese_array = explode(",",$domenii_alese);
        $multime_domenii="";
        

        if(sizeof($domenii_alese_array)==1){
            $multime_domenii = $domenii_alese_array[0];
        }else{
            if(sizeof($domenii_alese_array)==2){
            $multime_domenii = $domenii_alese_array[0]."','".$domenii_alese_array[1];
        }
        else{
            $multime_domenii = $domenii_alese_array[0]."',";
            for($i=1;$i<sizeof($domenii_alese_array)-2;$i++){
            $multime_domenii = $multime_domenii."'".$domenii_alese_array[$i]."',";
           }
           $multime_domenii = $multime_domenii."'".$domenii_alese_array[$i];

        }
        }

       // echo "\nDomeniile tale : ".$multime_domenii."\n";
       // echo $multime_domenii;
       // print_r (explode(",",$domenii_alese));
        
        mysqli_stmt_free_result($stmt);
        $interogare = "SELECT ID_INTREBARE FROM INTREBARI WHERE DOMENIU IN ( '".$multime_domenii."' ) ORDER BY RAND() LIMIT 1";
       // print "\n".$interogare."\n";
        $stmt =  mysqli_prepare($conn, $interogare);
        //mysqli_stmt_bind_param($stmt,'s',$multime_domenii);
        $stmt->execute();
        $stmt->bind_result($id_intrebare);
        $stmt->fetch() ;
      // echo "\n Id intrebare : ".$id_intrebare."\n";
       //     printf ("%d \n", $numar);
       // }   
        $_SESSION["id_intrebare"]=$id_intrebare;
       // echo "Id: ".$id_intrebare."id din sesiune : ".$_SESSION['id_intrebare']."\n";
        return $id_intrebare;     
}


function verifyAnswer(){
    $servername = "fenrir.info.uaic.ro";
    $username = "teo95ursan";
    $password = "aC7tAu6EWi";
    $dbname = "teo95ursan";
// Create connection
    $raspuns_dat='';
    if(isset($_POST['A'])){
        $raspuns_dat='A';
    }
    if(isset($_POST['B'])){
        $raspuns_dat='B';
    }
    if(isset($_POST['C'])){
        $raspuns_dat='C';
    }
    if(isset($_POST['D'])){
        $raspuns_dat='D';
    }
    $punctaj = 0;
    if($raspuns_dat!=''){
        $raspuns_corect=$_SESSION['raspuns_corect'];
        echo "corect: ".$raspuns_corect." ";
        echo "rasp dat : ".$raspuns_dat." ";
        if($raspuns_dat == $raspuns_corect){
             $punctaj = $punctaj+1;
        }
        echo $punctaj;

    }
}


function completeazaCampuri(){
    $id_intrebare = getQuestion ();
    $servername = "fenrir.info.uaic.ro";
    $username = "teo95ursan";
    $password = "aC7tAu6EWi";
    $dbname = "teo95ursan";
// Create connection
        $conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
     
       // echo "id joc ".$id_joc;
        $stmt = mysqli_prepare($conn, "SELECT ENUNT,VARIANTA_A,VARIANTA_B,VARIANTA_C,VARIANTA_D,RASPUNS_CORECT FROM INTREBARI WHERE ID_INTREBARE= ? ");
        mysqli_stmt_bind_param($stmt,'s',$id_intrebare);
        $stmt->execute();
        $stmt->bind_result($enunt,$a,$b,$c,$d,$raspuns_corect);
        $stmt->fetch();
        $_SESSION['raspuns_corect']=$raspuns_corect;
         print "<div class=\"form-group\"><hr> 
      <label class=\"control-label\" > Întrebarea: ".$enunt."</label
    </div>
    <hr>
    
    <div class=\"form-group\">
      <label class=\"control-label \" > A)  ".htmlentities($a)." </label> 
    </div>

    <div class=\"form-group\">
      <label class=\"control-label \" > B)  ".htmlentities($b)." </label> 
    </div>

    <div class=\"form-group\">
      <label class=\"control-label \" > C)  ".htmlentities($c)."</label>
      
    </div>
    
    <div class=\"form-group\">
      <label class=\"control-label \" > D)  ".htmlentities($d)."</label>
      
    </div>";
}

function getPartideDeJoc(){
    $servername = "fenrir.info.uaic.ro";
    $username = "teo95ursan";
    $password = "aC7tAu6EWi";
    $dbname = "teo95ursan";
// Create connection
    $conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    $stmt =  mysqli_prepare($conn, "SELECT USER1,USER2,USER3,STATUS_JOC FROM PARTIDE_DE_JOC");
    $stmt->execute();
    $stmt->bind_result($user1,$user2,$user3,$status);

    while ($stmt->fetch()) {
        print '<form method="POST">
        <div class="panel-body" >
                    <div class="panel panel-primary">
                      <div class="panel-heading">'.$user1.'</div>
                      <div class="panel-body">
                        <div>
                        <span class="label label-info" id="user">'.$user2.'</span>
                        <span class="label label-info" id="user">'.$user3.'</span>
                    </div>
                        <div class="input-group-btn">
                        
                       <button type="submit" class="join" name="joinGame"><span>Join Game</span></button>
                      </div>
                      </div>
                  </div>
              </div>
              <input type="hidden" name="autor_joc" value="'.$user1.'">
        </form>';
    }

}

function startGame(){
    $servername = "fenrir.info.uaic.ro";
    $username = "teo95ursan";
    $password = "aC7tAu6EWi";
    $dbname = "teo95ursan";
// Create connection
    $conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    $stmt =  mysqli_prepare($conn, "SELECT JOIN_USER3 FROM PARTIDE_DE_JOC WHERE ID_JOC=? AND STATUS_JOC=\"waiting\"");
    mysqli_stmt_bind_param($stmt,'d',$_SESSION['id_joc']);
    
    while(1){
         $stmt->execute();
         $stmt->bind_result($joinUser3);
         $stmt->fetch();
         //verificam daca user 3 a dat join
         if($joinUser3 == 1){
            print "<script>";
            print "top.window.location = 'multi_joc.php';";
            print "</script>";
         }
    }
    
}

function joinGame(){
     
    if(isset($_POST['joinGame'])){

    $servername = "fenrir.info.uaic.ro";
    $username = "teo95ursan";
    $password = "aC7tAu6EWi";
    $dbname = "teo95ursan";
// Create connection
    $conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    $autor = $_POST['autor_joc'];

    $stmt =  mysqli_prepare($conn, "SELECT ID_JOC,USER2,USER3,JOIN_USER2,JOIN_USER3 FROM PARTIDE_DE_JOC WHERE USER1=? AND STATUS_JOC=\"waiting\"");
    mysqli_stmt_bind_param($stmt,'s',$autor);
    $stmt->execute();
     
    $stmt->bind_result($id_joc,$user2,$user3,$join_user2,$join_user3);
    $stmt->fetch();
   
    $jucatorCurent=$_SESSION["my_user"];
    $_SESSION['id_joc']=$id_joc;
     
    if($autor != $jucatorCurent){
    if(($user2 == "?" || $user2 == $jucatorCurent) && $join_user2 == 0){
            $user2 = $jucatorCurent;
            $join_user2 = 1;
    }else{
        if(($user3 == "?" || $user3 == $jucatorCurent) && ($user2 != $jucatorCurent) && $join_user3 == 0){
            $user3 = $jucatorCurent;
            $join_user3 = 1;
            //lansam jocul
    }
    }
     
     mysqli_stmt_free_result($stmt);
     $stmt =  mysqli_prepare($conn, "UPDATE PARTIDE_DE_JOC SET USER2=?, USER3=?, JOIN_USER2=?,JOIN_USER3=? WHERE USER1=? AND STATUS_JOC=\"waiting\" ");
     
     mysqli_stmt_bind_param($stmt,'ssdds',$user2,$user3,$join_user2,$join_user3,$autor);
     $stmt->execute();
     
     mysqli_stmt_free_result($stmt);
     ///User-ul devine indisponibil
     mysqli_stmt_free_result($stmt);
     $stmt =  mysqli_prepare($conn, "UPDATE UTILIZATORI SET STATUS = 'INDISPONIBIL' WHERE USERNAME=?");
    
     mysqli_stmt_bind_param($stmt,'s',$jucatorCurent);
     $stmt->execute();
 
     mysqli_stmt_free_result($stmt);
     //
     mysqli_close($conn);
     
     //startGame();

     
    }
    
    else{
         print '   <!-- Modal -->
<div id="modal">
  <div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog">
      
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Warning!</h4>
        </div>
        <div class="modal-body">
          <p><b>You are trying to join your own game! LoL ..<b></p>
       
          <button type="button" class="btn btn-default" data-dismiss="modal" style="float:right;">OK</button><br><br>
        </div> 
      </div>
      
    </div>
  </div>
</div>
 <script> $("#myModal2").modal("show"); </script>';
    }
}
}

?>

