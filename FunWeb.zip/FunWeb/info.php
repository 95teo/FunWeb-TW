<?php
session_start();
?>
<!DOCTYPE HTML>
<html lang="en">
    <HEAD>
        <TITLE>
        </TITLE>

        <meta charset="utf-8">
        <!-- import CSS -->
        <link rel="stylesheet" href="bootstrap-3.3.6/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <!-- import JS -->
        <script src="bootstrap-3.3.6/js/tests/vendor/jquery.min.js"></script>
        <script src="bootstrap-3.3.6/dist/js/bootstrap.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <!-- import PHP -->
        <?php include'Model/Informatii.php'; ?> 

    </HEAD>

    <BODY>
        <form id = "Modificare_formular" class="form-horizontal" role="form" method="POST">

            <p class="text-center"> The Account Information are available for update!  </p>
            <hr>
            <div class="form-group">
                <label class="control-label col-sm-2" for="nume"> First Name: </label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="nume" placeholder="First Name" name="nume">
                </div>

            </div>
            <hr>
            <div class="form-group">
                <label class="control-label col-sm-2" for="prenume"> Second Name: </label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="prenume" placeholder="Second Name" name="prenume">
                </div>
            </div>
            <hr>
            <div class="form-group">
                <label class="control-label col-sm-2" for="user"> Username: </label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="user" placeholder="Username" name="user" disabled>
                </div>
            </div>
            <hr>
            <div class="form-group">
                <label class="control-label col-sm-2" for="data_nastere"> Date of birth: </label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="data_nastere" placeholder="yyyy-mm-dd" name="data_nastere"> 
                </div>
            </div>
            <hr>

            <div class="form-group">
                <label class="control-label col-sm-2" for="email"> Email: </label>
                <div class="col-sm-10">
                    <input type="email" class="form-control" id="email" placeholder="Email" name="email">
                </div>
            </div>

            <hr>  
            <div id= "inregistrare" class="form-group">        
                <div class="col-sm-offset-2 col-sm-10">
                    <div id="succes_info" hidden><p><img src="multimedia/green.svg" width="35px" height="35px" />Informations succesfully changed!</p> </div>
                    <button type="submit" id="aplica_modificari" name="aplica_modificari" class="btn btn-default"> Save Changes </button>

                </div>
            </div>
            <hr>

            <p class="text-center">Modify password</p>
            <div class="form-group">
                <label class="control-label col-sm-2" for="user"> Old Password: </label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" id="user" placeholder="Introduce the old password" name="old_pass"
                           data-toggle="popover" data-placement="top" data-content="Incorect password" >
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2" for="parola"> New Password: </label>
                <div class="col-sm-10">          
                    <input type="password" class="form-control" id="parola" placeholder="Introduce the new password" name="new_pass">
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-sm-2" for="rescrie_parola"> Confirm  new password: </label>
                <div class="col-sm-10">          

                    <input type="password" class="form-control" id="rescrie_parola" placeholder="Confirm your new password" name="new_pass_confirm">
                </div>

            </div>

            <div id= "inregistrare" class="form-group">  
                <div class="col-sm-offset-2 col-sm-10">
                    <div id="succes_pass" hidden><p><img src="multimedia/green.svg" width="35px" height="35px" />Password succesfully changed!</p></div>
                    <button type="submit" id="change_pass" name="change_pass" class="btn btn-default"> Change Password </button>

                </div>
            </div>

        </form>

        <?php
        modifica();
        modificaParola();
        getInfoUsers();
        ?>

    </BODY>
</HTML>