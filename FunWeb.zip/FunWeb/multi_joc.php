<?php session_start(); ?>
<!DOCTYPE HTML>
<html lang="en">
    <HEAD>
        <TITLE>
        </TITLE>
        <meta charset="utf-8">
        <!-- import CSS -->
        <link rel="stylesheet" href="bootstrap-3.3.6\dist\css\bootstrap.min.css">
        <link rel="stylesheet" href="css/multi_joc.css">
	<link rel="stylesheet" href="css\navbar.css">
	<link rel="stylesheet" href="css\w3shools.css">
        <!-- import JS -->
        <script src="bootstrap-3.3.6\js\tests\vendor\jquery.min.js"></script>
        <script src="bootstrap-3.3.6\dist\js\bootstrap.min.js"></script>
        <!-- import PHP -->
        <?php include'Model/Informatii.php'; ?>
	<?php include'Model/Shared.php'; ?>
        <?php include'Model/MultiJoc.php'; ?>
        
    </HEAD>
    <BODY>
       
<table id="continut">
    <tr><td>
            <div class="w3-card-12">
                <?php statistici_Multi() ?>
        </td>
    </tr>
    <tr><td>
            <div class="w3-card-12 ">
                <?php
                verifyAnswer_Multi(); 
                completeazaCampuri_Multi(); 
                ?>
                <form id = "form-modifier" class="form-horizontal" role="form" method="POST">
                    <div  class="form-group">        
                        <div class="col-sm-offset-2 col-sm-10" id= "butoane">
                            <button type="submit"  class="btn btn-primary" name = "A"> A </button>
                            <button type="submit"  class="btn btn-primary" name = "B"> B </button>
                            <button type="submit"  class="btn btn-primary" name = "C"> C </button>
                            <button type="submit"  class="btn btn-primary" name = "D"> D </button>
                             <button type="submit"  class="btn btn-primary" name = "E"  id ="E" > E </button>

                        </div>
                    </div>
            </div>
        </td>
    </tr>
</table>
    

    </BODY>
</HTML>