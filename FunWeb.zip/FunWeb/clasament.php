<?php
session_start();
?>
<!DOCTYPE HTML>
    <HTML lang="en">
    <HEAD>
        <TITLE>
        </TITLE>
        <!--import CSS -->
        <link rel="stylesheet" href="bootstrap-3.3.6/dist/css/bootstrap.min.css">
        <!--import JS -->
        <script src="bootstrap-3.3.6/js/tests/vendor/jquery.min.js"></script>
        <script src="bootstrap-3.3.6/dist/js/bootstrap.min.js"></script>
        <!--import PHP -->
        <?php include'Model/Informatii.php'; ?> 

</HEAD>
<BODY>
     <!-- bara de navigare  -->
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header navbar-right">
                <a class="navbar-brand" href="#">General</a>
            </div>


        </div>
    </nav>
     
     <!--tabel clasament -->
    <div class="table-responsive">          
        <table class="table">
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Score</th>
                    <th>Level</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    clasament();
                ?>
            </tbody>
        </table>
    </div>
    </div>

</BODY>
</HTML>