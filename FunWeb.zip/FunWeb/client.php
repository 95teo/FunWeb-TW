<html>
<head>
<script>
var connection = new WebSocket('ws://localhost:8001');
connection.onmessage=function (event) {

document.getElementById('result').value=event.data;
};
</script>
</head>
<body>
<p>
Result:<output type=text id="result" value="" readonly></output></p>
<input type=text onchange="connection.send(this.value);">
</body>
</html>