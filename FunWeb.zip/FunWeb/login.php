<?php
// Start the session
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>FunWeb</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <script type="text/javascript" src="fancybox/lib/jquery-1.10.1.min.js"></script>

 <!-- import CSS -->
  <link href="bootstrap-3.3.6\dist\css\bootstrap.css" rel="stylesheet">
  <link href="css\login.css" rel="stylesheet">

<!-- import JS -->
        <script src="bootstrap-3.3.6/js/tests/vendor/jquery.min.js"></script>
        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
	<script src="bootstrap-3.3.6/dist/js/bootstrap.min.js"></script>        
<!-- import PHP -->
  <?php include'Model/Index.php';?>
<?php include'Model/FB_Login.php';?>
<?php include'Model/Informatii.php';?>
</head>
<script type="text/javascript">(function (w,d) {var loader = function () {var s = d.createElement("script"), tag = d.getElementsByTagName("script")[0]; s.src = "//cdn.iubenda.com/iubenda.js"; tag.parentNode.insertBefore(s,tag);}; if(w.addEventListener){w.addEventListener("load", loader, false);}else if(w.attachEvent){w.attachEvent("onload", loader);}else{w.onload = loader;}})(window, document);</script>
<script>
function sortMethod(a, b) {
        var x = a.name.toLowerCase();
        var y = b.name.toLowerCase();
        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
    }

  
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '688266017982990',
      status : true, // check login status
    cookie : true, // enable cookies to allow the server to access the session
    xfbml  : true, // parse XFBML
      version    : 'v2.5',
oauth  : true // enable OAuth 2.0
    });
	

  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "//connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));

 function testAPI() {

    console.log('Welcome!  Fetching your information.... ');
    FB.api('/me', { locale: 'en_US', fields: 'name, email' },function(response) {

var details = response;
                var name = details.name;
                var email = details.email;
                var gender = details.gender;
     $.ajax({
     type: "POST",
     url: "https://funweblearning.tk/login.php",
     data: "&name=" + name + "&email=" + email,
         success: function(msg){
console.log("Success"+name+email); 
          }
         });
    console.log('Good to see you, ' + response.name + '.');
 
FB.getLoginStatus(function(response) {
  // this will be called when the roundtrip to Facebook has completed
}, true);
      console.log('Successful login for: ' + response.name);
      console.log('Your email is: ' + response.email);
console.log('Your ID is: ' + response.id);
    });

FB.api('/me', function(response) {
  console.log(response);

});
    FB.api('/me/invitable_friends', function(response) {
                 
                    var friend_data = response.data.sort(sortMethod);

                    var results = '';
                    for (var i = 0; i < friend_data.length; i++) {
                        results += '<div><img src="https://graph.facebook.com/' + friend_data[i].id + '/picture">' + friend_data[i].name + '</div>';
                    }

                    // and display them at our holder element
                    console.log('Result list of your friends:' + results);
                });


FB.getLoginStatus(function(response) {
  if (response.status === 'connected') {

                top.window.location = "https://apps.facebook.com/fun_web";
            

    // the user is logged in and has authenticated your
    // app, and response.authResponse supplies
    // the user's ID, a valid access token, a signed
    // request, and the time the access token 
    // and signed request each expire
    var uid = response.authResponse.userID;
    var accessToken = response.authResponse.accessToken;
  } else if (response.status === 'not_authorized') {

          
    // the user is logged in to Facebook, 
    // but has not authenticated your app
  } else {
    // the user isn't logged in to Facebook.

          
          

  }
 });

};

</script>
<body>
  <div class="login">



<form id = "Login_formular" class="form-horizontal" role="form" method="POST" >
                <div class="form-group">
                    <label class="control-label col-sm-2" for="user"> <span class="glyphicon glyphicon-user"></span> </label>
                    <div class="col-sm-10">
                        <input type="text" name='user' class="form-control" id="user" placeholder="Username" required="true" 
                               data-toggle="popover" data-placement="right" data-html="true" data-content="<div style='color:#8E0000;'><b> Username does not exist!</b>" >
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="pwd"> <span class="glyphicon glyphicon-lock"></span> </label>
                    <div class="col-sm-10">          
                        <input type="password" name='pwd' class="form-control" id="pwd" placeholder="Password" required="true" 
                         data-toggle="popover" data-placement="right" data-html="true" data-content="<div style='color:#8E0000;'><b> Incorect password!</b>">
                    </div>
                </div>

                <div id= "logare" class="form-group">        
                    <div class="col-sm-offset-2 col-sm-10">
                        <button type="submit" id="logare_buton" class="btn btn-primary" name="Login" > Login </button>
                    </div>
                </div>
            </form>

 <FB:login-button show-faces="false" perms="user_hometown,user_about_me,email,user_address,user_friends"
autologoutlink="false" width="200" max-rows="1" onlogin="testAPI();" scope="email,user_friends,public_profile">
</FB:login-button>


<div
  class="fb-like"
  data-share="true"
  data-width="450"
  data-show-faces="true">
</div>

  </div> 
<p>After you log in with Facebook we will give you a default password 123456. Please modify it as soon after you log in the application.</p>
<br>
<br>
<br>
<br>
 <?php
 FB_login();
  if(isset($_POST['Login'])){
    $_SESSION["my_user"]=$_POST["user"];
  }
  login();
 
   // echo $_SESSION["my_user"];}
    ?>

  </body>
  </html>
