var user_ok=0;
var email_ok=0;
var parola_ok=0;
var parola_confirma_ok=0;
function checkPass()
{
    //Store the password field objects into variables ...
   
    var pass1 = document.getElementById('parola');
    var pass2 = document.getElementById('rescrie_parola');
    //Store the Confimation Message Object ...
    var fieldset = pass2.parentNode;
    var message = document.getElementById('message');
    //Set the colors we will be using ...
    //var goodColor = "#66cc66";
    var badColor = "#ff6666";
    //Compare the values in the password field 
    //and the confirmation field
    if(pass1.value == pass2.value){
        //The passwords match. 
        //Set the color to the good color and inform
        //the user that they have entered the correct password 
        //pass2.style.backgroundColor = goodColor;
       // message.style.color = goodColor;
        fieldset.className = "welldone";
        pass1.style.backgroundColor = "white";
        pass2.style.backgroundColor = "white";
        parola_confirma_ok=1;
    }else{
        //The passwords do not match.
        //Set the color to the bad color and
        //notify the user.
        pass1.style.backgroundColor = badColor;
        pass2.style.backgroundColor = badColor;
        
    }
}  
// This function checks if the username field
// is at least 4 characters long.
// If so, it attaches class="welldone" to the 
// containing fieldset.

function checkUsernameForLength(whatYouTyped) {
	var fieldset = whatYouTyped.parentNode;
	var txt = whatYouTyped.value;
	if (txt.length > 3) {
		fieldset.className = "welldone";
		user_ok=1;
			}
	else {
		fieldset.className = "";
	}
}





// If the password is at least 4 characters long, the containing 
// fieldset is assigned class="kindagood".
// If it's at least 8 characters long, the containing
// fieldset is assigned class="welldone", to give the user
// the indication that they've selected a harder-to-crack
// password.

function checkPassword(whatYouTyped) {
	var fieldset = whatYouTyped.parentNode;
	var txt = whatYouTyped.value;
	if (txt.length > 3 && txt.length < 8) {
		fieldset.className = "kindagood";
		parola_ok=1;
	} else if (txt.length > 7) {
		fieldset.className = "welldone";
		parola_ok=1;
	} else {
		fieldset.className = "";
	}
}

// This function checks the email address to be sure
// it follows a certain pattern:
// blah@blah.blah
// If so, it assigns class="welldone" to the containing
// fieldset.

function checkEmail(whatYouTyped) {
	var fieldset = whatYouTyped.parentNode;
	var txt = whatYouTyped.value;
	if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(txt)) {
		fieldset.className = "welldone";
		email_ok=1;
	} else {
		fieldset.className = "";
	}
}




// this part is for the form field hints to display
// only on the condition that the text input has focus.
// otherwise, it stays hidden.

function addLoadEvent(func) {
  var oldonload = window.onload;
  if (typeof window.onload != 'function') {
    window.onload = func;
  } else {
    window.onload = function() {
      oldonload();
      func();
    }
  }
}


function prepareInputsForHints() {
  var inputs = document.getElementsByTagName("input");
  for (var i=0; i<inputs.length; i++){
    inputs[i].onfocus = function () {
      this.parentNode.getElementsByTagName("span")[0].style.display = "inline";
    }
    inputs[i].onblur = function () {
      this.parentNode.getElementsByTagName("span")[0].style.display = "none";
    }
  }
}
addLoadEvent(prepareInputsForHints);

$('#user,#email,#parola, #rescrie_parola').on('keyup', function () {
    if (user_ok==1 && email_ok==1 && parola_ok==1 && parola_confirma_ok==1) {
      document.getElementById("inregistrare_buton").disabled = false;  
      }
        document.write(user_ok + "sunt aici");

});

