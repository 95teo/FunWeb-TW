<?php session_start(); ?>
<!DOCTYPE HTML>
    <HTML lang="en">
        <HEAD>
            <TITLE>
            </TITLE>
            <!-- import CSS -->
            <link rel="stylesheet" href="bootstrap-3.3.6\dist\css\bootstrap.min.css">
            <link rel="stylesheet" href="css\w3shools.css">
            <link rel="stylesheet" href="css\final_multi.css">
	    <link rel="stylesheet" href="css\navbar.css">
	    <link rel="stylesheet" type="text/css" href="fancybox/source/jquery.fancybox.css?v=2.1.5" media="screen" />
            <!-- import JS -->
 	    <script src="bootstrap-3.3.6\js\tests\vendor\jquery.min.js"></script>
            <script src="bootstrap-3.3.6\dist\js\bootstrap.min.js"></script>

	    <script type="text/javascript" src="fancybox/source/jquery.fancybox.js?v=2.1.5"></script>
        


           
            <!-- import PHP -->
            <?php include'Model/Informatii.php'; ?> 
            <?php include'Model/Shared.php'; ?> 
            <?php include'Model/SingleJoc.php'; ?>

<script type="text/javascript">
            $(document).ready(function () {
                $('.fancybox').fancybox();

                $(".fancybox-effects-b").fancybox({
                    openEffect: 'none',
                    closeEffect: 'none',
                    helpers: {
                        title: {
                            type: 'over'
                        }
                    }
                });
                $(".fancybox-effects-c").fancybox({
                    openEffect: 'none',
                    closeEffect: 'none',
                    helpers: {
                        title: {
                            type: 'over'
                        }
                    }
                });
                $(".fancybox-effects-d").fancybox({
                    openEffect: 'none',
                    closeEffect: 'none',
                    helpers: {
                        title: {
                            type: 'over'
                        }
                    }
                });

                $("#fancybox-manual-b").click(function () {
                    $.fancybox.open({
                        href: 'info.php',
                        type: 'iframe',
                        padding: 5
                    });
                });
                $("#fancybox-manual-c").click(function () {
                    $.fancybox.open({
                        href: 'statistici.php',
                        type: 'iframe',
                        padding: 5
                    });
                });
                $("#fancybox-manual-d").click(function () {
                    $.fancybox.open({
                        href: 'clasament.php',
                        type: 'iframe',
                        padding: 5
                    });
                });


            });
        </script>
 

        </HEAD>
        <BODY>
<!-- Bara de navigare -->
        <div>
            <nav class="navbar">
                <div class="container-fluid">
                    <div class="navbar-header ">
                        <a class="navbar-brand" href="menu.php">Fun Web</a>
                    </div>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#" class= "dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user" ></span> <?php echo $_SESSION['my_user'] . "  " ?> </a>
                            <ul class="dropdown-menu">
                                <li><a id="fancybox-manual-b" href="javascript:;">Profile Info </a></li>
                                <li><a id="fancybox-manual-d" href="javascript:;">Clasament</a></li>
                                <li><a id="fancybox-manual-c" href="javascript:;">Statistics</a></li>
                            </ul>
                        </li>

                    </ul>
                </div>
            </nav>
        </div>

            
<table id="continut">
        <tr><td>
        	<div class="w3-card-12">
            	<?php finalSinglePage(); ?>
        	</div>
            </td>
        </tr>
	<tr><td>
        	<div class="w3-card-12">
            	<?php echo raport(); ?>
        	</div>
	    </td>
        </tr>
        </table>
<?php 
updatePunctaj();
unset($_SESSION['id_joc']); 
unset($_SESSION['nr_corecte']);
unset($_SESSION['nr_gresite']);
unset($_SESSION['scor']);
unset($_SESSION['raport_raspunsuri']); 
unset($_SESSION['enunturi']);
unset($_SESSION['raspunsuri_date']);
unset($_SESSION['raspunsuri_corecte']);
?>

        </BODY>
    </HTML>