<!DOCTYPE html>
<html lang="en">
    <head>
        <title>FunWeb</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!--import CSS -->
        <link rel="stylesheet" href="bootstrap-3.3.6\dist\css\bootstrap.min.css"> 
        <link href="css\index.css" rel="stylesheet">

        <!-- Add jQuery library -->
        <script type="text/javascript" src="fancybox/lib/jquery-1.10.1.min.js"></script>

        <!-- Add mousewheel plugin (this is optional) -->
        <script type="text/javascript" src="fancybox/lib/jquery.mousewheel-3.0.6.pack.js"></script>

        <!-- Add fancyBox main JS and CSS files -->
        <script type="text/javascript" src="fancybox/source/jquery.fancybox.js?v=2.1.5"></script>
        <link rel="stylesheet" type="text/css" href="fancybox/source/jquery.fancybox.css?v=2.1.5" media="screen" />

        <!-- Add Button helper (this is optional) -->
        <link rel="stylesheet" type="text/css" href="fancybox/source/helpers/jquery.fancybox-buttons.css?v=1.0.5" />
        <script type="text/javascript" src="fancybox/source/helpers/jquery.fancybox-buttons.js?v=1.0.5"></script>

        <!-- Add Thumbnail helper (this is optional) -->
        <link rel="stylesheet" type="text/css" href="fancybox/source/helpers/jquery.fancybox-thumbs.css?v=1.0.7" />
        <script type="text/javascript" src="fancybox/source/helpers/jquery.fancybox-thumbs.js?v=1.0.7"></script>

        <!-- Add Media helper (this is optional) -->
        <script type="text/javascript" src="fancybox/source/helpers/jquery.fancybox-media.js?v=1.0.6"></script>

        <script type="text/javascript">
            $(document).ready(function () {
                $('.fancybox').fancybox();

                $(".fancybox-effects-b").fancybox({
                    openEffect: 'none',
                    closeEffect: 'none',
                    helpers: {
                        title: {
                            type: 'over'
                        }
                    }
                });
                $(".fancybox-effects-c").fancybox({
                    openEffect: 'none',
                    closeEffect: 'none',
                    helpers: {
                        title: {
                            type: 'over'
                        }
                    }
                });

                $("#fancybox-manual-b").click(function () {
                    $.fancybox.open({
                        href: 'login.php',
                        type: 'iframe',
                        padding: 5
                    });
                });
                $("#fancybox-manual-c").click(function () {
                    $.fancybox.open({
                        href: 'register.php',
                        type: 'iframe',
                        padding: 5
                    });
                });

            });
        </script>

<script>


  
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '688266017982990',
      status : true, // check login status
    cookie : true, // enable cookies to allow the server to access the session
    xfbml  : true, // parse XFBML
      version    : 'v2.5',
oauth  : true // enable OAuth 2.0

    });
testAPI();	

  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "//connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));

 function testAPI() {

    
FB.getLoginStatus(function(response) {
  if (response.status === 'connected') {

                self.location = "menu.php";
            

    // the user is logged in and has authenticated your
    // app, and response.authResponse supplies
    // the user's ID, a valid access token, a signed
    // request, and the time the access token 
    // and signed request each expire
    var uid = response.authResponse.userID;
    var accessToken = response.authResponse.accessToken;
  } else if (response.status === 'not_authorized') {

          
    // the user is logged in to Facebook, 
    // but has not authenticated your app
  } else {
    // the user isn't logged in to Facebook.
          

  }
 });

};

</script>
        
    </head>
    
    <body>
        
        <div >
            <h2>FUN WEB</h2>

        </div>

        <div id = "Login_Register">
            <a id="fancybox-manual-b" href="javascript:;"><button  class="btn btn-primary" >Login </button></a>
            <br></br>
            <a id="fancybox-manual-c" href="javascript:;"><button  class="btn btn-primary" >Register</button></a>
	    <br>
	    <br>
	    
	    <a href="">How to use application</a>
        </div>

        
    </body>
</html>
