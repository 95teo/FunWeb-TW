<?php 
function connect() {
    //datele pt conectare
    $servername = "mysql.unlimitedfunweb.tk";
    $username = "gfkiller407";
    $password = "Informatica1";
    $dbname = "unlimitedfun_fun";
    // creaza conexiune
    $conn = new mysqli($servername, $username, $password, $dbname);
    //verifica conexiune
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
        //return -1;
    }
    return $conn;
}

function getInfoUsers(){
    //creaza conexiune la baza de date
  $conn=connect();
    //preluam username jucator din sesiune
  $jucatorCurent=$_SESSION["my_user"];

  $stmt =  mysqli_prepare($conn, "SELECT NUME,PRENUME,USERNAME,DATA_NASTERE,EMAIL from UTILIZATORI WHERE USERNAME=?");
  mysqli_stmt_bind_param($stmt,'s',$jucatorCurent);
  $stmt->execute();
  $stmt->bind_result($nume,$prenume,$username,$data_nastere,$email);
  $stmt->fetch();
  mysqli_stmt_free_result($stmt);
  mysqli_close($conn);
  print '<script>
  $(function(){
    $("#nume").val("'.$nume.'");
  });
</script>'; 
print '<script>
$(function(){
  $("#prenume").val("'.$prenume.'");
});
</script>';
print '<script>
$(function(){
  $("#user").val("'.$username.'");
});
</script>';
print '<script>
$(function(){
  $("#data_nastere").val("'.$data_nastere.'");
});
</script>';

print '<script>
$(function(){
  $("#email").val("'.$email.'");
});
</script>';

}

function modifica(){
    //daca s-a apasat butonul pt salvare modificari
  if(isset($_POST['aplica_modificari'])){
    //creaza conexiune la baza de date
    $conn=connect();
    //preia username-ul jucatorului curent
    $jucatorCurent=$_SESSION["my_user"];
    //preluam datele din campuri
    $nume=$_POST['nume'];
    $prenume=$_POST['prenume'];
    $data_nastere=$_POST['data_nastere'];
    $email=$_POST['email'];
    //salveaza modiifcarile in baza de date
    $stmt =  mysqli_prepare($conn, "UPDATE UTILIZATORI SET NUME=?, PRENUME=?, DATA_NASTERE=?, EMAIL=? WHERE USERNAME=?");
    //BIND parametri din operatia catre baza de date
    mysqli_stmt_bind_param($stmt,'sssss',$nume,$prenume,$data_nastere,$email,$jucatorCurent);
    $stmt->execute();
    mysqli_stmt_free_result($stmt);
    mysqli_close($conn);
    print '<script>$(function() {
      $("#succes_info").show();
    });</script>';


  }

}


function modificaParola(){
    //verifica daca a fos apasat butonul
  if(isset($_POST['change_pass'])){
        //preia datele din campuri
   $old_pass=$_POST['old_pass'];
   $new_pass=$_POST['new_pass'];
   $new_pass_confirm= $_POST['new_pass_confirm'];
       //realizeaza conexiunea la baza de date
   $conn= connect();
       //PREIA username-ul utilizatorului curent din sesiune
   $jucatorCurent= $_SESSION['my_user'];

       //stabilim operatia catre bd
   $selectParola = "SELECT PAROLA FROM UTILIZATORI WHERE USERNAME =?";
   $stmt=mysqli_prepare($conn, $selectParola);
       //bind parametri select
   mysqli_stmt_bind_param($stmt,'s',$jucatorCurent);
       //executam operatia
   $stmt->execute();
       //extragem rezultatele
   $stmt->bind_result($parola);
   $stmt->fetch();
       //eliberam statementul
   mysqli_stmt_free_result($stmt);
       //verifcam daca a introdus corect parola curenta
   if($old_pass==$parola){
        //verificam daca noua parola coincide in ambele campuri

     if(($new_pass==$new_pass_confirm)  && strlen($new_pass)>4){
       $stmt=mysqli_prepare($conn,"UPDATE UTILIZATORI SET PAROLA= ? WHERE USERNAME = ?");
                //bind parametri select
       mysqli_stmt_bind_param($stmt,'ss',$new_pass,$jucatorCurent);
                //executam operatia
       $stmt->execute();
                //eliberam statement
       mysqli_stmt_free_result($stmt);
                //inchidem conexiunea
       mysqli_close($conn);
                //afisam un mesaj de succes
       print '<script>$(function() {
        $("#succes_pass").show();
      });</script>';
    }
    else{
            //evidentiem cele doua campuri deoarece parola nu a fost confirmata corespunzator
      print "<script>
      $('#parola,#rescrie_parola').css('background-color', '#FFB6C1');
    </script>";
  }
}
       //indicam faptul ca userul si-a gresit parola
else print "<script>
 $(document).ready(function(){
  $('[data-toggle=\"popover\"]').popover(\"show\");   
});
</script>";
}
}

function clasament(){
        //creem o conexiune
  $conn=connect();
        //PREIA username-ul utilizatorului curent din sesiune
  $jucatorCurent= $_SESSION['my_user'];
        //pregatim soperatia de select
  $stmt=mysqli_prepare($conn, "SELECT * FROM CLASAMENT ORDER BY PUNCTAJ DESC");

        //executam operatia
  $stmt->execute();
        //extragem rezultatele
  $stmt->bind_result($user,$punctaj,$nivel);
  $loc=1;
  while($stmt->fetch()){
            //evidentiem utilizatorul curent
    if($user==$jucatorCurent){
      print '<tr class="success">
      <td><b>'.$user.'</b></td>
      <td><b>'.$punctaj.'</b></td>
      <td><b>'.$nivel.'</b></td>    
    </tr>';
  }else
            //completam tabelul cu ceilalti utilizatori
  print '<tr>
  <td>'.$user.'</td>
  <td>'.$punctaj.'</td>
  <td>'.$nivel.'</td>    
</tr>';
}
        //eliberam conexiunea
mysqli_stmt_free_result($stmt);
mysqli_close($conn);
}

function clasamentSpecificat(){

}
function finalMultiPage(){
        //creem o conexiune
  $conn=connect();
        //PREIA username-ul utilizatorului curent din sesiune
  $id_joc= $_SESSION['id_joc'];
        //pregatim soperatia de select
  $select= "SELECT USER1,USER2,USER3,CORECTE_1,CORECTE_2,CORECTE_3,NR_INTREBARI FROM PARTIDE_DE_JOC WHERE ID_JOC= ?";
  $stmt =  mysqli_prepare($conn, $select);
  mysqli_stmt_bind_param($stmt,'d',$id_joc);

        //executam operatia
  $stmt->execute();
        //extragem rezultatele
  $stmt->bind_result($user1,$user2,$user3,$corecte1,$corecte2,$corecte3,$nr_total_intrebari);
  $stmt->fetch();
       

  $gresite1 = $nr_total_intrebari - $corecte1;
  $gresite2 = $nr_total_intrebari - $corecte2;
  $gresite3 = $nr_total_intrebari - $corecte3;
  
 //desenam graficul
  print "<script type=\"text/javascript\" src=\"https://www.gstatic.com/charts/loader.js\"></script>

  <!-- load Google AJAX API -->
  <script type=\"text/javascript\" src=\"http://www.google.com/jsapi\"></script>


  <script type=\"text/javascript\">

   google.charts.load('current', {'packages':['bar']});
   google.charts.setOnLoadCallback(drawStuff);

   function drawStuff() {

    var data = new google.visualization.arrayToDataTable([
    ['Rezultate Joc', 'Right answers', 'Wrong answers'],
    [ '".$user1. "' , " .$corecte1." , ".$gresite1." ],
    [ '".$user2."' , ".$corecte2." , ".$gresite2."],
    ['".$user3."' , ".$corecte3." , ".$gresite3."],
    ]);

    var options = {
      width: 900,
      height: 500,
      chart: {

      },
      colors: ['#1AAF5D', '#8E0000'],
      
    };

    var chart = new google.charts.Bar(document.getElementById('dual_y_div'));
    chart.draw(data, options);
  };
</script>

<div id=\"dual_y_div\" ></div>
";
}

function getNrSingle(){
  //creem o conexiune
  $conn=connect();
        //PREIA username-ul utilizatorului curent din sesiune
  $jucatorCurent=$_SESSION["my_user"];
        //pregatim soperatia de select  
  $stmt=mysqli_prepare($conn, "SELECT COUNT(*) FROM JOC_SINGLE WHERE USER = ?");
  mysqli_stmt_bind_param($stmt,'s',$jucatorCurent);
        //executam operatia
  $stmt->execute();
        //extragem rezultatele
  $stmt->bind_result($nr_single);
  $stmt->fetch();
        //eliberam conexiunea
  mysqli_stmt_free_result($stmt);
  mysqli_close($conn);
  return $nr_single;
}
function getNrMulti(){
        //creem o conexiune
  $conn=connect();
        //PREIA username-ul utilizatorului curent din sesiune
  $jucatorCurent=$_SESSION["my_user"];
        //pregatim soperatia de select
        //Partide_de_joc joc_single

  $stmt=mysqli_prepare($conn, "SELECT COUNT(*) FROM PARTIDE_DE_JOC WHERE USER1 = ? OR USER2 = ? OR USER3 = ?");
  mysqli_stmt_bind_param($stmt,'sss',$jucatorCurent,$jucatorCurent,$jucatorCurent);
        //executam operatia
  $stmt->execute();
        //extragem rezultatele
  $stmt->bind_result($nr_multi);
  $stmt->fetch();
        //eliberam conexiunea
  mysqli_stmt_free_result($stmt);
  mysqli_close($conn);
  return $nr_multi;
}
function getLastGameDateSingle(){
      //creem o conexiune
  $conn=connect();
        //PREIA username-ul utilizatorului curent din sesiune
  $jucatorCurent=$_SESSION["my_user"];
        //pregatim soperatia de select

  $stmt=mysqli_prepare($conn, "SELECT MAX( DATA_JOC ) FROM JOC_SINGLE WHERE USER = ?");
  mysqli_stmt_bind_param($stmt,'s',$jucatorCurent);
        //executam operatia
  $stmt->execute();
        //extragem rezultatele
  $stmt->bind_result($lastGame);
  $stmt->fetch();
        //eliberam conexiunea
  mysqli_stmt_free_result($stmt);
  mysqli_close($conn);
  return $lastGame;
}

function getLastGameDateMulti(){
      //creem o conexiune
  $conn=connect();
        //PREIA username-ul utilizatorului curent din sesiune
  $jucatorCurent=$_SESSION["my_user"];
        //pregatim soperatia de select

  $stmt=mysqli_prepare($conn, "SELECT MAX( DATA_JOC ) FROM PARTIDE_DE_JOC WHERE USER1 = ? OR USER2 = ? OR USER3 = ?");
  mysqli_stmt_bind_param($stmt,'sss',$jucatorCurent,$jucatorCurent,$jucatorCurent);
        //executam operatia
  $stmt->execute();
        //extragem rezultatele
  $stmt->bind_result($lastGame);
  $stmt->fetch();
        //eliberam conexiunea
  mysqli_stmt_free_result($stmt);
  mysqli_close($conn);
  return $lastGame;
}

function getFromClasamet(){
      //creem o conexiune
  $conn=connect();
        //PREIA username-ul utilizatorului curent din sesiune
  $jucatorCurent=$_SESSION["my_user"];
        //pregatim soperatia de select
  $stmt=mysqli_prepare($conn, "SELECT NIVEL,PUNCTAJ FROM CLASAMENT WHERE USERNAME = ?");
  mysqli_stmt_bind_param($stmt,'s',$jucatorCurent);
        //executam operatia
  $stmt->execute();
        //extragem rezultatele
  $stmt->bind_result($nivel,$punctaj);
  $stmt->fetch();
        //eliberam conexiunea
  mysqli_stmt_free_result($stmt);
  mysqli_close($conn);

  print "<tr>
  <td>Level</td>
  <td>".$nivel."</td>
</tr>
<tr>
  <td>Score</td>
  <td>".$punctaj."</td>
</tr>";
}

function updateCastigator(){
        //creem o conexiune
  $conn=connect();
        //PREIA username-ul utilizatorului curent din sesiune
  $id_joc=$_SESSION["id_joc"];
        //pregatim soperatia de select
  $stmt=mysqli_prepare($conn, "SELECT PUNCTAJ_USER1,PUNCTAJ_USER2,PUNCTAJ_USER3 FROM PARTIDE_DE_JOC WHERE ID_JOC = ? ");
  mysqli_stmt_bind_param($stmt,'s',$id_joc);
        //executam operatia
  $stmt->execute();
        //extragem rezultatele
  $stmt->bind_result($punctaj1,$punctaj2,$punctaj3);
  $stmt -> fetch();
        //stabilim castigatorul
  $punctaje = array($punctaj1,$punctaj2,$punctaj3);
  $max = max($punctaje);
  $castigatori = "";
  for($i = 0 ; $i < sizeof($punctaje) ; $i++){
    if($max == $castigator){
     $castigatori = $castigatori."1";
   }else {
    $castigatori = $castigatori."0";
  }
}

        //eliberam conexiunea
mysqli_stmt_free_result($stmt);

$stmt=mysqli_prepare($conn, "UPDATE PARTIDE_DE_JOC SET CASTIGATORI = ? WHERE ID_JOC = ? ");
mysqli_stmt_bind_param($stmt,'ss',$castigatori,$id_joc);
        //executam operatia
$stmt->execute();
mysqli_stmt_free_result($stmt);
mysqli_close($conn);

}

function updatePunctaj(){//SE FACE UPDATE IN CLASAMENT PENTRU UTILIZATRUL CURENT
  $conn=connect();
        //PREIA username-ul utilizatorului curent din sesiune
  $id_joc=$_SESSION["my_user"];
  //selectam punctajul jocului curent din partide de joc
  $conn=connect();
        //PREIA username-ul utilizatorului curent din sesiune
        //pregatim soperatia de select
  $stmt=mysqli_prepare($conn, "SELECT USER".$_SESSION['nr_jucator']." FROM PARTIDE_DE_JOC WHERE ID_JOC = ?");
  mysqli_stmt_bind_param($stmt,'s',$id_joc);
        //executam operatia
  $stmt->execute();
        //extragem rezultatele
  $stmt->bind_result($punctaj);
  $stmt->fetch();
        //eliberam conexiunea
  mysqli_stmt_free_result($stmt);
  //update in clasament
        //pregatim operatia de select
  $stmt=mysqli_prepare($conn, "UPDATE CLASAMENT SET PUNCTAJ = ? WHERE USERNAME = ?");
  mysqli_stmt_bind_param($stmt,'ss',$punctaj,$jucatorCurent);
        //executam operatia
  $stmt->execute();
        //eliberam conexiunea
  mysqli_stmt_free_result($stmt);
  mysqli_close($conn);
}

function getCastigatori(){
  $conn=connect();
   //PREIA username-ul utilizatorului curent din sesiune
  $id_joc=$_SESSION["id_joc"];
  //selectam punctajul jocului curent din partide de joc
  $conn=connect();
  //PREIA username-ul utilizatorului curent din sesiune
  //pregatim soperatia de select
  $stmt=mysqli_prepare($conn, "SELECT USER1,USER2,USER3,CASTIGATORI FROM PARTIDE_DE_JOC WHERE ID_JOC = ?");
  mysqli_stmt_bind_param($stmt,'s',$id_joc);
        //executam operatia
  $stmt->execute();
        //extragem rezultatele
  $stmt->bind_result($user1,$user2,$user3,$castigatori);
  $stmt->fetch();
  $display_winners="<div ><b>";
  if(substr($castigatori,0,1) =="1"){
    $display_winners=$display_winners.$user1."<br>";
  }
  if(substr($castigatori,1,1) =="1"){
    $display_winners=$display_winners.$user1."<br>";
  }
  if(substr($castigatori,2,1) =="1"){
    $display_winners=$display_winners.$user1."<br>";
  }
  $display_winners=$display_winners.$user1."</b></div>";
  
  //eliberam conexiunea
  mysqli_stmt_free_result($stmt);
  mysqli_close($conn);
  print $display_winners;

}

function raportMulti(){
    $enunturi = $_SESSION['enunturi'];
    $raspunsuri_date = $_SESSION['raspunsuri_date'];
    $raspunsuri_corecte = $_SESSION['raspunsuri_corecte'];
    $raport_raspunsuri = $_SESSION['raport_raspunsuri'];
    $raport = "<div class=\"w3-card-2\"><table>";
    for ($i = 0; $i < sizeof($enunturi); $i++) {
        if ($raport_raspunsuri[$i] === " gresit ") {
            $raport = $raport . "<tr><td><img class=\"icon \" src=\"multimedia/wrong.svg\" ></td><td><b><div><p>" . $enunturi[$i] ."</p></div>
		<div class=\"wrong\">
    	Your answer: ". $raspunsuri_date[$i] . "</div>
		<div>Right answer: " . $raspunsuri_corecte[$i] ."</div></td></b></tr>";
        }
        else if($raport_raspunsuri[$i] === " corect "){
            $raport = $raport ."<tr> <td><img class=\"icon \"src=\"multimedia/green.svg\" ></td><td><b>
	<div><p>". $enunturi[$i] ."</p></div>
    <div class=\"right\">  Your right answer: ". $raspunsuri_date[$i] ."</div></td></b></tr>" ;
        }
    }
    
    $raport=$raport."</b></table></div>";
    
    return $raport;
}
?>

