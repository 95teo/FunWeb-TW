<?php

function createSingleGame() {
   
    if (isset($_POST['Start'])) {
       
        initializareRaport();
// Create connection
        $ok = 0;
        $domenii = array();
        if (!empty($_POST['chk1'])) {
            array_push($domenii, "html");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }
        if (!empty($_POST['chk2'])) {
            array_push($domenii, "angular");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }
        if (!empty($_POST['chk3'])) {
            array_push($domenii, "php");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }
        if (!empty($_POST['chk4'])) {
            array_push($domenii, "css");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }
        if (!empty($_POST['chk5'])) {
            array_push($domenii, "ajax");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }
        if (!empty($_POST['chk6'])) {
            array_push($domenii, "js");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }
        if (!empty($_POST['chk7'])) {
            array_push($domenii, "http");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }
        if (!empty($_POST['chk8'])) {
            array_push($domenii, "xml");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }
        $nr_intrebari = $_POST['questions'];

        if ($ok == 0) {
            unset($domenii);
            $domenii = array();
            array_push($domenii, "html");
            array_push($domenii, "angular");
            array_push($domenii, "php");
            array_push($domenii, "css");
            array_push($domenii, "js");
            array_push($domenii, "http");
            array_push($domenii, "ajax");
            array_push($domenii, "xml");
        }
        $all_dom = "";
        $prim = 0;
        for ($i = 0; $i < sizeof($domenii); $i++) {
            if ($domenii[$i] != "") {
                if ($prim == 0) {
                    $all_dom = $all_dom . $domenii[$i];
                    $prim = 1;
                } else
                    $all_dom = $all_dom . "," . $domenii[$i];
            }
        }

        $conn = connect();
        $autor = $_SESSION['my_user'];
        $stmt = mysqli_prepare($conn, "INSERT INTO JOC_SINGLE
        (USER,DOMENII_ALESE,NR_INTREBARI,PUNCTAJ,DURATA)
        VALUES (?,?,?,0,null)");
        mysqli_stmt_bind_param($stmt, 'ssd', $autor, $all_dom, $nr_intrebari);
        mysqli_stmt_execute($stmt);

        //sa punem id-ul jocului in sesiune
        mysqli_stmt_free_result($stmt);
        $jucatorCreator = $_SESSION["my_user"];

        $stmt = mysqli_prepare($conn, "SELECT ID_JOC FROM JOC_SINGLE WHERE USER=? ORDER BY DATA_JOC DESC LIMIT 1 ");
        mysqli_stmt_bind_param($stmt, 's', $jucatorCreator);
        $stmt->execute();

        $stmt->bind_result($id_joc);
        $stmt->fetch();
        
        $_SESSION['id_joc'] = $id_joc;
        $_SESSION['nr_intrebari'] = $nr_intrebari;
        $_SESSION['nr_corecte'] = 0;
        $_SESSION['nr_gresite'] = 0;
        $_SESSION['scor'] = 0;
       
        mysqli_stmt_free_result($stmt);
        //////////////////$$
                $intrebarile_jocului = getQuestion($nr_intrebari);
                mysqli_stmt_free_result($stmt);

                $updateLaIntrebari = "UPDATE JOC_SINGLE SET INTREBARI = '" . $intrebarile_jocului . "' WHERE ID_JOC= " . $id_joc;

                $stmt = mysqli_prepare($conn, $updateLaIntrebari);
                mysqli_stmt_execute($stmt);

                //sa punem id-ul jocului in sesiune
                mysqli_stmt_free_result($stmt);

                $_SESSION['index_intrebare'] = $nr_intrebari;
        /////////////////$$
        
        print "<script>";
        print "self.location = 'single_joc.php';";
        print "</script>";
        
        

        mysqli_close($conn);
    }
}

function getQuestion_single() {

// Create connection
    $conn = connect();
// Check connection

    $id_joc = $_SESSION['id_joc'];
    // echo "id joc ".$id_joc;
    $stmt = mysqli_prepare($conn, "SELECT DOMENII_ALESE FROM JOC_SINGLE WHERE ID_JOC=?");
    mysqli_stmt_bind_param($stmt, 's', $id_joc);
    $stmt->execute();
    $stmt->bind_result($domenii_alese);
    $stmt->fetch();
    // echo "\n Domenii alese *".$domenii_alese."*\n";

    $domenii_alese_array = array();
    $domenii_alese_array = explode(",", $domenii_alese);
    $multime_domenii = "";


    if (sizeof($domenii_alese_array) == 1) {
        $multime_domenii = $domenii_alese_array[0];
    } else {
        if (sizeof($domenii_alese_array) == 2) {
            $multime_domenii = $domenii_alese_array[0] . "','" . $domenii_alese_array[1];
        } else {
            $multime_domenii = $domenii_alese_array[0] . "',";
            for ($i = 1; $i < sizeof($domenii_alese_array) - 2; $i++) {
                $multime_domenii = $multime_domenii . "'" . $domenii_alese_array[$i] . "',";
            }
            $multime_domenii = $multime_domenii . "'" . $domenii_alese_array[$i];
        }
    }

    
    

    mysqli_stmt_free_result($stmt);
    $interogare = "SELECT ID_INTREBARE FROM INTREBARI WHERE DOMENIU IN ( '" . $multime_domenii . "' ) ORDER BY RAND() LIMIT 1";
    // print "\n".$interogare."\n";
    $stmt = mysqli_prepare($conn, $interogare);
    //mysqli_stmt_bind_param($stmt,'s',$multime_domenii);
    $stmt->execute();
    $stmt->bind_result($id_intrebare);
    $stmt->fetch();
    // echo "\n Id intrebare : ".$id_intrebare."\n";
    //     printf ("%d \n", $numar);
    // }   
    $_SESSION["id_intrebare"] = $id_intrebare;
    // echo "Id: ".$id_intrebare."id din sesiune : ".$_SESSION['id_intrebare']."\n";
    return $id_intrebare;
    mysqli_close($conn);
}

function completeazaCampuri_single() {
    //stabilim conexiunea la BD
    $conn = connect();
    //preluam id-ul jocului din sesiune
    $id_joc = $_SESSION['id_joc'];

    //preluam indexul intrebarii curente din sesiune
    $index_intrebare = $_SESSION['index_intrebare'];
    //preluam array-ul cu id-urile intrebarilor
    $id_intrebari_array = getIntrebariJoc($id_joc);

    if ($index_intrebare >= 0) {
        
        //preluam id-ul intrebarii de la indexul de intrebare curent
        $intrebare_curenta = $id_intrebari_array[$index_intrebare - 1];
        //facem selectul pentru id-ul intrebarii curente
        $stmt = mysqli_prepare($conn, "SELECT ENUNT,VARIANTA_A,VARIANTA_B,VARIANTA_C,VARIANTA_D,RASPUNS_CORECT,DIFICULTATE,TIMP FROM INTREBARI WHERE ID_INTREBARE= ? ");
        mysqli_stmt_bind_param($stmt, 's', $intrebare_curenta);
        $stmt->execute();
        $stmt->bind_result($enunt, $a, $b, $c, $d, $raspuns_corect, $dificultate, $timp);
        $stmt->fetch();
        //pastram raspunsul corect in sesiune

        $_SESSION['raspuns_corect'] = $raspuns_corect;
        $_SESSION['timp'] = $timp;
        setTimer();
        //pastram enunturile si raspunsurile corecte pt raport

        array_push($_SESSION['enunturi'], array($enunt, $a, $b, $c, $d));

        enuntRaspuns($a, $b, $c, $d, $raspuns_corect);
        //pastram raspunsul corect in sesiune
        $_SESSION['dificultate'] = $dificultate;
        //eliberam statement
        mysqli_stmt_free_result($stmt);
        //inchidem conexiunea
        mysqli_close($conn);
        //printam enuntul si variantele de raspuns
        print "<div class=\"form-group\" id=\"enunt\"> 
      <label class=\"control-label\" > Question: " . $enunt . "</label
    </div>
    <hr>         
    
    <div class=\"form-group\">
      <label class=\"control-label \" > A)  " . htmlentities($a) . " </label> 
    </div>

    <div class=\"form-group\">
      <label class=\"control-label \" > B)  " . htmlentities($b) . " </label> 
    </div>

    <div class=\"form-group\">
      <label class=\"control-label \" > C)  " . htmlentities($c) . "</label>
      
    </div>
    
    <div class=\"form-group\" >
      <label class=\"control-label \" > D)  " . htmlentities($d) . "</label>
      
    </div>
    <div class=\"form-group\" >
      <label class=\"control-label \" > E) I dont't know </label>
      
    </div>";
    }
}
function verifyAnswer() {
    $raspuns_dat = '';
    $rapsuns_raport = '';
    if (isset($_POST['A'])) {
        $raspuns_dat = 'A';
        $raspuns_raport = 'A. ' . htmlentities($_SESSION['enunturi'][sizeof($_SESSION['enunturi']) - 1][1]);
    }
    if (isset($_POST['B'])) {
        $raspuns_dat = 'B';
        $raspuns_raport = 'B. ' . htmlentities($_SESSION['enunturi'][sizeof($_SESSION['enunturi']) - 1][2]);
    }
    if (isset($_POST['C'])) {
        $raspuns_dat = 'C';
        $raspuns_raport = 'C. ' . htmlentities($_SESSION['enunturi'][sizeof($_SESSION['enunturi']) - 1][3]);
    }
    if (isset($_POST['D'])) {
        $raspuns_dat = 'D';
        $raspuns_raport = 'D. ' . htmlentities($_SESSION['enunturi'][sizeof($_SESSION['enunturi']) - 1][4]);
    }
    if (isset($_POST['E'])) {
        $raspuns_dat = 'E';
        $raspuns_raport = 'E. No response';
    }
    if ($raspuns_dat != '') {
        array_push($_SESSION['raspunsuri_date'], $raspuns_raport);

        $_SESSION['index_intrebare'] = $_SESSION['index_intrebare'] - 1;
        $raspuns_corect = $_SESSION['raspuns_corect'];
              if ($raspuns_dat == $raspuns_corect) {//pastram datele pt raport: daca raspunsul curent este corect/gresit
            array_push($_SESSION['raport_raspunsuri'], " corect ");
            return true;
        } else {
            array_push($_SESSION['raport_raspunsuri'], " gresit ");
            return false;
        }
    }
}

function verifyAnswer_single() {
    if (verifyAnswer()) {
        updateSingle();
    }

    if ($_SESSION['index_intrebare'] == 0) {
        print "<script>";
        print "self.location = 'final_single.php';";
        print "</script>";
    }
}

function updateSingle() {
    $conn = connect();
    $dificultate = $_SESSION['dificultate'];
    $_SESSION['nr_corecte'] = $_SESSION['nr_corecte'] + 1;
    switch ($dificultate) {
        case 'e':
            $punctajCurent = 10;
            break;
        case 'm':
            $punctajCurent = 15;
            break;
        default:
            $punctajCurent = 20;
            break;
    }

    $_SESSION['scor'] = $_SESSION['scor'] + $punctajCurent;
    $update = "UPDATE JOC_SINGLE SET PUNCTAJ=PUNCTAJ +" . $punctajCurent . " WHERE ID_JOC=" . $_SESSION['id_joc'];

    $stmt = mysqli_prepare($conn, $update);

    $stmt->execute();


    mysqli_stmt_free_result($stmt);
    mysqli_close($conn);
}



function finalSinglePage() {
    //creem o conexiune
    $conn = connect();
    //PREIA username-ul utilizatorului curent din sesiune
    $id_joc = $_SESSION['id_joc'];
    //pregatim soperatia de select
    $select = "SELECT USER,NR_INTREBARI FROM JOC_SINGLE WHERE ID_JOC= ?";
    $stmt = mysqli_prepare($conn, $select);
    mysqli_stmt_bind_param($stmt, 'd', $id_joc);
    //executam operatia
    $stmt->execute();
    //extragem rezultatele
    $stmt->bind_result($user, $nr_total_intrebari);
    $stmt->fetch();

    $corecte = $_SESSION['nr_corecte'];
    $gresite = $nr_total_intrebari - $corecte;

    //desenam graficul
    print "<script type=\"text/javascript\" src=\"https://www.gstatic.com/charts/loader.js\"></script>

  <!-- load Google AJAX API -->
  <script type=\"text/javascript\" src=\"http://www.google.com/jsapi\"></script>


  <script type=\"text/javascript\">

   google.charts.load('current', {'packages':['bar']});
   google.charts.setOnLoadCallback(drawStuff);

   function drawStuff() {

    var data = new google.visualization.arrayToDataTable([
    ['      ', 'Right answers', 'Wrong answers'],
    [ '" . $user . "' , " . $corecte . " , " . $gresite . "],
    ]);

    var options = {
      width: 900,
      height: 500,
      bar: {groupWidth: 2},
      chart: {
        title:'    ',
      },
      
      colors: ['#1AAF5D', '#8E0000'],
      
    };
   
    var chart = new google.charts.Bar(document.getElementById('dual_y_div'));
    chart.draw(data, options);
  };
</script>

<div id=\"dual_y_div\" ></div>
";
}
function getIntrebariJoc($id_joc) {

    //stabilim conexiunea la BD
    $conn = connect();
    //facem selectul din BD
    $stmt = mysqli_prepare($conn, "SELECT INTREBARI FROM JOC_SINGLE WHERE ID_JOC= ? ");
    mysqli_stmt_bind_param($stmt, 'd', $id_joc);
    $stmt->execute();
    $stmt->bind_result($id_intrebari);
    $stmt->fetch();
    //punem idurile intrebarilor intr-un array
    $id_intrebari_array = array();
    $id_intrebari_array = explode(",", $id_intrebari);
    //eliberam statement
    mysqli_stmt_free_result($stmt);
    //inchidem conexiunea
    mysqli_close($conn);
    //returnam arrayul cu id-uri de interbari 
    return $id_intrebari_array;
}

function getQuestion($nr_intrebari) {

    $conn = connect();
    $id_joc = $_SESSION['id_joc'];

    $stmt = mysqli_prepare($conn, "SELECT DOMENII_ALESE FROM JOC_SINGLE WHERE ID_JOC=?");
    mysqli_stmt_bind_param($stmt, 'd', $id_joc);
    $stmt->execute();
    $stmt->bind_result($domenii_alese);
    $stmt->fetch();


    $domenii_alese_array = array();
    $domenii_alese_array = explode(",", $domenii_alese);
    $multime_domenii = "";


    if (sizeof($domenii_alese_array) == 1) {
        $multime_domenii = $domenii_alese_array[0];
    } else {
        if (sizeof($domenii_alese_array) == 2) {
            $multime_domenii = $domenii_alese_array[0] . "','" . $domenii_alese_array[1];
        } else {
            $multime_domenii = $domenii_alese_array[0] . "',";
            for ($i = 1; $i < sizeof($domenii_alese_array) - 1; $i++) {
                $multime_domenii = $multime_domenii . "'" . $domenii_alese_array[$i] . "',";
            }
            $multime_domenii = $multime_domenii . "'" . $domenii_alese_array[$i];
        }
    }


    mysqli_stmt_free_result($stmt);
    $interogare = "SELECT ID_INTREBARE FROM INTREBARI WHERE DOMENIU IN ( '" . $multime_domenii . "' ) ORDER BY RAND() LIMIT " . $nr_intrebari;

    $stmt = mysqli_prepare($conn, $interogare);
    //mysqli_stmt_bind_param($stmt,'s',$multime_domenii);
    $stmt->execute();
    $stmt->bind_result($id_intrebare);
    //punem intrebarile selectate intr-un array
    $id_intrebari = array();
    while ($stmt->fetch()) {

        array_push($id_intrebari, $id_intrebare);
    }

    $id_intrebari_string = "";

    if (sizeof($id_intrebari) == 1) {
        $id_intrebari_string = $id_intrebari[0];
    } else {
        if (sizeof($id_intrebari) == 2) {
            $id_intrebari_string = $id_intrebari[0] . "," . $id_intrebari[1];
        } else {

            $id_intrebari_string = $id_intrebari[0] . ",";

            for ($i = 1; $i < sizeof($id_intrebari) - 1; $i++) {
                $id_intrebari_string = $id_intrebari_string . $id_intrebari[$i] . ",";
            }

            $id_intrebari_string = $id_intrebari_string . $id_intrebari[$i];
        }
    }

    return $id_intrebari_string;
}

function setTimer() {
    $timp = $_SESSION['timp'];
    print "<script>
    setTimeout(function(){ $( \"#E\" ).click(); }, " . $timp . "000+7000);"
            . "</script>";
}
function updatePunctaj() {//SE FACE UPDATE IN CLASAMENT PENTRU UTILIZATRUL CURENT
    $conn = connect();
    //PREIA username-ul utilizatorului curent din sesiune
    $jucatorCurent = $_SESSION["my_user"];
    //selectam punctajul jocului curent din partide de joc
    $conn = connect();
    $punctaj=$_SESSION['scor'];
        //pregatim operatia de update
    $stmt = mysqli_prepare($conn, "UPDATE CLASAMENT SET PUNCTAJ = PUNCTAJ + ? WHERE USERNAME = ?");
    mysqli_stmt_bind_param($stmt, 'ss', $punctaj, $jucatorCurent);
    //executam operatia
    $stmt->execute();
    //eliberam conexiunea
    mysqli_stmt_free_result($stmt);
    mysqli_close($conn);
}
?>