<?php
function createSingleGame(){
  $servername = "mysql.unlimitedfunweb.tk";
    $username = "gfkiller407";
    $password = "Informatica1";
    $dbname = "unlimitedfun_fun";
    if(isset($_POST['Start'])){
// Create connection
$ok=0;
        $domenii=array();
        if(!empty($_POST['chk1'])){
            array_push($domenii, "html");
$ok=1;
        }
        else{
            array_push($domenii, "");


        }
        if(!empty($_POST['chk2'])){
            array_push($domenii, "angular");
$ok=1;

        }
        else{
            array_push($domenii, "");
        }
        if(!empty($_POST['chk3'])){
            array_push($domenii, "php");
$ok=1;

        }
        else{
            array_push($domenii, "");
        }
        if(!empty($_POST['chk4'])){
            array_push($domenii, "css");
$ok=1;

        }
        else{
            array_push($domenii, "");
        } 
        if(!empty($_POST['chk5'])){
            array_push($domenii, "ajax");
$ok=1;

        }
        else{
            array_push($domenii, "");
        }
        if(!empty($_POST['chk6'])){
            array_push($domenii, "js");
$ok=1;

        }
        else{
            array_push($domenii,"");
        }
        if(!empty($_POST['chk7'])){
            array_push($domenii, "http");
$ok=1;

        }
        else{
            array_push($domenii, "");
        }
        if(!empty($_POST['chk8'])){
            array_push($domenii, "xml");
$ok=1;

        }
        else{
            array_push($domenii, "");
        }


if($ok==0){
unset($domenii);
$domenii=array();
array_push($domenii, "html");
array_push($domenii, "angular");
array_push($domenii, "php");
array_push($domenii, "css");
array_push($domenii, "js");
array_push($domenii, "http");
array_push($domenii, "ajax");
array_push($domenii, "xml");
}
        $all_dom="";
        $prim=0;
        for ($i=0;$i<sizeof($domenii);$i++){
           if($domenii[$i]!=""){
               if($prim==0){$all_dom=$all_dom.$domenii[$i];$prim=1;}
               else
                   $all_dom=$all_dom.",".$domenii[$i];
           }  
       }  

       $conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
       if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
   $autor=$_SESSION['my_user'];
    $stmt = mysqli_prepare($conn, "INSERT INTO JOC_SINGLE
        (USER,DOMENII_ALESE,NR_INTREBARI,PUNCTAJ,DURATA)
        VALUES (?,?,?,null,null)");
    mysqli_stmt_bind_param($stmt, 'ssd',$autor, $all_dom,$question_number);
    mysqli_stmt_execute($stmt);

     //sa punem id-ul jocului in sesiune
    mysqli_stmt_free_result($stmt);
    $jucatorCreator = $_SESSION["my_user"];

    $stmt =  mysqli_prepare($conn, "SELECT ID_JOC FROM JOC_SINGLE WHERE USER=? ORDER BY DATA_JOC DESC LIMIT 1 ");
    mysqli_stmt_bind_param($stmt,'s',$jucatorCreator);
    $stmt->execute();
     
    $stmt->bind_result($id_joc);
    $stmt->fetch();
   
    $_SESSION['id_joc']=$id_joc;
	$_SESSION['nr_corecte']=0;
	$_SESSION['scor']=0;
	$_SESSION['nr_gresite']=0;
	$_SESSION['intrebari_ramase']=5;
    mysqli_stmt_free_result($stmt);
    
	print "<script>";
            print "top.window.location = 'single_joc.php';";
            print "</script>";

mysqli_close($conn);  


}
}


  function getInfoUsers(){
 //datele de conectare la baza de date
  $servername = "mysql.unlimitedfunweb.tk";
    $username = "gfkiller407";
    $password = "Informatica1";
    $dbname = "unlimitedfun_fun";
// Create connection
    $conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $jucatorCurent=$_SESSION["my_user"];

    $stmt =  mysqli_prepare($conn, "SELECT NUME,PRENUME,USERNAME,DATA_NASTERE,EMAIL from UTILIZATORI WHERE USERNAME=?");
    mysqli_stmt_bind_param($stmt,'s',$jucatorCurent);
    $stmt->execute();
    $stmt->bind_result($nume,$prenume,$username,$data_nastere,$email);
    $stmt->fetch();
     print '<script>
 $(function(){
        $("#nume").val("'.$nume.'");
 });
 </script>'; 
 print '<script>
 $(function(){
        $("#prenume").val("'.$prenume.'");
 });
 </script>';
 print '<script>
 $(function(){
        $("#user").val("'.$username.'");
 });
 </script>';
    print '<script>
 $(function(){
        $("#data_nastere").val("'.$prenume.'");
 });
 </script>';

     print '<script>
 $(function(){
        $("#email").val("'.$email.'");
 });
 </script>';
mysqli_close($conn);

}
function login(){
   $servername = "mysql.unlimitedfunweb.tk";
    $username = "gfkiller407";
    $password = "Informatica1";
    $dbname = "unlimitedfun_fun";

    if(isset($_POST['Login'])){

// Create connection
        $conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        $user=$_POST['user'];
        $pass=$_POST['pwd'];
        $stmt =  mysqli_prepare($conn, "SELECT COUNT(*) from UTILIZATORI WHERE USERNAME=? and PAROLA=?");
        mysqli_stmt_bind_param($stmt, 'ss', $user,$pass);
        $stmt->execute();
        $stmt->bind_result($numar);
        while ($stmt->fetch()) {
            /*printf ("%d \n", $numar);*/
        }
        if($numar==0){
            echo 'Combinaţie user/parolă eronată! Reîncercaţi. ';
        }
        else {
            //$jucatorCurent=$_SESSION["my_user"];
            //mysqli_stmt_free_result($stmt);
            //$stmt =  mysqli_prepare($conn, "UPDATE UTILIZATORI SET STATUS = 'DISPONIBIL' WHERE USERNAME=?");
           // mysqli_stmt_bind_param($stmt,'s',$user);
           // $stmt->execute();
            mysqli_stmt_free_result($stmt);
            mysqli_close();
            echo "<script>";
            echo "top.window.location = 'menu.php';";
            echo "</script>";
            

}
mysqli_close($conn);
}

}

function register(){
  $servername = "mysql.unlimitedfunweb.tk";
    $username = "gfkiller407";
    $password = "Informatica1";
    $dbname = "unlimitedfun_fun";
    if(isset($_POST['Register'])){
// Create connection
        $conn = new mysqli($servername, $username, $password,$dbname);

// Check connection

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        $ok=1;
        $user=$_POST['user'];
        $pass=$_POST['parola'];
        $mail=$_POST['email'];
        $pass_confirm=$_POST['rescrie_parola'];

        if($user<4)$ok=0;
        if($pass<4)$ok=0;
        if($pass_confirm<4)$ok=0;
        if($pass==$pass_confirm)$ok=1; else $ok=0;
        if($ok==1){
           $stmt =  mysqli_prepare($conn, "SELECT COUNT(*) from UTILIZATORI WHERE USERNAME=?");
           mysqli_stmt_bind_param($stmt, 's', $user);
           $stmt->execute();
           $stmt->bind_result($numar);
           while ($stmt->fetch()) {
            /*printf ("%d \n", $numar);*/
        }
        if($numar==1){
            echo 'Sorry for that! The username is already taken. Please choose another one. ';
        }
        else {
            mysqli_stmt_free_result($stmt);
            $stmt = mysqli_prepare($conn, "INSERT INTO UTILIZATORI VALUES (null,null,null,?,?,?,null)");
            mysqli_stmt_bind_param($stmt, 'sss', $user,$pass,$mail);

            if(mysqli_stmt_execute($stmt)){



        mysqli_stmt_free_result($stmt);

$stmt =  mysqli_prepare($conn, "INSERT INTO CLASAMENT VALUES (?,0,'incepator') ");
     $_SESSION['my_user']=$_POST['user'];
     mysqli_stmt_bind_param($stmt,'s',$_POST['user']);
     $stmt->execute();

                echo "<script>";
                echo "top.window.location = 'menu.php';";
                echo "</script>";
            }
            else{
                echo 'Oups! Something unexpected happened.';
            }
}
}
else { echo "You haven't completed all the fields for register.";}
mysqli_close($conn);
}

}

function getOnlineUsers(){////////////////////////inca o coloana pentru cei online!!
  $servername = "mysql.unlimitedfunweb.tk";
    $username = "gfkiller407";
    $password = "Informatica1";
    $dbname = "unlimitedfun_fun";
// Create connection
    $conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    $stmt =  mysqli_prepare($conn, "SELECT USERNAME from UTILIZATORI WHERE STATUS = 'DISPONIBIL'");
    $stmt->execute();
    $stmt->bind_result($nume);
    $stmt->fetch();
    $jucatorCurent=$_SESSION["my_user"];
    if($nume != $jucatorCurent){
            printf ("{'word':'%s'}", $nume);
        }
    
    while ($stmt->fetch()) {
        if($nume != $jucatorCurent){
            printf (",\n");
            printf ("{'word':'%s'}", $nume);
        }
        
    }
mysqli_close($conn);

}

function getQuestion_single(){
  $servername = "mysql.unlimitedfunweb.tk";
    $username = "gfkiller407";
    $password = "Informatica1";
    $dbname = "unlimitedfun_fun";
// Create connection
        $conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        $id_joc = $_SESSION['id_joc'];
       // echo "id joc ".$id_joc;
        $stmt = mysqli_prepare($conn, "SELECT DOMENII_ALESE FROM JOC_SINGLE WHERE ID_JOC=?");
        mysqli_stmt_bind_param($stmt,'s',$id_joc);
        $stmt->execute();
        $stmt->bind_result($domenii_alese);
        $stmt->fetch();
       // echo "\n Domenii alese *".$domenii_alese."*\n";
        
        $domenii_alese_array =  array();
        $domenii_alese_array = explode(",",$domenii_alese);
        $multime_domenii="";
        

        if(sizeof($domenii_alese_array)==1){
            $multime_domenii = $domenii_alese_array[0];
        }else{
            if(sizeof($domenii_alese_array)==2){
            $multime_domenii = $domenii_alese_array[0]."','".$domenii_alese_array[1];
        }
        else{
            $multime_domenii = $domenii_alese_array[0]."',";
            for($i=1;$i<sizeof($domenii_alese_array)-2;$i++){
            $multime_domenii = $multime_domenii."'".$domenii_alese_array[$i]."',";
           }
           $multime_domenii = $multime_domenii."'".$domenii_alese_array[$i];

        }
        }

       // echo "\nDomeniile tale : ".$multime_domenii."\n";
       // echo $multime_domenii;
       // print_r (explode(",",$domenii_alese));
        
        mysqli_stmt_free_result($stmt);
        $interogare = "SELECT ID_INTREBARE FROM INTREBARI WHERE DOMENIU IN ( '".$multime_domenii."' ) ORDER BY RAND() LIMIT 1";
       // print "\n".$interogare."\n";
        $stmt =  mysqli_prepare($conn, $interogare);
        //mysqli_stmt_bind_param($stmt,'s',$multime_domenii);
        $stmt->execute();
        $stmt->bind_result($id_intrebare);
        $stmt->fetch() ;
      // echo "\n Id intrebare : ".$id_intrebare."\n";
       //     printf ("%d \n", $numar);
       // }   
        $_SESSION["id_intrebare"]=$id_intrebare;
       // echo "Id: ".$id_intrebare."id din sesiune : ".$_SESSION['id_intrebare']."\n";
        return $id_intrebare;
mysqli_close($conn);     
}


function completeazaCampuri_single(){
    $id_intrebare = getQuestion_single ();
  $servername = "mysql.unlimitedfunweb.tk";
    $username = "gfkiller407";
    $password = "Informatica1";
    $dbname = "unlimitedfun_fun";
// Create connection
        $conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
     
       // echo "id joc ".$id_joc;
        $stmt = mysqli_prepare($conn, "SELECT ENUNT,VARIANTA_A,VARIANTA_B,VARIANTA_C,VARIANTA_D,RASPUNS_CORECT FROM INTREBARI WHERE ID_INTREBARE= ? ");
        mysqli_stmt_bind_param($stmt,'s',$id_intrebare);
        $stmt->execute();
        $stmt->bind_result($enunt,$a,$b,$c,$d,$raspuns_corect);
        $stmt->fetch();
        $_SESSION['raspuns_corect']=$raspuns_corect;
         print "<div class=\"form-group\"><hr> 
      <label class=\"control-label\" > Question: ".$enunt."</label
    </div>
    <hr>
    
    <div class=\"form-group\">
      <label class=\"control-label \" > A)  ".htmlentities($a)." </label> 
    </div>

    <div class=\"form-group\">
      <label class=\"control-label \" > B)  ".htmlentities($b)." </label> 
    </div>

    <div class=\"form-group\">
      <label class=\"control-label \" > C)  ".htmlentities($c)."</label>
      
    </div>
    
    <div class=\"form-group\">
      <label class=\"control-label \" > D)  ".htmlentities($d)."</label>
      
    </div>";
mysqli_close($conn);
}

function getPartideDeJoc(){
  $servername = "mysql.unlimitedfunweb.tk";
    $username = "gfkiller407";
    $password = "Informatica1";
    $dbname = "unlimitedfun_fun";
// Create connection
    $conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    $stmt =  mysqli_prepare($conn, "SELECT USER1,USER2,USER3,STATUS_JOC FROM PARTIDE_DE_JOC WHERE STATUS_JOC=\"WAITING\"");
    $stmt->execute();
    $stmt->bind_result($user1,$user2,$user3,$status);

    while ($stmt->fetch()) {
        print '<form  method="POST">
        <div class="panel-body" >
                    <div class="panel panel-primary">
                      <div class="panel-heading">'.$user1.'</div>
                      <div class="panel-body">
                        <div>
                        <span class="label label-info" id="user">'.$user2.'</span>
                        <span class="label label-info" id="user">'.$user3.'</span>
                    </div>
                        <div class="input-group-btn">
                        
                       <button type="submit" class="join" id="JoinGame" name="joinGame"><span>Join Game</span></button>
                      </div>
                      </div>
                  </div>
              </div>
              <input type="hidden" name="autor_joc" value="'.$user1.'">
        </form>';
    }
mysqli_close($conn);

}


?>

