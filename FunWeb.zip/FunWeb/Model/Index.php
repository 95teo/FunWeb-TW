<?php

function login() {
    if (isset($_POST['Login'])) {
// Create connection
        $conn = connect();
        $user_ok = 0;
        $user = $_POST['user'];
        $pass = $_POST['pwd'];
        $stmt = mysqli_prepare($conn, "SELECT COUNT(*) from UTILIZATORI WHERE USERNAME=?");
        mysqli_stmt_bind_param($stmt, 's', $user);
        $stmt->execute();
        $stmt->bind_result($user_ok);
        $stmt->fetch();
        
        $login_ok=0;
        mysqli_stmt_free_result($stmt);
        $stmt = mysqli_prepare($conn, "SELECT COUNT(*) from UTILIZATORI WHERE USERNAME=? AND PAROLA=?");
        mysqli_stmt_bind_param($stmt, 'ss', $user, $pass);
        $stmt->execute();
        $stmt->bind_result($login_ok);
        $stmt->fetch();

        if (($login_ok == 0) && ($user_ok == 0)) {
            //toggle cu utilizator inexistent
            print "<script>
            $(document).ready(function(){
            $('#user').popover(\"show\"); 
            });
            </script>";
        } else if (($login_ok == 0) && ($user_ok > 0) ) {//toggle cu parola eronata
            //afisam mesaj
            print "<script>
            $(document).ready(function(){
            $('#pwd').popover(\"show\"); 
            });
            </script>";
            //completam campul
            print '<script>
            $(function(){
        $("#user").val("'.$user.'");
        });
        </script>';
        } else { //login  
            echo "<script>";
            echo "top.window.location = 'menu.php';";
            echo "</script>";
        }
        mysqli_close($conn);
    }
}

function register() {

    if (isset($_POST['Register'])) {
// Create connection
        $conn = connect();

        $ok = 1;
        $user = $_POST['user'];
        $pass = $_POST['parola'];
        $mail = $_POST['email'];
        $pass_confirm = $_POST['rescrie_parola'];

        if ($user < 4)
            $ok = 0;
        if ($pass < 4)
            $ok = 0;
        if ($pass_confirm < 4)
            $ok = 0;
        if ($pass == $pass_confirm)
            $ok = 1;
        else
            $ok = 0;
        if ($ok == 1) {
            $stmt = mysqli_prepare($conn, "SELECT COUNT(*) from UTILIZATORI WHERE USERNAME=?");
            mysqli_stmt_bind_param($stmt, 's', $user);
            $stmt->execute();
            $stmt->bind_result($numar);
            while ($stmt->fetch()) {
                /* printf ("%d \n", $numar); */
            }
            if ($numar == 1) {
                echo 'Sorry for that! The username is already taken. Please choose another one. ';
            } else {
                mysqli_stmt_free_result($stmt);
                $stmt = mysqli_prepare($conn, "INSERT INTO UTILIZATORI VALUES (null,null,null,?,?,?,null)");
                mysqli_stmt_bind_param($stmt, 'sss', $user, $pass, $mail);

                if (mysqli_stmt_execute($stmt)) {



                    mysqli_stmt_free_result($stmt);

                    $stmt = mysqli_prepare($conn, "INSERT INTO CLASAMENT VALUES (?,0,'incepator') ");
                    $_SESSION['my_user'] = $_POST['user'];
                    mysqli_stmt_bind_param($stmt, 's', $_POST['user']);
                    $stmt->execute();

                    echo "<script>";
                    echo "top.window.location = 'menu.php';";
                    echo "</script>";
                } else {
                    echo 'Oups! Something unexpected happened.';
                }
            }
        } else {
            echo "You haven't completed all the fields for register.";
        }
        mysqli_close($conn);
    }
}

?>