<?php
function FB_Login(){


if(isset($_POST['name'])){
$conn = connect();
$_SESSION['my_user']=$_POST['name'];
  $name = $_POST['name'];
$email = $_POST['email'];

$pass = '123456';
// Create connection
        
           $stmt =  mysqli_prepare($conn, "SELECT COUNT(*) from UTILIZATORI WHERE USERNAME=?");
           mysqli_stmt_bind_param($stmt, 's', $name);
           $stmt->execute();
           $stmt->bind_result($numar);
           while ($stmt->fetch()) {
            /*printf ("%d \n", $numar);*/
        }

        if($numar==1){
            echo 'Sorry for that! The username is already taken. Please login with your account password. Your username is '.$name;
        }
        else {

            mysqli_stmt_free_result($stmt);
            $stmt = mysqli_prepare($conn, "INSERT INTO UTILIZATORI VALUES (null,null,null,?,?,?,null)");
            mysqli_stmt_bind_param($stmt, 'sss', $name,$pass,$email);

            if(mysqli_stmt_execute($stmt)){



        mysqli_stmt_free_result($stmt);

$stmt =  mysqli_prepare($conn, "INSERT INTO CLASAMENT VALUES (?,0,'beginner') ");
     
     mysqli_stmt_bind_param($stmt,'s',$_POST['name']);
     $stmt->execute();
            }
            else{
                echo 'Oups! Something unexpected happened.';
            }
}

mysqli_close($conn);
}

}


?>