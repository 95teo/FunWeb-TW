<?php
function connect() {
    //datele pt conectare
    $servername = "mysql.unlimitedfunweb.tk";
    $username = "gfkiller407";
    $password = "Informatica1";
    $dbname = "unlimitedfun_fun";
    // creaza conexiune
    $conn = new mysqli($servername, $username, $password, $dbname);
    //verifica conexiune
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
        //return -1;
    }
    return $conn;
}

function getInfoUsers(){
    //creaza conexiune la baza de date
  $conn=connect();
    //preluam username jucator din sesiune
  $jucatorCurent=$_SESSION["my_user"];

  $stmt =  mysqli_prepare($conn, "SELECT NUME,PRENUME,USERNAME,DATA_NASTERE,EMAIL from UTILIZATORI WHERE USERNAME=?");
  mysqli_stmt_bind_param($stmt,'s',$jucatorCurent);
  $stmt->execute();
  $stmt->bind_result($nume,$prenume,$username,$data_nastere,$email);
  $stmt->fetch();
  mysqli_stmt_free_result($stmt);
  mysqli_close($conn);
  print '<script>
  $(function(){
    $("#nume").val("'.$nume.'");
  });
</script>'; 
print '<script>
$(function(){
  $("#prenume").val("'.$prenume.'");
});
</script>';
print '<script>
$(function(){
  $("#user").val("'.$username.'");
});
</script>';
print '<script>
$(function(){
  $("#data_nastere").val("'.$data_nastere.'");
});
</script>';

print '<script>
$(function(){
  $("#email").val("'.$email.'");
});
</script>';

}

function modifica(){
    //daca s-a apasat butonul pt salvare modificari
  if(isset($_POST['aplica_modificari'])){
    //creaza conexiune la baza de date
    $conn=connect();
    //preia username-ul jucatorului curent
    $jucatorCurent=$_SESSION["my_user"];
    //preluam datele din campuri
    $nume=$_POST['nume'];
    $prenume=$_POST['prenume'];
    $data_nastere=$_POST['data_nastere'];
    $email=$_POST['email'];
    //salveaza modiifcarile in baza de date
    $stmt =  mysqli_prepare($conn, "UPDATE UTILIZATORI SET NUME=?, PRENUME=?, DATA_NASTERE=?, EMAIL=? WHERE USERNAME=?");
    //BIND parametri din operatia catre baza de date
    mysqli_stmt_bind_param($stmt,'sssss',$nume,$prenume,$data_nastere,$email,$jucatorCurent);
    $stmt->execute();
    mysqli_stmt_free_result($stmt);
    mysqli_close($conn);
    print '<script>$(function() {
      $("#succes_info").show();
    });</script>';


  }

}

function modificaParola(){
    //verifica daca a fos apasat butonul
  if(isset($_POST['change_pass'])){
        //preia datele din campuri
   $old_pass=$_POST['old_pass'];
   $new_pass=$_POST['new_pass'];
   $new_pass_confirm= $_POST['new_pass_confirm'];
       //realizeaza conexiunea la baza de date
   $conn= connect();
       //PREIA username-ul utilizatorului curent din sesiune
   $jucatorCurent= $_SESSION['my_user'];

       //stabilim operatia catre bd
   $selectParola = "SELECT PAROLA FROM UTILIZATORI WHERE USERNAME =?";
   $stmt=mysqli_prepare($conn, $selectParola);
       //bind parametri select
   mysqli_stmt_bind_param($stmt,'s',$jucatorCurent);
       //executam operatia
   $stmt->execute();
       //extragem rezultatele
   $stmt->bind_result($parola);
   $stmt->fetch();
       //eliberam statementul
   mysqli_stmt_free_result($stmt);
       //verifcam daca a introdus corect parola curenta
   if($old_pass==$parola){
        //verificam daca noua parola coincide in ambele campuri

     if(($new_pass==$new_pass_confirm)  && strlen($new_pass)>4){
       $stmt=mysqli_prepare($conn,"UPDATE UTILIZATORI SET PAROLA= ? WHERE USERNAME = ?");
                //bind parametri select
       mysqli_stmt_bind_param($stmt,'ss',$new_pass,$jucatorCurent);
                //executam operatia
       $stmt->execute();
                //eliberam statement
       mysqli_stmt_free_result($stmt);
                //inchidem conexiunea
       mysqli_close($conn);
                //afisam un mesaj de succes
       print '<script>$(function() {
        $("#succes_pass").show();
      });</script>';
    }
    else{
            //evidentiem cele doua campuri deoarece parola nu a fost confirmata corespunzator
      print "<script>
      $('#parola,#rescrie_parola').css('background-color', '#FFB6C1');
    </script>";
  }
}
       //indicam faptul ca userul si-a gresit parola
else print "<script>
 $(document).ready(function(){
  $('[data-toggle=\"popover\"]').popover(\"show\");   
});
</script>";
}
}

function clasament(){
        //creem o conexiune
  $conn=connect();
        //PREIA username-ul utilizatorului curent din sesiune
  $jucatorCurent= $_SESSION['my_user'];
        //pregatim soperatia de select
  $stmt=mysqli_prepare($conn, "SELECT * FROM CLASAMENT ORDER BY PUNCTAJ DESC");

        //executam operatia
  $stmt->execute();
        //extragem rezultatele
  $stmt->bind_result($user,$punctaj,$nivel);
  $loc=1;
  while($stmt->fetch()){
            //evidentiem utilizatorul curent
    if($user==$jucatorCurent){
      print '<tr class="success">
      <td><b>'.$user.'</b></td>
      <td><b>'.$punctaj.'</b></td>
      <td><b>'.$nivel.'</b></td>    
    </tr>';
  }else{
            //completam tabelul cu ceilalti utilizatori
  print '<tr>
  <td>'.$user.'</td>
  <td>'.$punctaj.'</td>
  <td>'.$nivel.'</td>    
</tr>';
  }
}
        //eliberam conexiunea
mysqli_stmt_free_result($stmt);
mysqli_close($conn);
}

function getNrSingle(){
  //creem o conexiune
  $conn=connect();
        //PREIA username-ul utilizatorului curent din sesiune
  $jucatorCurent=$_SESSION["my_user"];
        //pregatim soperatia de select  
  $stmt=mysqli_prepare($conn, "SELECT COUNT(*) FROM JOC_SINGLE WHERE USER = ?");
  mysqli_stmt_bind_param($stmt,'s',$jucatorCurent);
        //executam operatia
  $stmt->execute();
        //extragem rezultatele
  $stmt->bind_result($nr_single);
  $stmt->fetch();
        //eliberam conexiunea
  mysqli_stmt_free_result($stmt);
  mysqli_close($conn);
  return $nr_single;
}

function getNrMulti(){
        //creem o conexiune
  $conn=connect();
        //PREIA username-ul utilizatorului curent din sesiune
  $jucatorCurent=$_SESSION["my_user"];
        //pregatim soperatia de select
        //Partide_de_joc joc_single

  $stmt=mysqli_prepare($conn, "SELECT COUNT(*) FROM PARTIDE_DE_JOC WHERE USER1 = ? OR USER2 = ? OR USER3 = ?");
  mysqli_stmt_bind_param($stmt,'sss',$jucatorCurent,$jucatorCurent,$jucatorCurent);
        //executam operatia
  $stmt->execute();
        //extragem rezultatele
  $stmt->bind_result($nr_multi);
  $stmt->fetch();
        //eliberam conexiunea
  mysqli_stmt_free_result($stmt);
  mysqli_close($conn);
  return $nr_multi;
}

function getLastGameDateSingle(){
      //creem o conexiune
  $conn=connect();
        //PREIA username-ul utilizatorului curent din sesiune
  $jucatorCurent=$_SESSION["my_user"];
        //pregatim soperatia de select

  $stmt=mysqli_prepare($conn, "SELECT MAX( DATA_JOC ) FROM JOC_SINGLE WHERE USER = ?");
  mysqli_stmt_bind_param($stmt,'s',$jucatorCurent);
        //executam operatia
  $stmt->execute();
        //extragem rezultatele
  $stmt->bind_result($lastGame);
  $stmt->fetch();
        //eliberam conexiunea
  mysqli_stmt_free_result($stmt);
  mysqli_close($conn);
  return $lastGame;
}

function getLastGameDateMulti(){
      //creem o conexiune
  $conn=connect();
        //PREIA username-ul utilizatorului curent din sesiune
  $jucatorCurent=$_SESSION["my_user"];
        //pregatim soperatia de select

  $stmt=mysqli_prepare($conn, "SELECT MAX( DATA_JOC ) FROM PARTIDE_DE_JOC WHERE USER1 = ? OR USER2 = ? OR USER3 = ?");
  mysqli_stmt_bind_param($stmt,'sss',$jucatorCurent,$jucatorCurent,$jucatorCurent);
        //executam operatia
  $stmt->execute();
        //extragem rezultatele
  $stmt->bind_result($lastGame);
  $stmt->fetch();
        //eliberam conexiunea
  mysqli_stmt_free_result($stmt);
  mysqli_close($conn);
  return $lastGame;
}

function getFromClasamet(){//COMPLETEAZA PAGINA DE CLASAMENT
      //creem o conexiune
  $conn=connect();
        //PREIA username-ul utilizatorului curent din sesiune
  $jucatorCurent=$_SESSION["my_user"];
        //pregatim soperatia de select
  $stmt=mysqli_prepare($conn, "SELECT NIVEL,PUNCTAJ FROM CLASAMENT WHERE USERNAME = ?");
  mysqli_stmt_bind_param($stmt,'s',$jucatorCurent);
        //executam operatia
  $stmt->execute();
        //extragem rezultatele
  $stmt->bind_result($nivel,$punctaj);
  $stmt->fetch();
        //eliberam conexiunea
  mysqli_stmt_free_result($stmt);
  mysqli_close($conn);

  print "<tr>
  <td>Level</td>
  <td>".$nivel."</td>
</tr>
<tr>
  <td>Score</td>
  <td>".$punctaj."</td>
</tr>";
}

function fb(){
     
    if($_SESSION['fb'] == 1){
     print '   <!-- Modal -->
<div id="modal">
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Warning!</h4>
        </div>
        <div class="modal-body">
          <p><b>Atentiune!Atentiune! <b></p>
       
          <button type="button" class="btn btn-default" data-dismiss="modal" style="float:right;">OK</button><br><br>
        </div> 
      </div>
      
    </div>
  </div>
</div>
 <script> $("#myModal").modal("show"); </script>';
}

    }
?>