<?php

function getQuestion($nr_intrebari) {

    $conn = connect();
    $id_joc = $_SESSION['id_joc'];

    $stmt = mysqli_prepare($conn, "SELECT DOMENII_ALESE FROM PARTIDE_DE_JOC WHERE ID_JOC=?");
    mysqli_stmt_bind_param($stmt, 'd', $id_joc);
    $stmt->execute();
    $stmt->bind_result($domenii_alese);
    $stmt->fetch();


    $domenii_alese_array = array();
    $domenii_alese_array = explode(",", $domenii_alese);
    $multime_domenii = "";


    if (sizeof($domenii_alese_array) == 1) {
        $multime_domenii = $domenii_alese_array[0];
    } else {
        if (sizeof($domenii_alese_array) == 2) {
            $multime_domenii = $domenii_alese_array[0] . "','" . $domenii_alese_array[1];
        } else {
            $multime_domenii = $domenii_alese_array[0] . "',";
            for ($i = 1; $i < sizeof($domenii_alese_array) - 1; $i++) {
                $multime_domenii = $multime_domenii . "'" . $domenii_alese_array[$i] . "',";
            }
            $multime_domenii = $multime_domenii . "'" . $domenii_alese_array[$i];
        }
    }


    mysqli_stmt_free_result($stmt);
    $interogare = "SELECT ID_INTREBARE FROM INTREBARI WHERE DOMENIU IN ( '" . $multime_domenii . "' ) ORDER BY RAND() LIMIT " . $nr_intrebari;

    $stmt = mysqli_prepare($conn, $interogare);
    //mysqli_stmt_bind_param($stmt,'s',$multime_domenii);
    $stmt->execute();
    $stmt->bind_result($id_intrebare);
    //punem intrebarile selectate intr-un array
    $id_intrebari = array();
    while ($stmt->fetch()) {

        array_push($id_intrebari, $id_intrebare);
    }

    $id_intrebari_string = "";

    if (sizeof($id_intrebari) == 1) {
        $id_intrebari_string = $id_intrebari[0];
    } else {
        if (sizeof($id_intrebari) == 2) {
            $id_intrebari_string = $id_intrebari[0] . "," . $id_intrebari[1];
        } else {

            $id_intrebari_string = $id_intrebari[0] . ",";

            for ($i = 1; $i < sizeof($id_intrebari) - 1; $i++) {
                $id_intrebari_string = $id_intrebari_string . $id_intrebari[$i] . ",";
            }

            $id_intrebari_string = $id_intrebari_string . $id_intrebari[$i];
        }
    }

    return $id_intrebari_string;
}

function createGame() {

    if (isset($_POST['Create'])) {
// Create connection
        $ok = 0;
        $domenii = array();
        if (!empty($_POST['chk1'])) {
            array_push($domenii, "html");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }
        if (!empty($_POST['chk2'])) {
            array_push($domenii, "angular");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }
        if (!empty($_POST['chk3'])) {
            array_push($domenii, "php");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }
        if (!empty($_POST['chk4'])) {
            array_push($domenii, "css");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }
        if (!empty($_POST['chk5'])) {
            array_push($domenii, "ajax");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }
        if (!empty($_POST['chk6'])) {
            array_push($domenii, "js");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }
        if (!empty($_POST['chk7'])) {
            array_push($domenii, "http");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }
        if (!empty($_POST['chk8'])) {
            array_push($domenii, "xml");
            $ok = 1;
        } else {
            array_push($domenii, "");
        }


        if ($ok == 0) {
            $domenii = array();
            array_push($domenii, "html");
            array_push($domenii, "angular");

            array_push($domenii, "php");
            array_push($domenii, "css");
            array_push($domenii, "js");
            array_push($domenii, "http");
            array_push($domenii, "ajax");
            array_push($domenii, "xml");
        }

        $conn = connect();

        $all_dom = "";
        $prim = 0;
        for ($i = 0; $i < sizeof($domenii); $i++) {
            if ($domenii[$i] != "") {
                if ($prim == 0) {
                    $all_dom = $all_dom . $domenii[$i];
                    $prim = 1;
                } else
                    $all_dom = $all_dom . "," . $domenii[$i];
            }
        }



        $ok = 1;
        $user2 = $_POST['user1'];
        $user3 = $_POST['user2'];
        $question_number = $_POST['questions'];
        $autor = $_SESSION["my_user"];
        $stmt = mysqli_prepare($conn, "SELECT COUNT(*) FROM PARTIDE_DE_JOC WHERE STATUS_JOC=\"WAITING\" AND USER1=?");
        mysqli_stmt_bind_param($stmt, 's', $autor);
        mysqli_stmt_execute($stmt);
        $stmt->bind_result($areJoc);
        $stmt->fetch();
        if ($areJoc != 0) {
            print '   <!-- Modal -->
<div id="modal">
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Warning!</h4>
        </div>
        <div class="modal-body">
          <p><b>You already have a game in the waiting list! Please have patience!<b></p>
       
          <button type="button" class="btn btn-default" data-dismiss="modal" style="float:right;">OK</button><br><br>
        </div> 
      </div>
      
    </div>
  </div>
</div>
 <script> $("#myModal").modal("show"); </script>';
        } else {

            mysqli_stmt_free_result($stmt);
            if ($user2 == "") {
                $user2 = "?";
            }
            if ($user3 == "") {
                $user3 = "?";
            }
            if (($user2 != $user3) || ($user2 == "?" && $user3 == "?")) {

                $stmt = mysqli_prepare($conn, "INSERT INTO PARTIDE_DE_JOC 
        (USER1,USER2,USER3,CASTIGATORI,DOMENII_ALESE,NR_INTREBARI,PUNCTAJ_USER1,PUNCTAJ_USER2,PUNCTAJ_USER3,DATA_JOC,DURATA,STATUS_JOC,CORECTE_1,CORECTE_2,CORECTE_3)
        VALUES (?,?,?,null,?,?,0,0,0,null,null,\"WAITING\",0,0,0)");
                mysqli_stmt_bind_param($stmt, 'ssssd', $autor, $user2, $user3, $all_dom, $question_number);
                mysqli_stmt_execute($stmt);

                //sa punem id-ul jocului in sesiune
                mysqli_stmt_free_result($stmt);

                //jucatorul curent este jucator_1 din tabel [autorul]
                $_SESSION['nr_jucator'] = 1;
                //preluam username jucatorului curent, cel care a reat jocul
                $jucatorCreator = $_SESSION["my_user"];
                //aflam id-ul jocului proaspat creat
                $stmt = mysqli_prepare($conn, "SELECT ID_JOC FROM PARTIDE_DE_JOC WHERE USER1=? AND STATUS_JOC=\"WAITING\"");
                mysqli_stmt_bind_param($stmt, 's', $jucatorCreator);
                $stmt->execute();
                $stmt->bind_result($id_joc);
                $stmt->fetch();
                //si-l pastram in sesiune
                $_SESSION['id_joc'] = $id_joc;
                //initializam un vector care v-a memora raspunsurile date pt raport !!!!!!!!!!!!!!!!
               
                $raport_raspunsuri = array();
                $raspunsuri_date = array();
               // $raspunsuri_corecte = 
                $enunturi = array();
                
                $_SESSION['raspunsuri_date']=$raspunsuri_date;
                $_SESSION['raport_raspunsuri'] = $raport_raspunsuri;
                $_SESSION['raspunsuri_corecte']=array();;
                $_SESSION['enunturi'] = $enunturi;
///////////////////////////!!!!!!!!!!!!!!!!!!!!!!!!!!!
                mysqli_stmt_free_result($stmt);

                $intrebarile_jocului = getQuestion($question_number);

                mysqli_stmt_free_result($stmt);

                $updateLaIntrebari = "UPDATE PARTIDE_DE_JOC SET INTREBARI = '" . $intrebarile_jocului . "' WHERE ID_JOC= " . $id_joc;

                $stmt = mysqli_prepare($conn, $updateLaIntrebari);
                mysqli_stmt_execute($stmt);

                //sa punem id-ul jocului in sesiune
                mysqli_stmt_free_result($stmt);
                mysqli_close($conn);

                $_SESSION['index_intrebare'] = $question_number;
                // startGame();
            } else {
                print '   <!-- Modal -->
<div id="modal">
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Warning!</h4>
        </div>
        <div class="modal-body">
          <p><b>Please choose different oponents!<b></p>
          <button type="button" class="btn btn-default" data-dismiss="modal" style="float:right;">OK</button><br><br>
        </div> 
      </div>
      
    </div>
  </div>
</div>
 <script> $("#myModal").modal("show"); </script>';
            }
        }
    }
}

/////////////////////////////
function verifyAnswer_single() {
    $servername = "mysql.unlimitedfunweb.tk";
    $username = "gfkiller407";
    $password = "Informatica1";
    $dbname = "unlimitedfun_fun";
// Create connection
    $raspuns_dat = '';
    if (isset($_POST['A'])) {
        $raspuns_dat = 'A';
    }
    if (isset($_POST['B'])) {
        $raspuns_dat = 'B';
    }
    if (isset($_POST['C'])) {
        $raspuns_dat = 'C';
    }
    if (isset($_POST['D'])) {
        $raspuns_dat = 'D';
    }
    $punctaj = $_SESSION['scor'];
   
    if ($raspuns_dat != '') {
        $raspuns_corect = $_SESSION['raspuns_corect'];
        //echo "corect: ".$raspuns_corect." ";
        //echo "rasp dat : ".$raspuns_dat." ";
        if ($raspuns_dat == $raspuns_corect) {
            $punctaj = $punctaj + 10;
            $_SESSION['nr_corecte'] = $_SESSION['nr_corecte'] + 1;
        } else
            $_SESSION['nr_gresite'] = $_SESSION['nr_gresite'] + 1;
        $_SESSION['scor'] = $punctaj;
        $_SESSION['intrebari_ramase'] = $_SESSION['intrebari_ramase'] - 1;




        if ($_SESSION['intrebari_ramase'] == 0) {
            $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }

            $stmt = mysqli_prepare($conn, "UPDATE JOC_SINGLE SET PUNCTAJ=? WHERE ID_JOC=? ");

            mysqli_stmt_bind_param($stmt, 'dd', $_SESSION['scor'], $_SESSION['id_joc']);
            $stmt->execute();

            mysqli_stmt_free_result($stmt);

            $stmt = mysqli_prepare($conn, "UPDATE CLASAMENT SET PUNCTAJ=PUNCTAJ+? WHERE USERNAME=? ");

            mysqli_stmt_bind_param($stmt, 'ds', $_SESSION['scor'], $_SESSION['my_user']);
            $stmt->execute();
            mysqli_close($conn);

            print "<script>";
            print "top.window.location = 'final_single.php';";
            print "</script>";
        }
    }
}

function joinGame() {

    if (isset($_POST['joinGame'])) {

        $conn = connect();

        $autor = $_POST['autor_joc'];

        $stmt = mysqli_prepare($conn, "SELECT ID_JOC,USER2,USER3,JOIN_USER2,JOIN_USER3,NR_INTREBARI FROM PARTIDE_DE_JOC WHERE USER1=? AND STATUS_JOC=\"WAITING\"");
        mysqli_stmt_bind_param($stmt, 's', $autor);
        $stmt->execute();

        $stmt->bind_result($id_joc, $user2, $user3, $join_user2, $join_user3, $nr_intrebari);
        $stmt->fetch();

        $jucatorCurent = $_SESSION["my_user"];

        //pastram nr de intrebari ale jocului in sesiune
        $_SESSION['index_intrebare'] = $nr_intrebari;
        //pastram idul jocului in sesiune
        $_SESSION['id_joc'] = $id_joc;
        //pastram punctajul jucatorului curent in sesiune

        if ($autor != $jucatorCurent) {
            if (($user2 == "?" || $user2 == $jucatorCurent) && $join_user2 == 0) {
                $user2 = $jucatorCurent;
                $join_user2 = 1;
                $_SESSION['nr_jucator'] = 2;
            } else {
                if (($user3 == "?" || $user3 == $jucatorCurent) && ($user2 != $jucatorCurent) && $join_user3 == 0) {
                    $user3 = $jucatorCurent;
                    $join_user3 = 1;
                    $_SESSION['nr_jucator'] = 3;
                    //lansam jocul
                }
            }

            mysqli_stmt_free_result($stmt);
            $stmt = mysqli_prepare($conn, "UPDATE PARTIDE_DE_JOC SET USER2=?, USER3=?, JOIN_USER2=?,JOIN_USER3=? WHERE USER1=? AND STATUS_JOC=\"WAITING\" ");

            mysqli_stmt_bind_param($stmt, 'ssdds', $user2, $user3, $join_user2, $join_user3, $autor);
            $stmt->execute();

            mysqli_stmt_free_result($stmt);
            ///User-ul devine indisponibil
            mysqli_stmt_free_result($stmt);
            $stmt = mysqli_prepare($conn, "UPDATE UTILIZATORI SET STATUS = 'INDISPONIBIL' WHERE USERNAME=?");


            mysqli_stmt_bind_param($stmt, 's', $jucatorCurent);
            $stmt->execute();

            mysqli_stmt_free_result($stmt);
            //
            mysqli_close($conn);

            //startGame();
        } else {
            print '   <!-- Modal -->
<div id="modal">
  <div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog">
      
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Warning!</h4>
        </div>
        <div class="modal-body">
          <p><b>You are trying to join your own game! LoL ..<b></p>
       
          <button type="button" class="btn btn-default" data-dismiss="modal" style="float:right;">OK</button><br><br>
        </div> 
      </div>
      
    </div>
  </div>
</div>
 <script> $("#myModal2").modal("show"); </script>';
        }
    }
}

?>
