<!DOCTYPE HTML> 
<html lang="en"> 
<HEAD> 
    <TITLE> 
    </TITLE> 
    <meta charset="utf-8"> 
    <link rel="stylesheet" href="bootstrap-3.3.6\dist\css\bootstrap.min.css"> 
    <link href="css/Butoane_domenii.css" rel="stylesheet"> 
    <link rel="stylesheet" href="css\config.css"> 
    <script src="bootstrap-3.3.6\js\tests\vendor\jquery.min.js"></script> 
    <script src="bootstrap-3.3.6\dist\js\bootstrap.min.js"></script> 
    <script src="js/jQuery/jquery-1.12.3.min.js"></script> 
    <script type="text/javascript" src="js/butoane_domenii.js"></script> 
    <script src="js/jQuery/jquery-1.11.3.min.js"></script>
    <script src="js/bootstrap-suggest.js"></script>
    <script src="js/configurare.js"></script>
    <?php include'Model\connection.php';?> 
</HEAD> 
<BODY> 
    <div class="panel" id="panel"> 
        <div class="left-panel">
            <div class="container">
              <div class="panel panel-default">
                <div class="panel-body" >
                    <div class="panel panel-primary">
                      <div class="panel-heading">Panel with panel-primary class</div>
                      <div class="panel-body">Panel Content</div>
                  </div>

              </div>
              <div class="panel-body">
                    <div class="panel panel-primary">
                      <div class="panel-heading">Panel with panel-primary class</div>
                      <div class="panel-body">Panel Content</div>
                  </div>

              </div>
              <div class="panel-body">
                    <div class="panel panel-primary">
                      <div class="panel-heading">Panel with panel-primary class</div>
                      <div class="panel-body">Panel Content</div>
                  </div>

              </div>
              <div class="panel-body">
                    <div class="panel panel-primary">
                      <div class="panel-heading">Panel with panel-primary class</div>
                      <div class="panel-body">Panel Content</div>
                  </div>

              </div>
              <div class="panel-body">
                    <div class="panel panel-primary">
                      <div class="panel-heading">Panel with panel-primary class</div>
                      <div class="panel-body">Panel Content</div>
                  </div>

              </div>
              <div class="panel-body">
                    <div class="panel panel-primary">
                      <div class="panel-heading">Panel with panel-primary class</div>
                      <div class="panel-body">Panel Content</div>
                  </div>

              </div>
              <div class="panel-body">
                    <div class="panel panel-primary">
                      <div class="panel-heading">Panel with panel-primary class</div>
                      <div class="panel-body">Panel Content</div>
                  </div>

              </div>
          </div>
      </div> 
  </div> 
  <div class="right-panel"> 
    <form id="productForm" method="post" class="form-horizontal" action="multi_joc.php"> 
        <div class="container" > 

            <div class="row">
                <label class="col-xs-3 control-label">Jucător1</label>
                <div class="col-lg-6">
                    <div class="input-group">
                        <input type="text" class="form-control" id="player1">

                        <div class="input-group-btn">
                            <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                                <span class="caret"></span>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-right" role="menu">
                            </ul>
                        </div>
                        <!-- /btn-group -->
                    </div>
                </div>
            </div> 
            <br>
            <div class="row">
                <label class="col-xs-3 control-label">Jucător2</label>
                <div class="col-lg-6">
                    <div class="input-group">
                        <input type="text" class="form-control" id="player2">

                        <div class="input-group-btn">
                            <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                                <span class="caret"></span>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-right" role="menu">
                            </ul>
                        </div>
                        <!-- /btn-group -->
                    </div>
                </div>
            </div> 
            <br> 
            <div class="form-group"> 
                <label class="col-xs-3 control-label">Număr întrebări</label> 
                <div class="col-xs-6 selectContainer"> 
                    <select class="form-control" name="color"> 
                        <option value=10>10</option> 
                        <option value=15>15</option> 
                        <option value=20>20</option> 
                        <option value=25>25</option> 
                        <option value=30>30</option> 
                    </select> 
                </div> 
            </div> 
        </div> 
        <div class="container"> 
            <div class="form-group"> 
                <div class="row"> 
                    <div class="col-md-3">
                        <label class="btn btn-primary"><img src="multimedia\SVG\html.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk1" id="item4" value="val1" class="hidden" autocomplete="off"></label> 
                    </div> 
                    <div class="col-md-3">
                        <label class="btn btn-primary"><img src="multimedia\SVG\angular.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk2" id="item4" value="val2" class="hidden" autocomplete="off"></label> 
                    </div> 
                    <div class="col-md-3">
                        <label class="btn btn-primary"><img src="multimedia\SVG\php.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk1" id="item4" value="val1" class="hidden" autocomplete="off"></label> 
                    </div> 
                    <div class="col-md-3">
                        <label class="btn btn-primary"><img src="multimedia\SVG\css.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk1" id="item4" value="val1" class="hidden" autocomplete="off"></label> 
                    </div> 
                </div> 
                <div class="row"> 
                    <div class="col-md-3">
                        <label class="btn btn-primary"><img src="multimedia\SVG\ajax.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk1" id="item4" value="val1" class="hidden" autocomplete="off"></label> 
                    </div> 
                    <div class="col-md-3">
                        <label class="btn btn-primary"><img src="multimedia\SVG\js.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk1" id="item4" value="val1" class="hidden" autocomplete="off"></label> 
                    </div> 
                    <div class="col-md-3">
                        <label class="btn btn-primary"><img src="multimedia\SVG\http.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk1" id="item4" value="val1" class="hidden" autocomplete="off"></label> 
                    </div> 
                    <div class="col-md-3">
                        <label class="btn btn-primary"><img src="multimedia\SVG\xml.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk1" id="item4" value="val1" class="hidden" autocomplete="off"></label> 
                    </div> 
                </div> 
            </div> 
            <div class="form-group"> 
                <div class="col-xs-5 col-xs-offset-3"> 
                    <button type="submit" class="btn btn-default" name="creeaza">Creează jocul</button> 
                </div> 
            </div> 
        </div>
    </form> 

</div>
</div> 
<script type="text/javascript">
var testdataBsSuggest = $("#player1,#player2").bsSuggest({
        indexId: 2,  
        indexKey: 1, 
        data: {
            'value':[
            <?php getOnlineUsers(); ?>
            ],
            'defaults':'http://www.1.com'
        }
    }).on('onDataRequestSuccess', function (e, result) {
        console.log('onDataRequestSuccess: ', result);
    }).on('onSetSelectValue', function (e, keyword, data) {
        console.log('onSetSelectValue: ', keyword, data);
    }).on('onUnsetSelectValue', function (e) {
        console.log("onUnsetSelectValue");
    });
    </script>
</BODY> 
</HTML>