<?php
function login(){
$servername = "fenrir.info.uaic.ro";
$username = "teo95ursan";
$password = "aC7tAu6EWi";
$dbname = "teo95ursan";
if(isset($_POST['Login'])){
// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$user=$_POST['user'];
$pass=$_POST['pwd'];
 $stmt =  mysqli_prepare($conn, "SELECT COUNT(*) from UTILIZATORI WHERE USERNAME=? and PAROLA=?");
mysqli_stmt_bind_param($stmt, 'ss', $user,$pass);
$stmt->execute();
$stmt->bind_result($numar);
      while ($stmt->fetch()) {
        /*printf ("%d \n", $numar);*/
    }
    if($numar==0){
        echo 'Combinaţie user/parolă eronată! Reîncercaţi. ';
    }
    else {
        echo "<script>";
echo "top.window.location = 'menu.php';";
echo "</script>";
/*$url='menu.php';
   ob_start();
    header('Location: '.$url);
    ob_end_flush();
    die();*/
}
}
}

function register(){
$servername = "fenrir.info.uaic.ro";
$username = "teo95ursan";
$password = "aC7tAu6EWi";
$dbname = "teo95ursan";
if(isset($_POST['Register'])){
// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$ok=1;
$user=$_POST['user'];
$pass=$_POST['parola'];
$mail=$_POST['email'];
$pass_confirm=$_POST['rescrie_parola'];

if($user<4)$ok=0;
if($pass<4)$ok=0;
if($pass_confirm<4)$ok=0;
if($pass==$pass_confirm)$ok=1; else $ok=0;
if($ok==1){
 $stmt =  mysqli_prepare($conn, "SELECT COUNT(*) from UTILIZATORI WHERE USERNAME=?");
mysqli_stmt_bind_param($stmt, 's', $user);
$stmt->execute();
$stmt->bind_result($numar);
      while ($stmt->fetch()) {
        /*printf ("%d \n", $numar);*/
    }
    if($numar==1){
        echo 'Sorry for that! The username is already taken. Please choose another one. ';
    }
    else {
mysqli_stmt_free_result($stmt);
$stmt = mysqli_prepare($conn, "INSERT INTO UTILIZATORI VALUES (null,null,null,?,?,?,null)");
mysqli_stmt_bind_param($stmt, 'sss', $user,$pass,$mail);
if(mysqli_stmt_execute($stmt)){
echo "<script>";
echo "top.window.location = 'menu.php';";
echo "</script>";
}
else{
    echo 'Oups! Something unexpected happened.';
}
/*
$url='menu.php';
   ob_start();
    header('Location: '.$url);
    ob_end_flush();
    die();*/
}
}
else { echo "You haven't completed all the fields for register.";}

}}

function getOnlineUsers(){
$servername = "fenrir.info.uaic.ro";
$username = "teo95ursan";
$password = "aC7tAu6EWi";
$dbname = "teo95ursan";
// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
 $stmt =  mysqli_prepare($conn, "SELECT USERNAME from UTILIZATORI");
$stmt->execute();
$stmt->bind_result($nume);
$stmt->fetch();
printf ("{'word':'%s'}", $nume);
      while ($stmt->fetch()) {
        printf (",\n");
        printf ("{'word':'%s'}", $nume);
    }
    
}
?>

