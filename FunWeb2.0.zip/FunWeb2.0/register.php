<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
     <link href="bootstrap-3.3.6\dist\css\bootstrap.min.css" rel="stylesheet">
    <link href="bootstrap-3.3.6\dist\css\bootstrap.css" rel="stylesheet">
	<link href="css\register.css" rel="stylesheet">
    <?php include'Model\connection.php';?>
      <script type="text/javascript" src="js\register.js"></script> 
      <link href="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-2.2.3.js">    
</head>
<body>
<div id="Titlu_inregistrare"> Începe să înveți! </div>
<hr>
<!--<form id = "Login_formular" >
Username:<input type='text' name='user' placeholder="Type your username here..." /><br>
Password :<input type='password' name='password' placeholder="Type your password here..."/><br>
<input type='submit' class="btn btn-default"  value='Login aplication' name='Submit'/>
 </form>-->
<form id = "Inregistrare_formular" class="form-horizontal" role="form" method="POST">
    <div class="form-group">
      <div class="col-sm-10">
        <fieldset>
      <label class="control-label col-sm-2" for="user"> Utilizator: </label>
      
        
        <input type="text" class="form-control" name='user' id="user" placeholder="Nume de utilizator" onkeyup="checkUsernameForLength(this);" />
      <span class="hint">Usernames must be a least 4 characters in length.</span>
      
      </fieldset>
      </div>
    </div>
    
    <div class="form-group">
      <div class="col-sm-10">
      <fieldset>
      <label class="control-label col-sm-2" for="email"> Email: </label>
      
        <input type="email" class="form-control" name='email' id="email" placeholder="Email" onkeyup="checkEmail(this);" />
        <span class="hint">You can enter your real address without worry - we don't spam!</span>
      </fieldset>
      </div>
    </div>
    

    <div class="form-group">
      <div class="col-sm-10"> 
      <fieldset>
      <label class="control-label col-sm-2" for="parola"> Parola: </label>
               
        <input type="password" name="parola" class="form-control" id="parola" placeholder="Parola" onkeyup="checkPassword(this);" />
        <span class="hint">The password can be any combination of characters, and must be at least 4 characters in length.  8 characters recommended!</span>
      </fieldset>
      </div>
    </div>
    
      <div class="form-group">
        <div class="col-sm-10">
          <fieldset>
      <label class="control-label col-sm-2" for="rescrie_parola"> Confirmă Parola: </label>
                
        <input type="password" class="form-control" name="rescrie_parola" id="rescrie_parola" placeholder="Confirmă Parola" onkeyup="checkPass(); return false;"/>
          <span id='message' class='message'></span>
          </fieldset>
          
        </div>
      </div>
  

    
   
    <div id= "inregistrare" class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" id="inregistrare_buton" class="btn btn-default" name="Register"> Înregistrare </button>
      </div>
    </div>
  </form>
<?php
register();
?>
</body>
</html>
