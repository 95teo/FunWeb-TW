<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
     <link href="bootstrap-3.3.6\dist\css\bootstrap.min.css" rel="stylesheet">
    <link href="bootstrap-3.3.6\dist\css\bootstrap.css" rel="stylesheet">
	<link href="css\register.css" rel="stylesheet">
    <?php include'Model\connection.php';?>
</head>
<body>
<div id="Titlu_inregistrare"> Începe să înveți! </div>
<hr>
<!--<form id = "Login_formular" >
Username:<input type='text' name='user' placeholder="Type your username here..." /><br>
Password :<input type='password' name='password' placeholder="Type your password here..."/><br>
<input type='submit' class="btn btn-default"  value='Login aplication' name='Submit'/>
 </form>-->
<form id = "Inregistrare_formular" class="form-horizontal" role="form" target="_top" method="POST">
    <div class="form-group">
      <label class="control-label col-sm-2" for="nume"> Numele: </label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="nume" placeholder="Nume">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="prenume"> Prenumele: </label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="prenume" placeholder="Prenume">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="data_nastere"> Data Nastere: </label>
      <div class="col-sm-10">
        <input type="date" class="form-control" id="data_nastere" placeholder="Data nastere">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="telefon"> Telefon: </label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="telefon" placeholder="Telefon">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="user"> Utilizator: </label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="user" placeholder="Nume de utilizator">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="email"> Email: </label>
      <div class="col-sm-10">
        <input type="email" class="form-control" id="email" placeholder="Email">
      </div>
    </div>


    <div class="form-group">
      <label class="control-label col-sm-2" for="parola"> Parola: </label>
      <div class="col-sm-10">          
        <input type="password" class="form-control" id="parola" placeholder="Parola">
      </div>
    </div>
      <div class="form-group">
      <label class="control-label col-sm-2" for="rescrie_parola"> Confirmă Parola: </label>
      <div class="col-sm-10">          
        <input type="password" class="form-control" id="rescrie_parola" placeholder="Confirmă Parola">
      </div>
    </div>

    
   
    <div id= "inregistrare" class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" id="inregistrare_buton" class="btn btn-default" name="Register"> Înregistrare </button>
      </div>
    </div>
  </form>
<?php
register();
?>
</body>
</html>
