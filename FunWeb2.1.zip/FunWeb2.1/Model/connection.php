<?php
function login(){
    $servername = "fenrir.info.uaic.ro";
    $username = "teo95ursan";
    $password = "aC7tAu6EWi";
    $dbname = "teo95ursan";
    if(isset($_POST['Login'])){
// Create connection
        $conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        $user=$_POST['user'];
        $pass=$_POST['pwd'];
        $stmt =  mysqli_prepare($conn, "SELECT COUNT(*) from UTILIZATORI WHERE USERNAME=? and PAROLA=?");
        mysqli_stmt_bind_param($stmt, 'ss', $user,$pass);
        $stmt->execute();
        $stmt->bind_result($numar);
        while ($stmt->fetch()) {
            /*printf ("%d \n", $numar);*/
        }
        if($numar==0){
            echo 'Combinaţie user/parolă eronată! Reîncercaţi. ';
        }
        else {
            echo "<script>";
            echo "top.window.location = 'menu.php';";
            echo "</script>";
/*$url='menu.php';
   ob_start();
    header('Location: '.$url);
    ob_end_flush();
    die();*/
}
}
}

function register(){
    $servername = "fenrir.info.uaic.ro";
    $username = "teo95ursan";
    $password = "aC7tAu6EWi";
    $dbname = "teo95ursan";
    if(isset($_POST['Register'])){
// Create connection
        $conn = new mysqli($servername, $username, $password,$dbname);

// Check connection

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        $ok=1;
        $user=$_POST['user'];
        $pass=$_POST['parola'];
        $mail=$_POST['email'];
        $pass_confirm=$_POST['rescrie_parola'];

        if($user<4)$ok=0;
        if($pass<4)$ok=0;
        if($pass_confirm<4)$ok=0;
        if($pass==$pass_confirm)$ok=1; else $ok=0;
        if($ok==1){
           $stmt =  mysqli_prepare($conn, "SELECT COUNT(*) from UTILIZATORI WHERE USERNAME=?");
           mysqli_stmt_bind_param($stmt, 's', $user);
           $stmt->execute();
           $stmt->bind_result($numar);
           while ($stmt->fetch()) {
            /*printf ("%d \n", $numar);*/
        }
        if($numar==1){
            echo 'Sorry for that! The username is already taken. Please choose another one. ';
        }
        else {
            mysqli_stmt_free_result($stmt);
            $stmt = mysqli_prepare($conn, "INSERT INTO UTILIZATORI VALUES (null,null,null,?,?,?,null)");
            mysqli_stmt_bind_param($stmt, 'sss', $user,$pass,$mail);
            if(mysqli_stmt_execute($stmt)){
                echo "<script>";
                echo "top.window.location = 'menu.php';";
                echo "</script>";
            }
            else{
                echo 'Oups! Something unexpected happened.';
            }
/*
$url='menu.php';
   ob_start();
    header('Location: '.$url);
    ob_end_flush();
    die();*/
}
}
else { echo "You haven't completed all the fields for register.";}

}}

function getOnlineUsers(){
    $servername = "fenrir.info.uaic.ro";
    $username = "teo95ursan";
    $password = "aC7tAu6EWi";
    $dbname = "teo95ursan";
// Create connection
    $conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    $stmt =  mysqli_prepare($conn, "SELECT USERNAME from UTILIZATORI");
    $stmt->execute();
    $stmt->bind_result($nume);
    $stmt->fetch();
    printf ("{'word':'%s'}", $nume);
    while ($stmt->fetch()) {
        printf (",\n");
        printf ("{'word':'%s'}", $nume);
    }

}

function createGame(){
    $servername = "fenrir.info.uaic.ro";
    $username = "teo95ursan";
    $password = "aC7tAu6EWi";
    $dbname = "teo95ursan";
    if(isset($_POST['Create'])){
// Create connection
        $domenii=array();
        if(!empty($_POST['chk1'])){
            array_push($domenii, "html");
        }
        else{
            array_push($domenii, "");
        }
        if(!empty($_POST['chk2'])){
            array_push($domenii, "angular");
        }
        else{
            array_push($domenii, "");
        }
        if(!empty($_POST['chk3'])){
            array_push($domenii, "php");
        }
        else{
            array_push($domenii, "");
        }
        if(!empty($_POST['chk4'])){
            array_push($domenii, "css");
        }
        else{
            array_push($domenii, "");
        } 
        if(!empty($_POST['chk5'])){
            array_push($domenii, "ajax");
        }
        else{
            array_push($domenii, "");
        }
        if(!empty($_POST['chk6'])){
            array_push($domenii, "js");
        }
        else{
            array_push($domenii,"");
        }
        if(!empty($_POST['chk7'])){
            array_push($domenii, "http");
        }
        else{
            array_push($domenii, "");
        }
        if(!empty($_POST['chk8'])){
            array_push($domenii, "xml");
        }
        else{
            array_push($domenii, "");
        }
        $all_dom="";
        $prim=0;
        for ($i=0;$i<sizeof($domenii);$i++){
           if($domenii[$i]!=""){
               if($prim==0){$all_dom=$all_dom.$domenii[$i];$prim=1;}
               else
                   $all_dom=$all_dom.",".$domenii[$i];
           }  
       }  

       $conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
       if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    $ok=1;
    $user1=$_POST['user1'];
    $user2=$_POST['user2'];
    $question_number=$_POST['questions'];
    $stmt = mysqli_prepare($conn, "INSERT INTO PARTIDE_DE_JOC 
        (USER1,USER2,USER3,CASTIGATORI,DOMENII_ALESE,NR_INTREBARI,PUNCTAJ_USER1,PUNCTAJ_USER2,PUNCTAJ_USER3,DATA_JOC,DURATA,STATUS_JOC)
        VALUES (null,null,null,null,?,?,null,null,null,null,null,null)");
    mysqli_stmt_bind_param($stmt, 'sd', $all_dom,$question_number);
    mysqli_stmt_execute($stmt);
        
}
}
?>

