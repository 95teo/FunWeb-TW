<DOCTYPE HTML>
<HEAD>
<TITLE>
</TITLE>
<link rel="stylesheet" href="bootstrap-3.3.6\dist\css\bootstrap.min.css">
<script src="bootstrap-3.3.6\js\tests\vendor\jquery.min.js"></script>
  <script src="bootstrap-3.3.6\dist\js\bootstrap.min.js"></script>

</HEAD>
<BODY>
 <table class="table table-striped">
    <tbody>
      <tr>
        <td>Partide jucate</td>
        <td>10</td>
      </tr>
      <tr>
        <td>Rata castig</td>
        <td>50%</td>
      </tr>
      <tr>
        <td>Partide jucate singur</td>
        <td>2</td>
      </tr>
      <tr>
        <td>Partide jucate multiplayer</td>
        <td>8</td>
      </tr>
      <tr>
        <td>Ultima partida jucata</td>
        <td>TIMESTAMP</td>
      </tr>
      <tr>
        <td>Status</td>
        <td>incepator</td>
      </tr>
      <tr>
        <td>Puncte</td>
        <td>45</td>
      </tr>
    </tbody>
  </table>
</BODY>
</HTML>