  function autocomplete(){
    //Store the password field objects into variables ...
    var autofield1 = document.getElementById('player1');
    var autofield2 = document.getElementById('player2');
    //Store the Confimation Message Object ...
    //Set the colors we will be using ...
    var goodColor = "#66cc66";
    var badColor = "#ff6666";
    //Compare the values in the password field 
    //and the confirmation field
        //The passwords match. 
        //Set the color to the good color and inform
        //the user that they have entered the correct password
        autofield1.style.backgroundColor = goodColor; 
        autofield2.style.backgroundColor = goodColor;

}  
