<!DOCTYPE HTML> 
<html lang="en"> 
<HEAD> 
  <TITLE> 
  </TITLE> 
  <meta charset="utf-8"> 
  <link rel="stylesheet" href="bootstrap-3.3.6\dist\css\bootstrap.min.css"> 
  <link href="css/Butoane_domenii.css" rel="stylesheet"> 
  <link rel="stylesheet" href="css\start_single.css"> 
  <script src="bootstrap-3.3.6\js\tests\vendor\jquery.min.js"></script> 
  <script src="bootstrap-3.3.6\dist\js\bootstrap.min.js"></script> 
  <script src="js/jQuery/jquery-1.12.3.min.js"></script> 
  <script type="text/javascript" src="js/butoane_domenii.js"></script> 
  <script src="js/jQuery/jquery-1.11.3.min.js"></script>
  <script src="js/bootstrap-suggest.js"></script>
  <script src="js/configurare.js"></script>
  <?php include'Model\connection.php';?> 
</HEAD> 
<BODY> 
  <div class="panel" id="panel">
    <p><h3>Choose your desired domains and start learning</h3></p>
   <form id="productForm" method="POST" class="form-horizontal">   
    <div class="container"> 

      <div class="form-group"> 
        <div class="row"> 
          <div class="col-md-3">
            <label class="btn btn-primary"><img src="multimedia\SVG\html.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk1" id="item4" value="val1" class="hidden" autocomplete="off"></label> 
          </div> 
          <div class="col-md-3">
            <label class="btn btn-primary"><img src="multimedia\SVG\angular.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk2" id="item4" value="val2" class="hidden" autocomplete="off"></label> 
          </div> 
          <div class="col-md-3">
            <label class="btn btn-primary"><img src="multimedia\SVG\php.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk3" id="item4" value="val1" class="hidden" autocomplete="off"></label> 
          </div> 
          <div class="col-md-3">
            <label class="btn btn-primary"><img src="multimedia\SVG\css.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk4" id="item4" value="val1" class="hidden" autocomplete="off"></label> 
          </div> 
        </div> 
        <div class="row"> 
          <div class="col-md-3">
            <label class="btn btn-primary"><img src="multimedia\SVG\ajax.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk5" id="item4" value="val1" class="hidden" autocomplete="off"></label> 
          </div> 
          <div class="col-md-3">
            <label class="btn btn-primary"><img src="multimedia\SVG\js.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk6" id="item4" value="val1" class="hidden" autocomplete="off"></label> 
          </div> 
          <div class="col-md-3">
            <label class="btn btn-primary"><img src="multimedia\SVG\http.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk7" id="item4" value="val1" class="hidden" autocomplete="off"></label> 
          </div> 
          <div class="col-md-3">
            <label class="btn btn-primary"><img src="multimedia\SVG\xml.svg" alt="..." class="img-thumbnail img-check"><input type="checkbox" name="chk8" id="item4" value="val1" class="hidden" autocomplete="off"></label> 
          </div> 
        </div> 
      </div> 
      <div class="form-group"> 
        <div class="col-xs-5 col-xs-offset-3"> 
          <button type="submit" class="btn btn-default" id="Start" name="Start">Start Game</button> 
        </div> 
      </div> 
    </div>
  </form> 
</div> 
</BODY> 
</HTML>