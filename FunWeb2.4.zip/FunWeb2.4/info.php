<?php
    session_start();
?>
<!DOCTYPE HTML>
 <html lang="en">
<HEAD>
<TITLE>
</TITLE>
   <meta charset="utf-8">
<link rel="stylesheet" href="bootstrap-3.3.6\dist\css\bootstrap.min.css">
<script src="bootstrap-3.3.6\js\tests\vendor\jquery.min.js"></script>
  <script src="bootstrap-3.3.6\dist\js\bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  <?php include'Model\functions.php';?> 
</HEAD>
<BODY>
  <form id = "Modificare_formular" class="form-horizontal" role="form" method="POST">

      <p class="text-center">Informaţiile contului sunt disponibile pentru actualizare!  </p>
<hr>
    <div class="form-group">
      <label class="control-label col-sm-2" for="nume"> Numele: </label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="nume" placeholder="Nume" name="nume">
      </div>
     
    </div>
     <hr>
    <div class="form-group">
      <label class="control-label col-sm-2" for="prenume"> Prenumele: </label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="prenume" placeholder="Prenume" name="prenume">
      </div>
    </div>
    <hr>
    <div class="form-group">
      <label class="control-label col-sm-2" for="user"> Utilizator: </label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="user" placeholder="Nume de utilizator" name="user" disabled>
      </div>
    </div>
     <hr>
    <div class="form-group">
      <label class="control-label col-sm-2" for="data_nastere"> Data Nastere: </label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="data_nastere" placeholder="yyyy-mm-dd" name="data_nastere"> 
      </div>
    </div>
     <hr>
    
    <div class="form-group">
      <label class="control-label col-sm-2" for="email"> Email: </label>
      <div class="col-sm-10">
        <input type="email" class="form-control" id="email" placeholder="Email" name="email">
      </div>
    </div>
    
    <hr>
    <p class="text-center">Modificare parolă</p>
<div class="form-group">
      <label class="control-label col-sm-2" for="user"> Parola Veche: </label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="user" placeholder="Introdu parola veche">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="parola"> Parola Nouă: </label>
      <div class="col-sm-10">          
        <input type="password" class="form-control" id="parola" placeholder="Introdu noua parolă">
      </div>
    </div>
      <div class="form-group">
      <label class="control-label col-sm-2" for="rescrie_parola"> Confirmă Parola Nouă: </label>
      <div class="col-sm-10">          
        <input type="password" class="form-control" id="rescrie_parola" placeholder="Confirmă noua parolă">
      </div>
    </div>

     <hr>
   
    <div id= "inregistrare" class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" id="aplica_modificari" name="aplica_modificari" class="btn btn-default"> Salvare modificări </button>
      </div>
    </div>
     <hr>
  </form>

<?php
    getInfoUsers();
    modifica();
?>
<script>
//$("#user").on("change", function(){
 //   $("#email").val("hello am reusit again");
//})

$( "#user" ).change(function() {
  $("#email").val("hello am reusit ");
});

</script>

</BODY>
</HTML>