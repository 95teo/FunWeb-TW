<?php 
	function getInfoUsers(){
	//datele de conectare la baza de date
    $servername = "fenrir.info.uaic.ro";
    $username = "teo95ursan";
    $password = "aC7tAu6EWi";
    $dbname = "teo95ursan";
// Create connection
    $conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $jucatorCurent=$_SESSION["my_user"];

    $stmt =  mysqli_prepare($conn, "SELECT NUME,PRENUME,USERNAME,DATA_NASTERE,EMAIL from UTILIZATORI WHERE USERNAME=?");
    mysqli_stmt_bind_param($stmt,'s',$jucatorCurent);
    $stmt->execute();
    $stmt->bind_result($nume,$prenume,$username,$data_nastere,$email);
    $stmt->fetch();
     print '<script>
	$(function(){
        $("#nume").val("'.$nume.'");
	});
	</script>'; 
	print '<script>
	$(function(){
        $("#prenume").val("'.$prenume.'");
	});
	</script>';
	print '<script>
	$(function(){
        $("#user").val("'.$username.'");
	});
	</script>';
    print '<script>
	$(function(){
        $("#data_nastere").val("'.$data_nastere.'");
	});
	</script>';

     print '<script>
	$(function(){
        $("#email").val("'.$email.'");
	});
	</script>';

}

function modifica(){
	if(isset($_POST['aplica_modificari'])){
        $nume=$_POST['nume'];
        $prenume=$_POST['prenume'];
        $data_nastere=$_POST['data_nastere'];
        $email=$_POST['email'];
        $servername = "fenrir.info.uaic.ro";
      
    $username = "teo95ursan";
    $password = "aC7tAu6EWi";
    $dbname = "teo95ursan";
// Create connection
    $conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $jucatorCurent=$_SESSION["my_user"];

    $stmt =  mysqli_prepare($conn, "UPDATE UTILIZATORI SET NUME=?, PRENUME=?, DATA_NASTERE=?, EMAIL=? WHERE USERNAME=?");

    mysqli_stmt_bind_param($stmt,'sssss',$nume,$prenume,$data_nastere,$email,$jucatorCurent);
    $stmt->execute();
    
    }
}
?>