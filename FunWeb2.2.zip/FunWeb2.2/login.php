<?php
// Start the session
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link href="bootstrap-3.3.6\dist\css\bootstrap.css" rel="stylesheet">
  <link href="css\login.css" rel="stylesheet">
  <?php include'Model\connection.php';?>
</head>
<script>
window.fbAsyncInit = function() {
  FB.init({
    appId      : '688266017982990',
    xfbml      : true,
    version    : 'v2.5'
  });
};

(function(d, s, id){
 var js, fjs = d.getElementsByTagName(s)[0];
 if (d.getElementById(id)) {return;}
 js = d.createElement(s); js.id = id;
 js.src = "//connect.facebook.net/en_US/sdk.js";
 fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
</script>
<body>
  <div class="login">

    <form id = "Login_formular" class="form-horizontal" role="form" method="POST" >
      <div class="form-group">
        <label class="control-label col-sm-2" for="user"> <span class="glyphicon glyphicon-user"></span> </label>
        <div class="col-sm-10">
          <input type="text" name='user' class="form-control" id="user" placeholder="Nume" required="true">
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-sm-2" for="pwd"> <span class="glyphicon glyphicon-lock"></span> </label>
        <div class="col-sm-10">          
          <input type="password" name='pwd' class="form-control" id="pwd" placeholder="Parola" required="true">
        </div>
      </div>
      <div id="tine_ma_minte" class="form-group">        
        <div class="col-sm-offset-2 col-sm-10">
          <div class="checkbox">
            <label><input type="checkbox"> Ține-mă minte! </label>
          </div>
        </div>
      </div>
      <div id= "logare" class="form-group">        
        <div class="col-sm-offset-2 col-sm-10">
          <button type="submit" id="logare_buton" class="btn btn-default" name="Login" > Logare </button>
        </div>
      </div>
    </form>
    <p><span class="fb-login-button" data-max-rows="1" data-size="medium" data-show-faces="false" data-auto-logout-link="false"></span></p>
  </div>
  <?php
  login();
  if(isset($_POST['Login'])){
    $_SESSION["my_user"]=$_POST["user"];
    echo $_SESSION["my_user"];}
    ?>
  </body>
  </html>
