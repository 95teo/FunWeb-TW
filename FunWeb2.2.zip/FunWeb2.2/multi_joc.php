<!DOCTYPE HTML>
<html lang="en">
<HEAD>
  <TITLE>
  </TITLE>
  <meta charset="utf-8">
  <link rel="stylesheet" href="bootstrap-3.3.6\dist\css\bootstrap.min.css">
  <link rel="stylesheet" href="css\multi_joc.css">
  <script src="bootstrap-3.3.6\js\tests\vendor\jquery.min.js"></script>
  <script src="bootstrap-3.3.6\dist\js\bootstrap.min.js"></script>
  <?php include'Model\connection.php';?> 
</HEAD>
<BODY>
  <form id = "form-modifier" class="form-horizontal" role="form">

    
    <div class="statistics">

      <label class="control-label col-sm-2" > Întrebări rămase: </label>

      <label class="control-label col-sm-2" > Răspunsuri corecte: </label>
      
      <label class="control-label col-sm-2" > Răspunsuri greşite: </label>
      
      <label class="control-label col-sm-2" > Scorul meu: </label>

      <label class="control-label col-sm-2" > Scor prieten1: </label>
      <label class="control-label col-sm-2" > Scor prieten2: </label>
      
      
      <hr>  
    </div>
    <br>
    
    <div class="form-group"><hr> 
      <label class="control-label col-sm-2" > Întrebarea: </label>
      <div class="col-sm-10">
      </div>
    </div>
    <hr>
    <div class="form-group">
      <label class="control-label col-sm-2" > A: </label>
      <div class="col-sm-10">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" > B: </label>
      <div class="col-sm-10">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" > C: </label>
      <div class="col-sm-10">
      </div>
    </div>
    
    <div class="form-group">
      <label class="control-label col-sm-2" > D: </label>
      <div class="col-sm-10">
      </div>
    </div>
    <hr>

    <hr>
    
    <div id= "butoane" class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" id="inregistrare_buton" class="btn btn-default" onclick="<php getQuestion(); ?>"> A </button>
        <button type="submit" id="inregistrare_buton" class="btn btn-default"> B </button>
        <button type="submit" id="inregistrare_buton" class="btn btn-default"> C </button>
        <button type="submit" id="inregistrare_buton" class="btn btn-default"> D </button>
      </div>
    </div>
    <hr>
  </form>



</BODY>
</HTML>