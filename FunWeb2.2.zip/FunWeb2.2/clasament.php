<DOCTYPE HTML>
<HEAD>
<TITLE>
</TITLE>
<link rel="stylesheet" href="bootstrap-3.3.6\dist\css\bootstrap.min.css">
<script src="bootstrap-3.3.6\js\tests\vendor\jquery.min.js"></script>
  <script src="bootstrap-3.3.6\dist\js\bootstrap.min.js"></script>

</HEAD>
<BODY>
 <table class="table table-striped">
  <thead>
    <th>Nume jucator</th>
    <th>Punctaj</th>
  </thead>  
    <tbody>
    </tbody>
  </table>

</BODY>
</HTML>